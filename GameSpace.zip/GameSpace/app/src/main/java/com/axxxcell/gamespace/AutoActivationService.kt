package com.axxxcell.gamespace

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.axxxcell.gamespace.data.Flag
import com.axxxcell.gamespace.data.GameRepository
import com.axxxcell.gamespace.data.SettingsStore
import com.axxxcell.gamespace.ui.OverlayViews
import com.axxxcell.gamespace.ui.dpi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** Values other parts of the app (Boost, Group 6) write so the session summary can show them. */
object SessionStats {
    @Volatile var freedMb: Int = 0
}

/**
 * Smart activation. Dormant by default: it is event-driven (the system only wakes it when the
 * front window changes), runs no foreground service and shows no notification. When Auto Mode is
 * off, or no games are added, it asks the system to send it zero events.
 */
class AutoActivationService : AccessibilityService() {

    companion object {
        private const val END_DELAY_MS = 10_000L      // game must be gone this long before we stop
        private const val BANNER_MS = 2_500L
        private const val SUMMARY_MS = 30_000L
        private const val MIN_SUMMARY_MS = 15_000L

        @Volatile var instance: AutoActivationService? = null

        /** Free + Pro: BOOST on a card starts a session so the floating toolbar appears. */
        fun startManual(pkg: String): Boolean {
            val s = instance ?: return false
            s.handler.post { s.beginManual(pkg) }
            return true
        }

        fun isEnabled(ctx: Context): Boolean {
            val list = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val cn = ComponentName(ctx, AutoActivationService::class.java)
            val full = cn.flattenToString()
            val short = cn.flattenToShortString()
            return list.split(':').any { it.equals(full, true) || it.equals(short, true) }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: SettingsStore
    private lateinit var repo: GameRepository
    private lateinit var wm: WindowManager

    private var auto = false
    private var proFlag = false
    private var proExpiry = 0L
    private fun isPro() = proFlag && System.currentTimeMillis() <= proExpiry
    private data class St(val auto: Boolean, val games: Set<String>, val pro: Boolean, val exp: Long)
    private var games: Set<String> = emptySet()

    private var sessionPkg: String? = null
    private var sessionStart = 0L
    private var endScheduled = false

    private var toolbar: GameToolbar? = null
    private var gameMode = true
    private var mode = "balanced"
    private var muteFlag = false
    private var closeFlag = true
    private var banner: View? = null
    private var summary: View? = null

    private val endRunnable = Runnable { endScheduled = false; endSession(true) }
    private val hideBanner = Runnable { removeBanner() }
    private val hideSummary = Runnable { removeSummary() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        store = SettingsStore(this)
        repo = GameRepository(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        scope.launch { store.flag(Flag.GAME_MODE).collect { gameMode = it } }
        scope.launch { store.flag(Flag.MUTE_CALLS).collect { muteFlag = it } }
        scope.launch { store.flag(Flag.CLOSE_APPS).collect { closeFlag = it } }
        scope.launch { store.mode.collect { mode = it } }
        scope.launch {
            combine(store.flag(Flag.AUTO_MODE), store.games, store.flag(Flag.PRO), store.proExpiry) { a, g, p, e ->
                St(a, g, p, e)
            }.collect { st ->
                auto = st.auto
                games = st.games
                proFlag = st.pro
                proExpiry = st.exp
                applyDormancy()
            }
        }
    }

    /** No Auto Mode or no games = ask the system for zero events. */
    private fun applyDormancy() {
        val live = (auto && isPro() && games.isNotEmpty()) || sessionPkg != null
        serviceInfo?.let { info ->
            val want = if (live) AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED else 0
            if (info.eventTypes != want) {
                info.eventTypes = want
                serviceInfo = info
            }
        }
        if (!live && sessionPkg != null) endSession(false)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (ignored(pkg, e.className?.toString())) return

        if (pkg in games) {
            handler.removeCallbacks(endRunnable)
            endScheduled = false
            if (sessionPkg != pkg) {
                if (sessionPkg != null) endSession(true)
                if (auto && isPro()) startSession(pkg)
            }
        } else if (sessionPkg != null && !endScheduled) {
            endScheduled = true
            handler.postDelayed(endRunnable, END_DELAY_MS)
        }
    }

    /** Skip system noise so pulling the shade or opening the keyboard never ends a session. */
    private fun ignored(pkg: String, cls: String?): Boolean {
        if (pkg == packageName || pkg == "android" || pkg == "com.android.systemui") return true
        if (pkg.contains("inputmethod") || pkg.contains("keyboard")) return true
        // WhatsApp (opened from the toolbar) must not count as leaving the game
        if (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") return true
        if (cls != null && (cls.startsWith("android.widget.") || cls.startsWith("android.view."))) return true
        return false
    }

    // ---------- session ----------

    /** Toolbar "Cool down": closes background apps, then shows what was closed and the battery temperature. */
    private fun coolDownNow() {
        val pkg = sessionPkg ?: return
        val label = repo.load(pkg)?.label ?: pkg
        scope.launch {
            val r = BoostUtils.boost(this@AutoActivationService, games)
            SessionStats.freedMb += r.totalMb
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            val extra = "Closed ${r.apps} apps" + if (t > 0f) "  |  Battery ${Math.round(t)}\u00B0C" else ""
            showBanner(label, extra, "COOLING DOWN")
        }
    }

    private fun beginManual(pkg: String) {
        if (sessionPkg == pkg) return
        if (sessionPkg != null) endSession(false)
        startSession(pkg, manual = true)
        applyDormancy()
        // if the game never reaches the screen, stop after 15 s
        endScheduled = true
        handler.postDelayed(endRunnable, 15_000L)
    }

    private fun startSession(pkg: String, manual: Boolean = false) {
        sessionPkg = pkg
        sessionStart = SystemClock.elapsedRealtime()
        if (!manual) SessionStats.freedMb = 0
        val label = repo.load(pkg)?.label ?: pkg
        showBanner(label, if (manual && SessionStats.freedMb > 0) "Freed ${SessionStats.freedMb}MB" else null)
        toolbar = GameToolbar(this, wm, handler, isPro(), if (gameMode && muteFlag && closeFlag) "ultra" else "balanced", { m -> scope.launch { store.applyPreset(m) } }, { coolDownNow() }).also {
            it.show()
            if (gameMode) it.enableBlockNotifications()   // "Block notifications" switch
            if (muteFlag) it.enableMuteCalls()            // "Mute calls" switch
        }
        if (closeFlag && !manual) {
            // Real boost runs once at the start of each game session.
            scope.launch {
                val r = BoostUtils.boost(this@AutoActivationService, games)
                SessionStats.freedMb = r.totalMb
                if (sessionPkg == pkg) showBanner(label, "Freed ${r.totalMb}MB \u2022 ${r.apps} apps cleaned")
            }
        }
    }

    private fun endSession(showSummary: Boolean) {
        val pkg = sessionPkg ?: return
        val dur = SystemClock.elapsedRealtime() - sessionStart
        val label = (repo.load(pkg)?.label ?: pkg).replace("|", " ").replace("\n", " ")
        val freed = SessionStats.freedMb
        sessionPkg = null
        endScheduled = false
        applyDormancy()
        handler.removeCallbacks(endRunnable)
        removeBanner()
        toolbar?.hide()
        toolbar = null
        scope.launch {
            store.addSession("$pkg|$label|${System.currentTimeMillis() - dur}|$dur|$freed")
        }
        if (showSummary && dur >= MIN_SUMMARY_MS) {
            val min = (dur / 60_000).toInt()
            val played = if (min < 1) "<1min" else "${min}min"
            val line = "Played $label $played" + if (freed > 0) " | Freed ${freed}MB" else ""
            showSummary(line)
        }
    }

    // ---------- overlays (no overlay permission needed for accessibility overlays) ----------

    private fun params(touchable: Boolean, gravity: Int, y: Int): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity; this.y = y }
    }

    private fun showBanner(game: String, extra: String? = null, title: String = "SYSTEM ENGAGED") {
        removeBanner()
        val v = OverlayViews.banner(this, game, extra, title)
        v.alpha = 0f
        try {
            wm.addView(v, params(false, Gravity.TOP or Gravity.CENTER_HORIZONTAL, dpi(10f)))
            banner = v
            v.animate().alpha(1f).setDuration(200).start()
            handler.postDelayed(hideBanner, BANNER_MS)
        } catch (e: Exception) { /* window could not be added; ignore */ }
    }

    private fun removeBanner() {
        handler.removeCallbacks(hideBanner)
        banner?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        banner = null
    }

    private fun showSummary(line: String) {
        removeSummary()
        val v = OverlayViews.summary(this, line) { removeSummary() }
        v.alpha = 0f
        try {
            wm.addView(v, params(true, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, dpi(24f)))
            summary = v
            v.animate().alpha(1f).setDuration(250).start()
            handler.postDelayed(hideSummary, SUMMARY_MS)
        } catch (e: Exception) { /* ignore */ }
    }

    private fun removeSummary() {
        handler.removeCallbacks(hideSummary)
        summary?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        summary = null
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // the game may have rotated: rebuild the panel for the new screen shape
        toolbar?.let { tb -> handler.postDelayed({ tb.relayout() }, 400) }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeBanner()
        removeSummary()
        toolbar?.hide()
        toolbar = null
        scope.cancel()
        super.onDestroy()
    }
}
