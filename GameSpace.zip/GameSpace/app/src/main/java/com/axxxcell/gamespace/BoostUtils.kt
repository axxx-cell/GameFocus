package com.axxxcell.gamespace

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Real Boost: asks Android to close background processes of normal apps and clears Game Space's own cache.
 * Android does not let ordinary apps clear OTHER apps' caches, so that is not attempted.
 */
object BoostUtils {

    data class Result(val ramMb: Int, val cacheMb: Int, val apps: Int) {
        val totalMb: Int get() = ramMb + cacheMb
    }

    /** Never touched, so messages and typing keep working. */
    private val ALWAYS_PROTECT = setOf("com.whatsapp", "com.whatsapp.w4b")

    suspend fun boost(
        ctx: Context,
        protect: Set<String>,
        onStep: (String) -> Unit = {}
    ): Result = withContext(Dispatchers.IO) {
        val app = ctx.applicationContext
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = app.packageManager

        withContext(Dispatchers.Main) { onStep("Closing background apps...") }
        val before = availMb(am)

        val home = pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName
        val ime = Settings.Secure.getString(app.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')
        val keep = HashSet<String>().apply {
            addAll(protect); addAll(ALWAYS_PROTECT); add(app.packageName)
            home?.let { add(it) }; ime?.let { add(it) }
        }

        @Suppress("DEPRECATION")
        val candidates = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it !in keep }

        var cleaned = 0
        for (pkg in candidates) {
            try {
                val ai = pm.getApplicationInfo(pkg, 0)
                val userApp = (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                    (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                val stopped = (ai.flags and ApplicationInfo.FLAG_STOPPED) != 0
                if (userApp && !stopped) {
                    am.killBackgroundProcesses(pkg)
                    cleaned++
                }
            } catch (_: Exception) {}
        }
        delay(1000)                       // let the system release the memory
        val ramFreed = (availMb(am) - before).coerceAtLeast(0)

        withContext(Dispatchers.Main) { onStep("Clearing cache...") }
        val cacheBytes = clearOwnCache(app)

        Result(ramFreed, (cacheBytes / (1024 * 1024)).toInt(), cleaned)
    }

    private fun availMb(am: ActivityManager): Int {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return (mi.availMem / (1024 * 1024)).toInt()
    }

    private fun clearOwnCache(ctx: Context): Long {
        var freed = 0L
        for (dir in listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)) freed += deleteContents(dir)
        return freed
    }

    private fun deleteContents(dir: File): Long {
        var n = 0L
        dir.listFiles()?.forEach { f ->
            n += if (f.isDirectory) deleteContents(f).also { f.delete() } else f.length().also { f.delete() }
        }
        return n
    }
}
