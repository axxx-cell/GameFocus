package com.axxxcell.gamespace

/** Fill these in before you publish. */
object Config {
    /** Text file in your GitHub repo. One line per buyer:  XXXX-XXXX 2026-12-31  (device code + last day of Pro). */
    const val PRO_LIST_URL = "https://raw.githubusercontent.com/axxx-cell/Game-Space/main/pro.txt"
    const val CONTACT_EMAIL = "YOUR_EMAIL@gmail.com"
    const val GCASH_NUMBER = "09XX-XXX-XXXX"
}
