package com.axxxcell.gamespace

object Config {
    /**
     * Same list file as Side Panel (GitHub user axxx-cell, repo Side-Panel).
     * One line per buyer:  XXXX-XXXX 2026-12-31   (device code, then the last day of Pro).
     * Lines that start with # can also carry the payment details, so you can change them without a new build:
     *   # email: you@gmail.com
     *   # gcash: 09xx xxx xxxx
     *   # price: 99 pesos for the first month, then 25 pesos per month
     */
    const val PRO_LIST_URL = "https://raw.githubusercontent.com/axxx-cell/Side-Panel/main/pro.txt"

    // Used unless the list has its own "# email:" / "# gcash:" lines.
    const val CONTACT_EMAIL = "ax020318@gmail.com"
    const val GCASH_NUMBER = "09097574108"
    const val PRICE_TEXT = "99 pesos for the first month, then 25 pesos per month"
}
