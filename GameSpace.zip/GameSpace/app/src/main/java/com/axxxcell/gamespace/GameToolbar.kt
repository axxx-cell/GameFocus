package com.axxxcell.gamespace

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.axxxcell.gamespace.ui.*
import java.io.File
import kotlin.math.abs

/** Glowing dot shown when the toolbar is minimized. */
class GlowDot(ctx: Context) : View(ctx) {
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GS.CYAN }
    override fun onMeasure(w: Int, h: Int) {
        val s = context.dpi(46f)
        setMeasuredDimension(s, s)
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        glow.shader = RadialGradient(
            w / 2f, h / 2f, w / 2f,
            intArrayOf(0xCC00F5FF.toInt(), 0x4400F5FF, 0x0000F5FF),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }
    override fun onDraw(c: Canvas) {
        c.drawCircle(width / 2f, height / 2f, width / 2f, glow)
        c.drawCircle(width / 2f, height / 2f, width * 0.16f, core)
    }
}

/** Round glass tool button (40dp). */
class ToolButton(ctx: Context, iconRes: Int) : FrameLayout(ctx) {
    private val icon: ImageView = ctx.icon(iconRes, 20f, GS.TEXT_SECONDARY)
    init {
        isClickable = true
        addView(icon, LayoutParams(dpi(20f), dpi(20f), Gravity.CENTER))
        setOn(false)
    }
    fun setOn(on: Boolean) {
        icon.setColorFilter(if (on) GS.CYAN else GS.TEXT_SECONDARY)
        glass(
            cornerDp = 20f,
            fill = if (on) 0xB3252D5A.toInt() else GS.GLASS_PILL_70,
            stroke = if (on) 0x9900F5FF.toInt() else GS.CYAN_BORDER_20
        )
    }
}

/**
 * Draggable in-game toolbar, shown as an accessibility overlay while a game session is active.
 * Contents: display refresh + temperatures, brightness slider, block notifications, touch lock, minimize.
 */
class GameToolbar(
    private val ctx: Context,
    private val wm: WindowManager,
    private val handler: Handler
) {
    companion object {
        private var lastX = -1
        private var lastY = -1
    }

    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun dpi(v: Float): Int = ctx.dpi(v)

    private var root: FrameLayout? = null
    private var lockView: FrameLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bar: LinearLayout
    private lateinit var dot: GlowDot
    private lateinit var hzText: TextView
    private lateinit var tempText: TextView
    private lateinit var sliderRow: LinearLayout
    private lateinit var brightBtn: ToolButton
    private lateinit var dndBtn: ToolButton
    private lateinit var lockBtn: ToolButton
    private lateinit var muteBtn: ToolButton
    private lateinit var crossBtn: ToolButton
    private lateinit var recBtn: ToolButton
    private lateinit var waBtn: ToolButton
    private lateinit var zoomBtn: ToolButton
    private var zoomIdx = 0
    private val zoomLevels = floatArrayOf(1.0f, 1.2f, 1.4f, 1.6f)
    private val crosshair = CrosshairOverlay(ctx, wm)
    private var crossStyle = 0            // 0 = off, 1..10 = style
    private var muteCalls = false
    private var watermarkView: View? = null

    private var minimized = false
    private var hudRunning = false

    // block notifications state
    private var dndActive = false
    private var prevFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var prevPolicy: NotificationManager.Policy? = null

    // brightness state
    private var origBrightness = -1
    private var origMode = -1

    private val hudTick = object : Runnable {
        override fun run() {
            if (!hudRunning) return
            updateHud()
            handler.postDelayed(this, 2000)
        }
    }
    private val unlockRun = Runnable { unlock() }

    private val cpuZones: List<File> by lazy {
        try {
            File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
                ?.filter {
                    val t = try { File(it, "type").readText().trim().lowercase() } catch (e: Exception) { "" }
                    t.contains("cpu") || t.contains("soc") || t.contains("tsens")
                }
                ?.map { File(it, "temp") } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    // ---------- show / hide ----------

    fun show() {
        if (root != null) return
        val r = FrameLayout(ctx)

        bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(8f), dpi(6f), dpi(8f), dpi(6f))
            glass(cornerDp = 26f, fill = 0xE60A0E1E.toInt(), stroke = 0x8800F5FF.toInt())
        }
        val hud = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(6f), 0, dpi(10f), 0) }
        hzText = TextView(ctx).apply {
            textSize = 13f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setShadowLayer(ctx.dp(6f), 0f, 0f, GS.CYAN)
        }
        tempText = TextView(ctx).apply { textSize = 9f; setTextColor(GS.WHITE); typeface = Typeface.MONOSPACE }
        hud.addView(hzText); hud.addView(tempText)

        brightBtn = ToolButton(ctx, R.drawable.ic_sun)
        dndBtn = ToolButton(ctx, R.drawable.ic_bell_off)
        muteBtn = ToolButton(ctx, R.drawable.ic_phone_off)
        lockBtn = ToolButton(ctx, R.drawable.ic_lock)
        crossBtn = ToolButton(ctx, R.drawable.ic_crosshair)
        recBtn = ToolButton(ctx, R.drawable.ic_record)
        waBtn = ToolButton(ctx, R.drawable.ic_chat)
        zoomBtn = ToolButton(ctx, R.drawable.ic_zoom)
        val minBtn = ToolButton(ctx, R.drawable.ic_minus)
        brightBtn.setOnClickListener { toggleBrightness() }
        dndBtn.setOnClickListener { toggleDnd() }
        muteBtn.setOnClickListener { toggleMute() }
        lockBtn.setOnClickListener { lock() }
        crossBtn.setOnClickListener { cycleCrosshair() }
        recBtn.setOnClickListener { toggleRecord() }
        waBtn.setOnClickListener { openWhatsApp() }
        zoomBtn.setOnClickListener { cycleZoom() }
        minBtn.setOnClickListener { setMinimized(true) }

        val tools = listOf(brightBtn, dndBtn, muteBtn, lockBtn, crossBtn, zoomBtn, recBtn, waBtn)
        val dmx = ctx.resources.displayMetrics
        val wide = dmx.widthPixels / dmx.density >= 600f
        fun btnLp() = LinearLayout.LayoutParams(dpi(40f), dpi(40f)).apply { marginStart = dpi(4f) }
        if (wide) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(hud)
            for (b in tools) row.addView(b, btnLp())
            row.addView(minBtn, btnLp())
            bar.addView(row)
        } else {
            val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(hud)
            head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
            head.addView(minBtn, btnLp())
            bar.addView(head)
            for (chunk in tools.chunked(4)) {
                val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                for (b in chunk) row.addView(b, btnLp())
                bar.addView(row, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(2f) })
            }
        }

        sliderRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        sliderRow.addView(SeekBar(ctx).apply {
            max = 245
            progress = currentBrightness() - 10
            progressTintList = android.content.res.ColorStateList.valueOf(GS.CYAN)
            thumbTintList = android.content.res.ColorStateList.valueOf(GS.CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) setBrightness(p + 10)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }, LinearLayout.LayoutParams(dpi(220f), dpi(32f)))
        bar.addView(sliderRow, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(2f) })

        dot = GlowDot(ctx).apply { visibility = View.GONE }
        r.addView(bar)
        r.addView(dot)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (lastX >= 0) lastX else ctx.dpi(90f)
            y = if (lastY >= 0) lastY else ctx.dpi(64f)
        }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > ctx.dp(6f) || abs(dy) > ctx.dp(6f)) moved = true
                    if (moved) {
                        lp.x = (ox + dx).toInt().coerceAtLeast(0)
                        lp.y = (oy + dy).toInt().coerceAtLeast(0)
                        try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    lastX = lp.x; lastY = lp.y
                    if (!moved && minimized) setMinimized(false)
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(r, lp)
            root = r
            RecordState.listener = { on -> handler.post { onRecordChanged(on) } }
            updateHud()
            startHud()
        } catch (e: Exception) { /* could not add window */ }
    }

    fun hide() {
        stopHud()
        handler.removeCallbacks(unlockRun)
        lockView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        lockView = null
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        resetZoom()
        RecordState.listener = null
        if (RecordState.recording) ScreenRecordService.stop()
        removeWatermark()
        crosshair.hide()
        if (dndActive) setDnd(false)
        restoreBrightness()
    }

    private fun setMinimized(min: Boolean) {
        minimized = min
        bar.visibility = if (min) View.GONE else View.VISIBLE
        dot.visibility = if (min) View.VISIBLE else View.GONE
        if (min) stopHud() else { updateHud(); startHud() }
        root?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
    }

    // ---------- HUD (only ticks while the toolbar is expanded) ----------

    private fun startHud() { if (!hudRunning && !minimized && lockView == null) { hudRunning = true; handler.postDelayed(hudTick, 2000) } }
    private fun stopHud() { hudRunning = false; handler.removeCallbacks(hudTick) }

    private fun updateHud() {
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val hz = dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f
        hzText.text = "${Math.round(hz)}Hz"
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val b = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val cpu = cpuTemp()
        val cpuTxt = if (cpu != null) "CPU ${Math.round(cpu)}°  " else ""
        tempText.text = cpuTxt + (if (b > 0f) "BAT ${Math.round(b)}°" else "")
    }

    private fun cpuTemp(): Float? {
        var best: Float? = null
        for (f in cpuZones) {
            try {
                val raw = f.readText().trim().toFloatOrNull() ?: continue
                val c = if (raw > 1000f) raw / 1000f else raw
                if (c in 10f..120f) best = maxOf(best ?: 0f, c)
            } catch (_: Exception) {}
        }
        return best
    }

    // ---------- block notifications ----------

    fun enableBlockNotifications() { if (!dndActive && nm.isNotificationPolicyAccessGranted) setDnd(true) }

    private fun toggleDnd() { setDnd(!dndActive) }

    /** Muting calls works through Do Not Disturb, so it switches Block notifications on too. */
    private fun toggleMute() {
        muteCalls = !muteCalls
        if (muteCalls) {
            if (!dndActive) setDnd(true) else applyPolicy()
            if (!dndActive) muteCalls = false
        } else if (dndActive) {
            applyPolicy()
        }
        if (root != null) muteBtn.setOn(muteCalls)
    }

    private fun applyPolicy() {
        val vis = if (Build.VERSION.SDK_INT >= 28) NotificationManager.Policy.SUPPRESSED_EFFECT_PEEK
                  else NotificationManager.Policy.SUPPRESSED_EFFECT_SCREEN_ON
        val cats = NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS or
            (if (muteCalls) 0 else NotificationManager.Policy.PRIORITY_CATEGORY_CALLS) or
            (if (Build.VERSION.SDK_INT >= 28) NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA else 0)
        nm.notificationPolicy = NotificationManager.Policy(cats, NotificationManager.Policy.PRIORITY_SENDERS_ANY, 0, vis)
    }

    private fun setDnd(on: Boolean) {
        try {
            if (on) {
                if (!nm.isNotificationPolicyAccessGranted) {
                    openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                    return
                }
                prevFilter = nm.currentInterruptionFilter
                prevPolicy = nm.notificationPolicy
                applyPolicy()
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                dndActive = true
            } else {
                nm.setInterruptionFilter(prevFilter)
                prevPolicy?.let { nm.notificationPolicy = it }
                dndActive = false
                muteCalls = false
            }
        } catch (e: Exception) { dndActive = false; muteCalls = false }
        if (root != null) { dndBtn.setOn(dndActive); muteBtn.setOn(muteCalls) }
    }

    // ---------- crosshair ----------

    private fun cycleCrosshair() {
        crossStyle = (crossStyle + 1) % (CrosshairView.STYLES + 1)
        if (crossStyle == 0) {
            crosshair.hide()
            Toast.makeText(ctx, "Crosshair off", Toast.LENGTH_SHORT).show()
        } else {
            crosshair.show(crossStyle - 1)
            Toast.makeText(ctx, "Crosshair $crossStyle/${CrosshairView.STYLES}", Toast.LENGTH_SHORT).show()
        }
        crossBtn.setOn(crossStyle != 0)
    }

    // ---------- screen record ----------

    private fun toggleRecord() {
        if (RecordState.recording) {
            ScreenRecordService.stop()
        } else {
            try {
                ctx.startActivity(Intent(ctx, RecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }
    }

    /** While recording, the toolbar hides itself so it is not in the video. Stop from the notification. */
    private fun onRecordChanged(on: Boolean) {
        if (root == null) return
        recBtn.setOn(on)
        if (lockView == null) root?.visibility = if (on) View.GONE else View.VISIBLE
        if (on && RecordState.watermark) showWatermark() else removeWatermark()
    }

    private fun showWatermark() {
        if (watermarkView != null) return
        val v = TextView(ctx).apply {
            text = "GAME SPACE"
            textSize = 11f
            setTextColor(0xB300F5FF.toInt())
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(ctx.dp(4f), 0f, 0f, 0xFF000000.toInt())
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = ctx.dpi(16f); y = ctx.dpi(12f) }
        try { wm.addView(v, p); watermarkView = v } catch (_: Exception) {}
    }

    private fun removeWatermark() {
        watermarkView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        watermarkView = null
    }

    // ---------- zoom (bigger game picture) ----------

    /** Magnifies the whole display around its centre. Touches still reach the game correctly. */
    private fun cycleZoom() {
        val mc = (ctx as? android.accessibilityservice.AccessibilityService)?.magnificationController
        if (mc == null) {
            Toast.makeText(ctx, "Zoom is not supported on this phone", Toast.LENGTH_SHORT).show()
            return
        }
        zoomIdx = (zoomIdx + 1) % zoomLevels.size
        val scale = zoomLevels[zoomIdx]
        try {
            if (scale <= 1.0f) {
                mc.reset(true)
            } else {
                val dm = ctx.resources.displayMetrics
                mc.setScale(scale, true)
                mc.setCenter(dm.widthPixels / 2f, dm.heightPixels / 2f, true)
            }
            Toast.makeText(ctx, if (scale <= 1.0f) "Zoom off" else "Zoom ${Math.round(scale * 100)}%", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            zoomIdx = 0
            Toast.makeText(ctx, "Zoom is not supported on this phone", Toast.LENGTH_SHORT).show()
        }
        zoomBtn.setOn(zoomIdx != 0)
    }

    private fun resetZoom() {
        if (zoomIdx == 0) return
        try { (ctx as? android.accessibilityservice.AccessibilityService)?.magnificationController?.reset(true) } catch (_: Exception) {}
        zoomIdx = 0
    }

    // ---------- WhatsApp ----------

    private fun openWhatsApp() {
        val pm = ctx.packageManager
        val i = pm.getLaunchIntentForPackage("com.whatsapp") ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
        if (i == null) {
            Toast.makeText(ctx, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
        } else {
            try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    // ---------- brightness ----------

    private fun currentBrightness(): Int =
        try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }.coerceIn(10, 255)

    private fun toggleBrightness() {
        if (!Settings.System.canWrite(ctx)) {
            openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
            return
        }
        val show = sliderRow.visibility != View.VISIBLE
        sliderRow.visibility = if (show) View.VISIBLE else View.GONE
        brightBtn.setOn(show)
        root?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
    }

    private fun setBrightness(v: Int) {
        try {
            if (origBrightness < 0) {
                origBrightness = currentBrightness()
                origMode = Settings.System.getInt(
                    ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
            }
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(10, 255))
        } catch (_: Exception) {}
    }

    private fun restoreBrightness() {
        if (origBrightness < 0) return
        try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, origBrightness)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, origMode)
        } catch (_: Exception) {}
        origBrightness = -1
    }

    // ---------- touch lock ----------

    private fun lock() {
        if (lockView != null) return
        val v = FrameLayout(ctx).apply {
            setBackgroundColor(0x01000000)
            setOnTouchListener { _, _ -> true }
        }
        v.addView(TextView(ctx).apply {
            text = "TOUCH LOCKED"
            textSize = 10f
            setTextColor(GS.CYAN)
            typeface = Typeface.MONOSPACE
            letterSpacing = 0.15f
            setPadding(dpi(14f), dpi(5f), dpi(14f), dpi(5f))
            glass(cornerDp = 14f, fill = 0xCC0A0E1E.toInt(), stroke = 0x8800F5FF.toInt())
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dpi(10f) })

        val unlockBtn = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            glass(cornerDp = 30f, fill = 0xCC0A0E1E.toInt(), stroke = 0xAA00F5FF.toInt())
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { handler.postDelayed(unlockRun, 1000); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(unlockRun); true }
                    else -> true
                }
            }
        }
        unlockBtn.addView(ctx.icon(R.drawable.ic_lock, 20f, GS.CYAN))
        unlockBtn.addView(TextView(ctx).apply {
            text = "HOLD"; textSize = 8f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
        })
        v.addView(unlockBtn, FrameLayout.LayoutParams(dpi(60f), dpi(60f), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dpi(20f), dpi(20f))
        })

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, p)
            lockView = v
            root?.visibility = View.GONE
            stopHud()
        } catch (_: Exception) {}
    }

    private fun unlock() {
        lockView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        lockView = null
        root?.visibility = View.VISIBLE
        if (!minimized) { updateHud(); startHud() }
    }

    private fun openSettings(action: String, uri: Uri?) {
        try {
            val i = Intent(action)
            if (uri != null) i.data = uri
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            Toast.makeText(ctx, "Allow Game Space, then go back to your game", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {}
    }
}
