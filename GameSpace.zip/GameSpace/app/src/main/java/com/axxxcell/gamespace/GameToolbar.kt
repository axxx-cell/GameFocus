package com.axxxcell.gamespace

import android.app.ActivityManager
import android.util.DisplayMetrics
import android.app.NotificationManager
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.axxxcell.gamespace.ui.*
import java.io.File
import kotlin.math.abs

/** Glowing dot shown when the toolbar is minimized. */
class GlowDot(ctx: Context) : View(ctx) {
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GS.CYAN }
    override fun onMeasure(w: Int, h: Int) {
        val s = context.dpi(46f)
        setMeasuredDimension(s, s)
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        glow.shader = RadialGradient(
            w / 2f, h / 2f, w / 2f,
            intArrayOf(0xCC00F5FF.toInt(), 0x4400F5FF, 0x0000F5FF),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }
    override fun onDraw(c: Canvas) {
        c.drawCircle(width / 2f, height / 2f, width / 2f, glow)
        c.drawCircle(width / 2f, height / 2f, width * 0.16f, core)
    }
}

/** Round tool button with a caption. ON = filled cyan circle. Pro-only buttons get a small lock badge. */
class ToolButton(ctx: Context, iconRes: Int, caption: String) : LinearLayout(ctx) {
    private val icon: ImageView = ctx.icon(iconRes, 20f, GS.WHITE)
    private val circle = FrameLayout(ctx)
    private val badge: ImageView = ctx.icon(R.drawable.ic_lock, 11f, GS.CYAN)
    private val cap = TextView(ctx)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        circle.addView(icon, FrameLayout.LayoutParams(dpi(20f), dpi(20f), Gravity.CENTER))
        circle.addView(badge, FrameLayout.LayoutParams(dpi(11f), dpi(11f), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dpi(3f), dpi(3f), 0)
        })
        badge.visibility = GONE
        addView(circle, LinearLayout.LayoutParams(dpi(40f), dpi(40f)))
        cap.apply { text = caption; textSize = 8f; gravity = Gravity.CENTER; maxLines = 1 }
        addView(cap, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(2f) })
        setOn(false)
    }

    fun setLocked(l: Boolean) {
        badge.visibility = if (l) VISIBLE else GONE
        icon.alpha = if (l) 0.45f else 1f
    }

    fun setOn(on: Boolean) {
        circle.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) 0xFF00E5FF.toInt() else 0x66444C78)
            setStroke(dpi(1f), if (on) 0xFF00F5FF.toInt() else 0x33FFFFFF)
        }
        icon.setColorFilter(if (on) 0xFF04202B.toInt() else GS.WHITE)
        cap.setTextColor(if (on) GS.CYAN else GS.TEXT_SECONDARY)
    }
}

/**
 * Draggable in-game toolbar, shown as an accessibility overlay while a game session is active.
 * Contents: display refresh + temperatures, brightness slider, block notifications, touch lock, minimize.
 */
class GameToolbar(
    private val ctx: Context,
    private val wm: WindowManager,
    private val handler: Handler,
    private val pro: Boolean,
    private val initialMode: String,
    private val onMode: (String) -> Unit
) {
    companion object {
        private var lastX = -1
        private var lastY = -1
    }

    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun dpi(v: Float): Int = ctx.dpi(v)

    private var root: FrameLayout? = null
    private var lockView: FrameLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bar: LinearLayout
    private lateinit var dot: GlowDot
    private lateinit var batteryVal: TextView
    private lateinit var netVal: TextView
    private lateinit var ramVal: TextView
    private lateinit var tempVal: TextView
    private lateinit var hzVal: TextView
    private val modeChips = HashMap<String, TextView>()
    private var curMode = initialMode
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    private lateinit var sliderRow: LinearLayout
    private lateinit var brightBtn: ToolButton
    private lateinit var dndBtn: ToolButton
    private lateinit var lockBtn: ToolButton
    private lateinit var muteBtn: ToolButton
    private lateinit var crossBtn: ToolButton
    private lateinit var recBtn: ToolButton
    private lateinit var waBtn: ToolButton
    private lateinit var zoomBtn: ToolButton
    private var zoomIdx = 0
    private val zoomLevels = floatArrayOf(1.0f, 1.2f, 1.4f, 1.6f)
    private val crosshair = CrosshairOverlay(ctx, wm)
    private var crossStyle = 0            // 0 = off, 1..10 = style
    private var muteCalls = false
    private var watermarkView: View? = null

    private var minimized = false
    private var userMoved = lastX >= 0
    private var hudRunning = false

    // block notifications state
    private var dndActive = false
    private var prevFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var prevPolicy: NotificationManager.Policy? = null

    // brightness state
    private var origBrightness = -1
    private var origMode = -1

    private val hudTick = object : Runnable {
        override fun run() {
            if (!hudRunning) return
            updateHud()
            handler.postDelayed(this, 2000)
        }
    }
    private val unlockRun = Runnable { unlock() }

    private val cpuZones: List<File> by lazy {
        try {
            File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
                ?.filter {
                    val t = try { File(it, "type").readText().trim().lowercase() } catch (e: Exception) { "" }
                    t.contains("cpu") || t.contains("soc") || t.contains("tsens")
                }
                ?.map { File(it, "temp") } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    // ---------- show / hide ----------

    /** Real, current screen size (the service's own resources can be stale after a rotation). */
    private fun screenSize(): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return intArrayOf(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d?.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    private fun round(color: Int, radiusDp: Float) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = ctx.dp(radiusDp)
        setColor(color)
    }

    fun show() {
        if (root != null) return
        val sw = screenSize()[0]
        val wide = sw / ctx.resources.displayMetrics.density >= 640f
        val r = FrameLayout(ctx)

        // two dark cards, like the phone's own game panel: buttons on top, stats below
        bar = LinearLayout(ctx).apply { orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        val gridCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(10f), dpi(8f), dpi(10f), dpi(10f))
            background = round(0xF2121828.toInt(), 16f)
        }

        // ---- header: grip, title, minimize ----
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(View(ctx).apply {
            background = round(0x66FFFFFF, 2f)
        }, LinearLayout.LayoutParams(dpi(20f), dpi(3f)))
        head.addView(TextView(ctx).apply {
            text = "GAME SPACE"; textSize = 10f; setTextColor(GS.CYAN)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC); letterSpacing = 0.15f
            setPadding(dpi(8f), 0, 0, 0)
        })
        head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        val minBtn = ctx.icon(R.drawable.ic_minus, 16f, GS.WHITE).apply {
            setPadding(dpi(5f), dpi(5f), dpi(5f), dpi(5f))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66444C78) }
            setOnClickListener { setMinimized(true) }
        }
        head.addView(minBtn, LinearLayout.LayoutParams(dpi(26f), dpi(26f)))
        gridCard.addView(head)

        // ---- round tool buttons ----
        brightBtn = ToolButton(ctx, R.drawable.ic_sun, "Brightness")
        dndBtn = ToolButton(ctx, R.drawable.ic_bell_off, "Block notif")
        muteBtn = ToolButton(ctx, R.drawable.ic_phone_off, "Mute calls")
        lockBtn = ToolButton(ctx, R.drawable.ic_lock, "Lock touch")
        crossBtn = ToolButton(ctx, R.drawable.ic_crosshair, "Crosshair")
        zoomBtn = ToolButton(ctx, R.drawable.ic_zoom, "Zoom")
        recBtn = ToolButton(ctx, R.drawable.ic_record, "Record")
        waBtn = ToolButton(ctx, R.drawable.ic_chat, "WhatsApp")
        brightBtn.setOnClickListener { toggleBrightness() }
        dndBtn.setOnClickListener { toggleDnd() }
        muteBtn.setOnClickListener { toggleMute() }
        lockBtn.setOnClickListener { gated { lock() } }
        crossBtn.setOnClickListener { gated { cycleCrosshair() } }
        zoomBtn.setOnClickListener { cycleZoom() }
        recBtn.setOnClickListener { toggleRecord() }
        waBtn.setOnClickListener { gated { openWhatsApp() } }
        if (!pro) { lockBtn.setLocked(true); crossBtn.setLocked(true); waBtn.setLocked(true) }
        RecordState.watermark = !pro
        // keep the on/off look after a re-layout
        dndBtn.setOn(dndActive); muteBtn.setOn(muteCalls); crossBtn.setOn(crossStyle != 0)
        zoomBtn.setOn(zoomIdx != 0); recBtn.setOn(RecordState.recording)

        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        listOf(brightBtn, dndBtn, muteBtn, lockBtn, crossBtn, zoomBtn, recBtn, waBtn).chunked(4).forEachIndexed { n, row ->
            val rl = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (b in row) rl.addView(b, LinearLayout.LayoutParams(dpi(56f), WRAP))
            grid.addView(rl, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(6f) })
        }
        gridCard.addView(grid)

        // ---- brightness slider (opens from the Brightness button) ----
        sliderRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        sliderRow.addView(SeekBar(ctx).apply {
            max = 245
            progress = currentBrightness() - 10
            progressTintList = android.content.res.ColorStateList.valueOf(GS.CYAN)
            thumbTintList = android.content.res.ColorStateList.valueOf(GS.CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) setBrightness(p + 10) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }, LinearLayout.LayoutParams(MATCH, dpi(30f)))
        gridCard.addView(sliderRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(2f) })

        // ---- stats card (deep blue): mode switch, big numbers, small numbers ----
        val stats = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(10f), dpi(8f), dpi(10f), dpi(8f))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF20B1B6E.toInt(), 0xF207104A.toInt())
            ).apply { cornerRadius = ctx.dp(16f) }
        }
        val seg = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0x33FFFFFF, 14f)
            setPadding(dpi(3f), dpi(3f), dpi(3f), dpi(3f))
        }
        for ((key, name) in listOf("ultra" to "Ultra", "balanced" to "Balanced")) {
            val tv = TextView(ctx).apply {
                text = name; textSize = 11f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                setPadding(dpi(4f), dpi(5f), dpi(4f), dpi(5f))
                setOnClickListener { chooseMode(key) }
            }
            modeChips[key] = tv
            seg.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paintMode()
        stats.addView(seg, LinearLayout.LayoutParams(MATCH, WRAP))

        fun bigTile(label: String, unit: String): Pair<LinearLayout, TextView> {
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(ctx).apply { text = label; textSize = 8f; setTextColor(GS.WHITE); letterSpacing = 0.12f; typeface = Typeface.DEFAULT_BOLD })
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
            val v = TextView(ctx).apply {
                text = "--"; textSize = 22f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
                setTypeface(typeface, Typeface.BOLD)
            }
            row.addView(v)
            row.addView(TextView(ctx).apply { text = unit; textSize = 10f; setTextColor(GS.TEXT_SECONDARY); setPadding(dpi(3f), 0, 0, dpi(3f)) })
            col.addView(row)
            return col to v
        }
        val (batTile, bv) = bigTile("BATTERY", "%")
        val (netTile, nv) = bigTile("NETWORK", "ms")
        batteryVal = bv; netVal = nv
        val big = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        big.addView(batTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        big.addView(netTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        stats.addView(big, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(6f) })

        fun smallTile(label: String): Pair<LinearLayout, TextView> {
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(ctx).apply { text = label; textSize = 8f; setTextColor(GS.TEXT_SECONDARY); typeface = Typeface.DEFAULT_BOLD })
            val v = TextView(ctx).apply { text = "--"; textSize = 11f; setTextColor(GS.WHITE); typeface = Typeface.MONOSPACE }
            col.addView(v)
            return col to v
        }
        val (ramTile, rv) = smallTile("RAM")
        val (tempTile, tv2) = smallTile("TEMP")
        val (hzTile, hv) = smallTile("DISPLAY")
        ramVal = rv; tempVal = tv2; hzVal = hv
        val small = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        small.addView(ramTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        small.addView(tempTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        small.addView(hzTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        stats.addView(small, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(4f) })

        bar.addView(gridCard)
        bar.addView(stats, LinearLayout.LayoutParams(if (wide) dpi(210f) else MATCH, WRAP).apply {
            if (wide) marginStart = dpi(6f) else topMargin = dpi(6f)
        })

        dot = GlowDot(ctx).apply { visibility = View.GONE }
        r.addView(bar)
        r.addView(dot)

        val sh = screenSize()[1]
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (lastX >= 0) lastX.coerceIn(0, maxOf(0, sw - ctx.dpi(46f))) else maxOf(0, sw - ctx.dpi(46f))
            y = if (lastY >= 0) lastY.coerceIn(0, maxOf(0, sh - ctx.dpi(60f))) else ctx.dpi(110f)
        }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > ctx.dp(6f) || abs(dy) > ctx.dp(6f)) moved = true
                    if (moved) {
                        userMoved = true
                        lp.x = (ox + dx).toInt().coerceAtLeast(0)
                        lp.y = (oy + dy).toInt().coerceAtLeast(0)
                        try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    lastX = lp.x; lastY = lp.y
                    if (!moved && minimized) setMinimized(false)
                    true
                }
                MotionEvent.ACTION_OUTSIDE -> { if (!minimized) setMinimized(true); false }   // tap the game = panel folds away
                else -> false
            }
        }

        try {
            wm.addView(r, lp)
            root = r
            RecordState.listener = { on -> handler.post { onRecordChanged(on) } }
            setMinimized(true)          // starts as a small glowing dot; tap it to open the panel
        } catch (e: Exception) { /* could not add window */ }
    }

    /** Rebuilds the panel for the new screen shape after a rotation. Keeps every setting as it is. */
    fun relayout() {
        val r = root ?: return
        val wasMin = minimized
        try { wm.removeView(r) } catch (_: Exception) {}
        root = null
        modeChips.clear()
        show()
        if (!wasMin) setMinimized(false)
        if (lockView != null || RecordState.recording) root?.visibility = View.GONE
    }

    /** Keeps the panel fully on screen; by default it sits at the right edge. */
    private fun fitOnScreen() {
        val r = root ?: return
        val size = screenSize()
        val w = r.width
        val h = r.height
        lp.x = if (!userMoved) maxOf(0, size[0] - w - (if (minimized) 0 else ctx.dpi(6f)))
               else lp.x.coerceIn(0, maxOf(0, size[0] - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, size[1] - h))
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
    }

    private fun paintMode() {
        for ((key, tv) in modeChips) {
            val on = key == curMode
            tv.setTextColor(if (on) 0xFF04202B.toInt() else GS.WHITE)
            tv.background = if (on) GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE; cornerRadius = ctx.dp(12f); setColor(0xFF00E5FF.toInt())
            } else null
        }
    }

    private fun chooseMode(m: String) {
        curMode = m
        paintMode()
        onMode(m)
        if (m == "ultra") applyUltra() else if (dndActive) setDnd(false)
    }

    fun hide() {
        stopHud()
        try { io.shutdownNow() } catch (_: Exception) {}
        handler.removeCallbacks(unlockRun)
        lockView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        lockView = null
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        resetZoom()
        RecordState.listener = null
        if (RecordState.recording) ScreenRecordService.stop()
        removeWatermark()
        crosshair.hide()
        if (dndActive) setDnd(false)
        restoreBrightness()
    }

    private fun setMinimized(min: Boolean) {
        minimized = min
        bar.visibility = if (min) View.GONE else View.VISIBLE
        dot.visibility = if (min) View.VISIBLE else View.GONE
        if (min) stopHud() else { updateHud(); startHud() }
        root?.post { fitOnScreen() }
    }

    // ---------- HUD (only ticks while the toolbar is expanded) ----------

    private fun gated(action: () -> Unit) {
        if (pro) action()
        else Toast.makeText(ctx, "Pro feature. Donate in Game Space to switch it on.", Toast.LENGTH_SHORT).show()
    }

    private fun startHud() { if (!hudRunning && !minimized && lockView == null) { hudRunning = true; handler.postDelayed(hudTick, 2000) } }
    private fun stopHud() { hudRunning = false; handler.removeCallbacks(hudTick) }

    private fun updateHud() {
        // battery + network are free; RAM, temperature and display are Pro
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        batteryVal.text = if (level < 0 || scale <= 0) "--" else "${level * 100 / scale}"
        try {
            io.execute {
                val ms = pingOnce()
                handler.post { if (root != null) netVal.text = if (ms > 0) "$ms" else "--" }
            }
        } catch (_: Exception) {}

        if (!pro) { ramVal.text = "PRO"; tempVal.text = "PRO"; hzVal.text = "PRO"; return }
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = 1073741824.0
        ramVal.text = String.format(Locale.US, "%.1f/%dG", (mi.totalMem - mi.availMem) / gb, Math.round(mi.totalMem / gb).toInt())
        val t = cpuTemp() ?: ((bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f).takeIf { it > 0f }
        tempVal.text = if (t != null) "${Math.round(t)}\u00B0C" else "--"
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        hzVal.text = "${Math.round(dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f)}Hz"
    }

    private fun pingOnce(): Int = try {
        Socket().use { s ->
            val t = SystemClock.elapsedRealtime()
            s.connect(InetSocketAddress("1.1.1.1", 443), 1200)
            (SystemClock.elapsedRealtime() - t).toInt()
        }
    } catch (e: Exception) { -1 }

    private fun cpuTemp(): Float? {
        var best: Float? = null
        for (f in cpuZones) {
            try {
                val raw = f.readText().trim().toFloatOrNull() ?: continue
                val c = if (raw > 1000f) raw / 1000f else raw
                if (c in 10f..120f) best = maxOf(best ?: 0f, c)
            } catch (_: Exception) {}
        }
        return best
    }

    // ---------- block notifications ----------

    fun enableBlockNotifications() { if (!dndActive && nm.isNotificationPolicyAccessGranted) setDnd(true) }

    private fun toggleDnd() { setDnd(!dndActive) }

    /** Muting calls works through Do Not Disturb, so it switches Block notifications on too. */
    private fun toggleMute() {
        muteCalls = !muteCalls
        if (muteCalls) {
            if (!dndActive) setDnd(true) else applyPolicy()
            if (!dndActive) muteCalls = false
        } else if (dndActive) {
            applyPolicy()
        }
        if (root != null) muteBtn.setOn(muteCalls)
    }

    private fun applyPolicy() {
        val vis = if (Build.VERSION.SDK_INT >= 28) NotificationManager.Policy.SUPPRESSED_EFFECT_PEEK
                  else NotificationManager.Policy.SUPPRESSED_EFFECT_SCREEN_ON
        val cats = NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS or
            (if (muteCalls) 0 else NotificationManager.Policy.PRIORITY_CATEGORY_CALLS) or
            (if (Build.VERSION.SDK_INT >= 28) NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA else 0)
        nm.notificationPolicy = NotificationManager.Policy(cats, NotificationManager.Policy.PRIORITY_SENDERS_ANY, 0, vis)
    }

    private fun setDnd(on: Boolean) {
        try {
            if (on) {
                if (!nm.isNotificationPolicyAccessGranted) {
                    openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                    return
                }
                prevFilter = nm.currentInterruptionFilter
                prevPolicy = nm.notificationPolicy
                applyPolicy()
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                dndActive = true
            } else {
                nm.setInterruptionFilter(prevFilter)
                prevPolicy?.let { nm.notificationPolicy = it }
                dndActive = false
                muteCalls = false
            }
        } catch (e: Exception) { dndActive = false; muteCalls = false }
        if (root != null) { dndBtn.setOn(dndActive); muteBtn.setOn(muteCalls) }
    }

    /** Ultra mode: block notifications and mute calls (only if Do Not Disturb access was already granted). */
    fun applyUltra() {
        if (!nm.isNotificationPolicyAccessGranted) return
        if (!dndActive) setDnd(true)
        if (dndActive && !muteCalls) {
            muteCalls = true
            try { applyPolicy() } catch (_: Exception) { muteCalls = false }
            if (root != null) muteBtn.setOn(muteCalls)
        }
    }

    // ---------- crosshair ----------

    private fun cycleCrosshair() {
        crossStyle = (crossStyle + 1) % (CrosshairView.STYLES + 1)
        if (crossStyle == 0) {
            crosshair.hide()
            Toast.makeText(ctx, "Crosshair off", Toast.LENGTH_SHORT).show()
        } else {
            crosshair.show(crossStyle - 1)
            Toast.makeText(ctx, "Crosshair $crossStyle/${CrosshairView.STYLES}", Toast.LENGTH_SHORT).show()
        }
        crossBtn.setOn(crossStyle != 0)
    }

    // ---------- screen record ----------

    private fun toggleRecord() {
        if (RecordState.recording) {
            ScreenRecordService.stop()
        } else {
            try {
                ctx.startActivity(Intent(ctx, RecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }
    }

    /** While recording, the toolbar hides itself so it is not in the video. Stop from the notification. */
    private fun onRecordChanged(on: Boolean) {
        if (root == null) return
        recBtn.setOn(on)
        if (lockView == null) root?.visibility = if (on) View.GONE else View.VISIBLE
        if (on && RecordState.watermark) showWatermark() else removeWatermark()
    }

    private fun showWatermark() {
        if (watermarkView != null) return
        val v = TextView(ctx).apply {
            text = "GAME SPACE"
            textSize = 11f
            setTextColor(0xB300F5FF.toInt())
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(ctx.dp(4f), 0f, 0f, 0xFF000000.toInt())
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = ctx.dpi(16f); y = ctx.dpi(12f) }
        try { wm.addView(v, p); watermarkView = v } catch (_: Exception) {}
    }

    private fun removeWatermark() {
        watermarkView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        watermarkView = null
    }

    // ---------- zoom (bigger game picture) ----------

    /** Magnifies the whole display around its centre. Touches still reach the game correctly. */
    private fun cycleZoom() {
        val mc = (ctx as? android.accessibilityservice.AccessibilityService)?.magnificationController
        if (mc == null) {
            Toast.makeText(ctx, "Zoom is not supported on this phone", Toast.LENGTH_SHORT).show()
            return
        }
        zoomIdx = (zoomIdx + 1) % zoomLevels.size
        val scale = zoomLevels[zoomIdx]
        try {
            if (scale <= 1.0f) {
                mc.reset(true)
            } else {
                val dm = ctx.resources.displayMetrics
                mc.setScale(scale, true)
                mc.setCenter(dm.widthPixels / 2f, dm.heightPixels / 2f, true)
            }
            Toast.makeText(ctx, if (scale <= 1.0f) "Zoom off" else "Zoom ${Math.round(scale * 100)}%", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            zoomIdx = 0
            Toast.makeText(ctx, "Zoom is not supported on this phone", Toast.LENGTH_SHORT).show()
        }
        zoomBtn.setOn(zoomIdx != 0)
    }

    private fun resetZoom() {
        if (zoomIdx == 0) return
        try { (ctx as? android.accessibilityservice.AccessibilityService)?.magnificationController?.reset(true) } catch (_: Exception) {}
        zoomIdx = 0
    }

    // ---------- WhatsApp ----------

    private fun openWhatsApp() {
        val pm = ctx.packageManager
        val i = pm.getLaunchIntentForPackage("com.whatsapp") ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
        if (i == null) {
            Toast.makeText(ctx, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
        } else {
            try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    // ---------- brightness ----------

    private fun currentBrightness(): Int =
        try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }.coerceIn(10, 255)

    private fun toggleBrightness() {
        if (!Settings.System.canWrite(ctx)) {
            openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
            return
        }
        val show = sliderRow.visibility != View.VISIBLE
        sliderRow.visibility = if (show) View.VISIBLE else View.GONE
        brightBtn.setOn(show)
        root?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
    }

    private fun setBrightness(v: Int) {
        try {
            if (origBrightness < 0) {
                origBrightness = currentBrightness()
                origMode = Settings.System.getInt(
                    ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
            }
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(10, 255))
        } catch (_: Exception) {}
    }

    private fun restoreBrightness() {
        if (origBrightness < 0) return
        try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, origBrightness)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, origMode)
        } catch (_: Exception) {}
        origBrightness = -1
    }

    // ---------- touch lock ----------

    private fun lock() {
        if (lockView != null) return
        val v = FrameLayout(ctx).apply {
            setBackgroundColor(0x01000000)
            setOnTouchListener { _, _ -> true }
        }
        v.addView(TextView(ctx).apply {
            text = "TOUCH LOCKED"
            textSize = 10f
            setTextColor(GS.CYAN)
            typeface = Typeface.MONOSPACE
            letterSpacing = 0.15f
            setPadding(dpi(14f), dpi(5f), dpi(14f), dpi(5f))
            glass(cornerDp = 14f, fill = 0xCC0A0E1E.toInt(), stroke = 0x8800F5FF.toInt())
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dpi(10f) })

        val unlockBtn = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            glass(cornerDp = 30f, fill = 0xCC0A0E1E.toInt(), stroke = 0xAA00F5FF.toInt())
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { handler.postDelayed(unlockRun, 1000); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(unlockRun); true }
                    else -> true
                }
            }
        }
        unlockBtn.addView(ctx.icon(R.drawable.ic_lock, 20f, GS.CYAN))
        unlockBtn.addView(TextView(ctx).apply {
            text = "HOLD"; textSize = 8f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
        })
        v.addView(unlockBtn, FrameLayout.LayoutParams(dpi(60f), dpi(60f), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dpi(20f), dpi(20f))
        })

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, p)
            lockView = v
            root?.visibility = View.GONE
            stopHud()
        } catch (_: Exception) {}
    }

    private fun unlock() {
        lockView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        lockView = null
        root?.visibility = View.VISIBLE
        if (!minimized) { updateHud(); startHud() }
    }

    private fun openSettings(action: String, uri: Uri?) {
        try {
            val i = Intent(action)
            if (uri != null) i.data = uri
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            Toast.makeText(ctx, "Allow Game Space, then go back to your game", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {}
    }
}
