package com.axxxcell.gamespace

import android.app.ActivityManager
import android.util.DisplayMetrics
import android.app.NotificationManager
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.axxxcell.gamespace.ui.*
import java.io.File
import kotlin.math.abs

/** Small round dot shown when the panel is folded. Flat, no glow. */
class GameDot(ctx: Context) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE61B2447.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(2f); color = 0xFF00C8E0.toInt()
    }
    private val icon = androidx.core.content.ContextCompat.getDrawable(ctx, R.drawable.ic_games)?.mutate()?.apply { setTint(GS.WHITE) }

    override fun onMeasure(w: Int, h: Int) {
        val sz = context.dpi(54f)
        setMeasuredDimension(sz, sz)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - context.dp(2f)
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, ring)
        icon?.let {
            val half = (width * 0.25f).toInt()
            it.setBounds(cx.toInt() - half, cy.toInt() - half, cx.toInt() + half, cy.toInt() + half)
            it.draw(c)
        }
    }
}

/** Round tool button with a caption. ON = filled cyan circle. Pro-only buttons get a small lock badge. */
class ToolButton(ctx: Context, iconRes: Int, caption: String) : LinearLayout(ctx) {
    private val icon: ImageView = ctx.icon(iconRes, 20f, GS.WHITE)
    private val circle = FrameLayout(ctx)
    private val badge: ImageView = ctx.icon(R.drawable.ic_lock, 11f, GS.CYAN)
    private val cap = TextView(ctx)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        circle.addView(icon, FrameLayout.LayoutParams(dpi(20f), dpi(20f), Gravity.CENTER))
        circle.addView(badge, FrameLayout.LayoutParams(dpi(11f), dpi(11f), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dpi(3f), dpi(3f), 0)
        })
        badge.visibility = GONE
        addView(circle, LinearLayout.LayoutParams(dpi(40f), dpi(40f)))
        cap.apply { text = caption; textSize = 8f; gravity = Gravity.CENTER; maxLines = 1 }
        addView(cap, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(2f) })
        setOn(false)
    }

    fun setLocked(l: Boolean) {
        badge.visibility = if (l) VISIBLE else GONE
        icon.alpha = if (l) 0.45f else 1f
    }

    fun setOn(on: Boolean) {
        circle.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) 0xFF00E5FF.toInt() else 0x66444C78)
            setStroke(dpi(1f), if (on) 0xFF00F5FF.toInt() else 0x33FFFFFF)
        }
        icon.setColorFilter(if (on) 0xFF04202B.toInt() else GS.WHITE)
        cap.setTextColor(if (on) GS.CYAN else GS.TEXT_SECONDARY)
    }
}

/**
 * Draggable in-game toolbar, shown as an accessibility overlay while a game session is active.
 * Contents: display refresh + temperatures, brightness slider, block notifications, touch lock, minimize.
 */
class GameToolbar(
    private val ctx: Context,
    private val wm: WindowManager,
    private val handler: Handler,
    private val pro: Boolean,
    private val initialMode: String,
    private val onMode: (String) -> Unit,
    private val onCool: () -> Unit
) {
    companion object {
        private var lastX = -1
        private var lastY = -1
    }

    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun dpi(v: Float): Int = ctx.dpi(v)

    private var root: FrameLayout? = null            // the panel (its own window)
    private var dotWin: GameDot? = null              // the dot (its own, tiny window)
    private lateinit var dotLp: WindowManager.LayoutParams
    private var panelAttached = false
    private var dotAttached = false
    private var panelWidthPx = 0
    private var lockView: FrameLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bar: LinearLayout
    private lateinit var batteryVal: TextView
    private lateinit var netVal: TextView
    private lateinit var ramVal: TextView
    private lateinit var tempVal: TextView
    private lateinit var hzVal: TextView
    private val modeChips = HashMap<String, TextView>()
    private var curMode = initialMode
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    private lateinit var sliderRow: LinearLayout
    private lateinit var brightBtn: ToolButton
    private lateinit var dndBtn: ToolButton
    private lateinit var lockBtn: ToolButton
    private lateinit var muteBtn: ToolButton
    private lateinit var crossBtn: ToolButton
    private lateinit var recBtn: ToolButton
    private lateinit var waBtn: ToolButton
    private lateinit var coolBtn: ToolButton
    private val crosshair = CrosshairOverlay(ctx, wm)
    private var crossStyle = 0            // 0 = off, 1..10 = style
    private var muteCalls = false
    private var watermarkView: View? = null

    private var minimized = false
    private var hudRunning = false

    // block notifications state
    private var dndActive = false
    private var prevFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var prevPolicy: NotificationManager.Policy? = null

    // brightness state
    private var origBrightness = -1
    private var origMode = -1

    private val hudTick = object : Runnable {
        override fun run() {
            if (!hudRunning) return
            updateHud()
            handler.postDelayed(this, 2000)
        }
    }
    private val unlockRun = Runnable { unlock() }

    private val cpuZones: List<File> by lazy {
        try {
            File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
                ?.filter {
                    val t = try { File(it, "type").readText().trim().lowercase() } catch (e: Exception) { "" }
                    t.contains("cpu") || t.contains("soc") || t.contains("tsens")
                }
                ?.map { File(it, "temp") } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    // ---------- show / hide ----------

    /** Real, current screen size (the service's own resources can be stale after a rotation). */
    private fun screenSize(): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return intArrayOf(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d?.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    private fun round(color: Int, radiusDp: Float) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = ctx.dp(radiusDp)
        setColor(color)
    }

    fun show() {
        if (root != null) return
        val sw = screenSize()[0]
        val wide = sw / ctx.resources.displayMetrics.density >= 640f
        val r = FrameLayout(ctx)

        // two dark cards, like the phone's own game panel: buttons on top, stats below
        bar = LinearLayout(ctx).apply { orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        val gridCard = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(10f), dpi(8f), dpi(10f), dpi(10f))
            background = round(0xF2121828.toInt(), 16f)
        }

        // ---- header: grip, title, minimize ----
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(View(ctx).apply {
            background = round(0x66FFFFFF, 2f)
        }, LinearLayout.LayoutParams(dpi(20f), dpi(3f)))
        head.addView(TextView(ctx).apply {
            text = "GAME SPACE"; textSize = 10f; setTextColor(GS.CYAN)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC); letterSpacing = 0.15f
            setPadding(dpi(8f), 0, 0, 0)
        })
        head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        val minBtn = ctx.icon(R.drawable.ic_minus, 16f, GS.WHITE).apply {
            setPadding(dpi(5f), dpi(5f), dpi(5f), dpi(5f))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66444C78) }
            setOnClickListener { setMinimized(true) }
        }
        head.addView(minBtn, LinearLayout.LayoutParams(dpi(26f), dpi(26f)))
        gridCard.addView(head)

        // ---- round tool buttons ----
        brightBtn = ToolButton(ctx, R.drawable.ic_sun, "Brightness")
        dndBtn = ToolButton(ctx, R.drawable.ic_bell_off, "Block notif")
        muteBtn = ToolButton(ctx, R.drawable.ic_phone_off, "Mute calls")
        lockBtn = ToolButton(ctx, R.drawable.ic_lock, "Lock touch")
        crossBtn = ToolButton(ctx, R.drawable.ic_crosshair, "Crosshair")
        coolBtn = ToolButton(ctx, R.drawable.ic_fan, "Cool down")
        recBtn = ToolButton(ctx, R.drawable.ic_record, "Record")
        waBtn = ToolButton(ctx, R.drawable.ic_chat, "WhatsApp")
        brightBtn.setOnClickListener { toggleBrightness() }
        dndBtn.setOnClickListener { toggleDnd() }
        muteBtn.setOnClickListener { toggleMute() }
        lockBtn.setOnClickListener { gated { lock() } }
        crossBtn.setOnClickListener { gated { cycleCrosshair() } }
        coolBtn.setOnClickListener { coolDown() }
        recBtn.setOnClickListener { toggleRecord() }
        waBtn.setOnClickListener { gated { openWhatsApp() } }
        if (!pro) { lockBtn.setLocked(true); crossBtn.setLocked(true); waBtn.setLocked(true) }
        RecordState.watermark = !pro
        // keep the on/off look after a re-layout
        dndBtn.setOn(dndActive); muteBtn.setOn(muteCalls); crossBtn.setOn(crossStyle != 0)
        recBtn.setOn(RecordState.recording)

        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        listOf(brightBtn, dndBtn, muteBtn, lockBtn, crossBtn, coolBtn, recBtn, waBtn).chunked(4).forEachIndexed { n, row ->
            val rl = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (b in row) rl.addView(b, LinearLayout.LayoutParams(dpi(52f), WRAP))
            grid.addView(rl, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(6f) })
        }
        gridCard.addView(grid)

        // ---- brightness slider (opens from the Brightness button) ----
        sliderRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        sliderRow.addView(SeekBar(ctx).apply {
            max = 245
            progress = currentBrightness() - 10
            progressTintList = android.content.res.ColorStateList.valueOf(GS.CYAN)
            thumbTintList = android.content.res.ColorStateList.valueOf(GS.CYAN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) setBrightness(p + 10) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }, LinearLayout.LayoutParams(MATCH, dpi(30f)))
        gridCard.addView(sliderRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(2f) })

        // ---- stats card (deep blue): mode switch, big numbers, small numbers ----
        val stats = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(10f), dpi(8f), dpi(10f), dpi(8f))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF20B1B6E.toInt(), 0xF207104A.toInt())
            ).apply { cornerRadius = ctx.dp(16f) }
        }
        val seg = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0x33FFFFFF, 14f)
            setPadding(dpi(3f), dpi(3f), dpi(3f), dpi(3f))
        }
        for ((key, name) in listOf("ultra" to "Ultra", "balanced" to "Balanced")) {
            val tv = TextView(ctx).apply {
                text = name; textSize = 11f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                setPadding(dpi(4f), dpi(5f), dpi(4f), dpi(5f))
                setOnClickListener { chooseMode(key) }
            }
            modeChips[key] = tv
            seg.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paintMode()
        stats.addView(seg, LinearLayout.LayoutParams(MATCH, WRAP))

        fun bigTile(label: String, unit: String): Pair<LinearLayout, TextView> {
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(ctx).apply { text = label; textSize = 8f; setTextColor(GS.WHITE); letterSpacing = 0.12f; typeface = Typeface.DEFAULT_BOLD })
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
            val v = TextView(ctx).apply {
                text = "--"; textSize = 22f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
                setTypeface(typeface, Typeface.BOLD)
            }
            row.addView(v)
            row.addView(TextView(ctx).apply { text = unit; textSize = 10f; setTextColor(GS.TEXT_SECONDARY); setPadding(dpi(3f), 0, 0, dpi(3f)) })
            col.addView(row)
            return col to v
        }
        val (batTile, bv) = bigTile("BATTERY", "%")
        val (netTile, nv) = bigTile("NETWORK", "ms")
        batteryVal = bv; netVal = nv
        val big = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        big.addView(batTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        big.addView(netTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        stats.addView(big, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(6f) })

        fun smallTile(label: String): Pair<LinearLayout, TextView> {
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(ctx).apply { text = label; textSize = 8f; setTextColor(GS.TEXT_SECONDARY); typeface = Typeface.DEFAULT_BOLD })
            val v = TextView(ctx).apply { text = "--"; textSize = 11f; setTextColor(GS.WHITE); typeface = Typeface.MONOSPACE }
            col.addView(v)
            return col to v
        }
        val (ramTile, rv) = smallTile("RAM")
        val (tempTile, tv2) = smallTile("TEMP")
        val (hzTile, hv) = smallTile("DISPLAY")
        ramVal = rv; tempVal = tv2; hzVal = hv
        val small = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        small.addView(ramTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        small.addView(tempTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        small.addView(hzTile, LinearLayout.LayoutParams(0, WRAP, 1f))
        stats.addView(small, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(4f) })

        bar.addView(gridCard)
        bar.addView(stats, LinearLayout.LayoutParams(if (wide) dpi(200f) else MATCH, WRAP).apply {
            if (wide) marginStart = dpi(6f) else topMargin = dpi(6f)
        })

        panelWidthPx = dpi(if (wide) 440f else 232f)
        r.addView(bar, FrameLayout.LayoutParams(panelWidthPx, WRAP))

        val sh = screenSize()[1]
        val dotSize = ctx.dpi(54f)
        // GPU drawing is switched on explicitly: overlay windows are otherwise drawn by the CPU, which is what made this laggy
        lp = WindowManager.LayoutParams(
            panelWidthPx, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        dotLp = WindowManager.LayoutParams(
            dotSize, dotSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (lastX >= 0 && lastX + dotSize / 2 < sw / 2) 0 else sw - dotSize
            y = if (lastY >= 0) lastY.coerceIn(0, maxOf(0, sh - dotSize)) else ctx.dpi(110f)
        }

        // panel: drag it by empty areas; touching the game folds it away
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > ctx.dp(6f) || abs(dy) > ctx.dp(6f)) moved = true
                    if (moved) {
                        lp.x = (ox + dx).toInt().coerceIn(0, maxOf(0, sw - panelWidthPx))
                        lp.y = (oy + dy).toInt().coerceAtLeast(0)
                        updatePanel()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> true
                MotionEvent.ACTION_OUTSIDE -> { if (!minimized) setMinimized(true); false }
                else -> false
            }
        }

        // dot: tap to open, drag anywhere, it snaps to the nearest side when released
        val d = GameDot(ctx)
        var dsx = 0f; var dsy = 0f; var dox = 0; var doy = 0; var dmoved = false
        d.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dsx = e.rawX; dsy = e.rawY; dox = dotLp.x; doy = dotLp.y; dmoved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - dsx; val dy = e.rawY - dsy
                    if (abs(dx) > ctx.dp(6f) || abs(dy) > ctx.dp(6f)) dmoved = true
                    if (dmoved) {
                        dotLp.x = (dox + dx).toInt().coerceIn(0, maxOf(0, sw - dotSize))
                        dotLp.y = (doy + dy).toInt().coerceIn(0, maxOf(0, sh - dotSize))
                        updateDot()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (dmoved) snapDot() else setMinimized(false); true }
                else -> false
            }
        }

        try {
            root = r
            dotWin = d
            RecordState.listener = { on -> handler.post { onRecordChanged(on) } }
            minimized = true
            wm.addView(d, dotLp)
            dotAttached = true           // starts as the small dot; tap it to open the panel
        } catch (e: Exception) { root = null; dotWin = null }
    }

    /** Rebuilds the panel for the new screen shape after a rotation. Keeps every setting as it is. */
    fun relayout() {
        if (root == null) return
        val wasMin = minimized
        root?.let { if (panelAttached) try { wm.removeView(it) } catch (_: Exception) {} }
        dotWin?.let { if (dotAttached) try { wm.removeView(it) } catch (_: Exception) {} }
        panelAttached = false; dotAttached = false
        root = null; dotWin = null
        modeChips.clear()
        show()
        if (!wasMin) setMinimized(false)
        if (lockView != null || RecordState.recording) setUiVisible(View.GONE)
    }

    private fun setUiVisible(v: Int) {
        root?.visibility = v
        dotWin?.visibility = v
    }

    private fun updateDot() {
        val d = dotWin ?: return
        if (dotAttached) try { wm.updateViewLayout(d, dotLp) } catch (_: Exception) {}
    }

    private fun updatePanel() {
        val r = root ?: return
        if (panelAttached) try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
    }

    /** After a drag, the dot glides to the nearest side. Only the tiny dot window moves, so it stays smooth. */
    private fun snapDot() {
        val size = screenSize()
        val dotSize = ctx.dpi(54f)
        val targetX = if (dotLp.x + dotSize / 2 < size[0] / 2) 0 else size[0] - dotSize
        val targetY = dotLp.y.coerceIn(0, maxOf(0, size[1] - dotSize))
        lastX = targetX; lastY = targetY
        val fromX = dotLp.x
        val fromY = dotLp.y
        android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 160
            interpolator = android.view.animation.DecelerateInterpolator()
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                dotLp.x = (fromX + (targetX - fromX) * t).toInt()
                dotLp.y = (fromY + (targetY - fromY) * t).toInt()
                updateDot()
            }
            start()
        }
    }

    private fun paintMode() {
        for ((key, tv) in modeChips) {
            val on = key == curMode
            tv.setTextColor(if (on) 0xFF04202B.toInt() else GS.WHITE)
            tv.background = if (on) GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE; cornerRadius = ctx.dp(12f); setColor(0xFF00E5FF.toInt())
            } else null
        }
    }

    private fun chooseMode(m: String) {
        curMode = m
        paintMode()
        onMode(m)
        if (m == "ultra") applyUltra() else if (dndActive) setDnd(false)
    }

    fun hide() {
        stopHud()
        try { io.shutdownNow() } catch (_: Exception) {}
        handler.removeCallbacks(unlockRun)
        lockView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        lockView = null
        root?.let { if (panelAttached) try { wm.removeView(it) } catch (_: Exception) {} }
        dotWin?.let { if (dotAttached) try { wm.removeView(it) } catch (_: Exception) {} }
        panelAttached = false; dotAttached = false
        root = null; dotWin = null
        RecordState.listener = null
        if (RecordState.recording) ScreenRecordService.stop()
        removeWatermark()
        crosshair.hide()
        if (dndActive) setDnd(false)
        restoreBrightness()
    }

    /** Folding removes the big panel window and shows the small dot window; opening does the reverse. */
    private fun setMinimized(min: Boolean) {
        val r = root ?: return
        val d = dotWin ?: return
        val size = screenSize()
        val dotSize = ctx.dpi(54f)
        if (min) {
            minimized = true
            stopHud()
            if (panelAttached) {
                // dock the dot on the same side, at the same height as the panel
                val onRight = lp.x + panelWidthPx / 2 >= size[0] / 2
                dotLp.x = if (onRight) size[0] - dotSize else 0
                dotLp.y = lp.y.coerceIn(0, maxOf(0, size[1] - dotSize))
                lastX = dotLp.x; lastY = dotLp.y
                try { wm.removeView(r) } catch (_: Exception) {}
                panelAttached = false
            }
            if (!dotAttached) {
                try { wm.addView(d, dotLp); dotAttached = true } catch (_: Exception) {}
            } else updateDot()
        } else {
            minimized = false
            // open on the side the dot is docked to, at the dot's height
            r.measure(
                View.MeasureSpec.makeMeasureSpec(panelWidthPx, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(size[1], View.MeasureSpec.AT_MOST)
            )
            val h = r.measuredHeight
            val onRight = dotLp.x + dotSize / 2 >= size[0] / 2
            lp.x = if (onRight) maxOf(0, size[0] - panelWidthPx - ctx.dpi(6f)) else ctx.dpi(6f)
            lp.y = dotLp.y.coerceIn(0, maxOf(0, size[1] - h))
            if (dotAttached) { try { wm.removeView(d) } catch (_: Exception) {}; dotAttached = false }
            if (!panelAttached) {
                try { wm.addView(r, lp); panelAttached = true } catch (_: Exception) {}
            }
            updateHud()
            startHud()
        }
    }

    // ---------- HUD (only ticks while the toolbar is expanded) ----------

    private fun gated(action: () -> Unit) {
        if (pro) action()
        else Toast.makeText(ctx, "Pro feature. Donate in Game Space to switch it on.", Toast.LENGTH_SHORT).show()
    }

    private fun startHud() { if (!hudRunning && !minimized && lockView == null) { hudRunning = true; handler.postDelayed(hudTick, 2000) } }
    private fun stopHud() { hudRunning = false; handler.removeCallbacks(hudTick) }

    private fun updateHud() {
        // battery + network are free; RAM, temperature and display are Pro
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        batteryVal.text = if (level < 0 || scale <= 0) "--" else "${level * 100 / scale}"
        try {
            io.execute {
                val ms = pingOnce()
                handler.post { if (root != null) netVal.text = if (ms > 0) "$ms" else "--" }
            }
        } catch (_: Exception) {}

        if (!pro) { ramVal.text = "PRO"; tempVal.text = "PRO"; hzVal.text = "PRO"; return }
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = 1073741824.0
        ramVal.text = String.format(Locale.US, "%.1f/%dG", (mi.totalMem - mi.availMem) / gb, Math.round(mi.totalMem / gb).toInt())
        val t = cpuTemp() ?: ((bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f).takeIf { it > 0f }
        tempVal.text = if (t != null) "${Math.round(t)}\u00B0C" else "--"
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        hzVal.text = "${Math.round(dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f)}Hz"
    }

    private fun pingOnce(): Int = try {
        Socket().use { s ->
            val t = SystemClock.elapsedRealtime()
            s.connect(InetSocketAddress("1.1.1.1", 443), 1200)
            (SystemClock.elapsedRealtime() - t).toInt()
        }
    } catch (e: Exception) { -1 }

    private fun cpuTemp(): Float? {
        var best: Float? = null
        for (f in cpuZones) {
            try {
                val raw = f.readText().trim().toFloatOrNull() ?: continue
                val c = if (raw > 1000f) raw / 1000f else raw
                if (c in 10f..120f) best = maxOf(best ?: 0f, c)
            } catch (_: Exception) {}
        }
        return best
    }

    // ---------- block notifications ----------

    fun enableBlockNotifications() { if (!dndActive && nm.isNotificationPolicyAccessGranted) setDnd(true) }

    private fun toggleDnd() { setDnd(!dndActive) }

    /** Muting calls works through Do Not Disturb, so it switches Block notifications on too. */
    private fun toggleMute() {
        muteCalls = !muteCalls
        if (muteCalls) {
            if (!dndActive) setDnd(true) else applyPolicy()
            if (!dndActive) muteCalls = false
        } else if (dndActive) {
            applyPolicy()
        }
        if (root != null) muteBtn.setOn(muteCalls)
    }

    private fun applyPolicy() {
        val vis = if (Build.VERSION.SDK_INT >= 28) NotificationManager.Policy.SUPPRESSED_EFFECT_PEEK
                  else NotificationManager.Policy.SUPPRESSED_EFFECT_SCREEN_ON
        val cats = NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS or
            (if (muteCalls) 0 else NotificationManager.Policy.PRIORITY_CATEGORY_CALLS) or
            (if (Build.VERSION.SDK_INT >= 28) NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA else 0)
        nm.notificationPolicy = NotificationManager.Policy(cats, NotificationManager.Policy.PRIORITY_SENDERS_ANY, 0, vis)
    }

    private fun setDnd(on: Boolean) {
        try {
            if (on) {
                if (!nm.isNotificationPolicyAccessGranted) {
                    openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                    return
                }
                prevFilter = nm.currentInterruptionFilter
                prevPolicy = nm.notificationPolicy
                applyPolicy()
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                dndActive = true
            } else {
                nm.setInterruptionFilter(prevFilter)
                prevPolicy?.let { nm.notificationPolicy = it }
                dndActive = false
                muteCalls = false
            }
        } catch (e: Exception) { dndActive = false; muteCalls = false }
        if (root != null) { dndBtn.setOn(dndActive); muteBtn.setOn(muteCalls) }
    }

    /** Mute calls (needs Do Not Disturb access that was already granted). */
    fun enableMuteCalls() {
        if (!nm.isNotificationPolicyAccessGranted) return
        if (!dndActive) setDnd(true)
        if (dndActive && !muteCalls) {
            muteCalls = true
            try { applyPolicy() } catch (_: Exception) { muteCalls = false }
            if (root != null) muteBtn.setOn(muteCalls)
        }
    }

    /** Ultra mode: block notifications and mute calls (only if Do Not Disturb access was already granted). */
    fun applyUltra() {
        if (!nm.isNotificationPolicyAccessGranted) return
        if (!dndActive) setDnd(true)
        if (dndActive && !muteCalls) {
            muteCalls = true
            try { applyPolicy() } catch (_: Exception) { muteCalls = false }
            if (root != null) muteBtn.setOn(muteCalls)
        }
    }

    // ---------- crosshair ----------

    private fun cycleCrosshair() {
        crossStyle = (crossStyle + 1) % (CrosshairView.STYLES + 1)
        if (crossStyle == 0) {
            crosshair.hide()
            Toast.makeText(ctx, "Crosshair off", Toast.LENGTH_SHORT).show()
        } else {
            crosshair.show(crossStyle - 1)
            Toast.makeText(ctx, "Crosshair $crossStyle/${CrosshairView.STYLES}", Toast.LENGTH_SHORT).show()
        }
        crossBtn.setOn(crossStyle != 0)
    }

    // ---------- screen record ----------

    private fun toggleRecord() {
        if (RecordState.recording) {
            ScreenRecordService.stop()
        } else {
            try {
                ctx.startActivity(Intent(ctx, RecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }
    }

    /** While recording, the toolbar hides itself so it is not in the video. Stop from the notification. */
    private fun onRecordChanged(on: Boolean) {
        if (root == null) return
        recBtn.setOn(on)
        if (lockView == null) setUiVisible(if (on) View.GONE else View.VISIBLE)
        if (on && RecordState.watermark) showWatermark() else removeWatermark()
    }

    private fun showWatermark() {
        if (watermarkView != null) return
        val v = TextView(ctx).apply {
            text = "GAME SPACE"
            textSize = 11f
            setTextColor(0xB300F5FF.toInt())
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(ctx.dp(4f), 0f, 0f, 0xFF000000.toInt())
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = ctx.dpi(16f); y = ctx.dpi(12f) }
        try { wm.addView(v, p); watermarkView = v } catch (_: Exception) {}
    }

    private fun removeWatermark() {
        watermarkView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        watermarkView = null
    }

    // ---------- cool down ----------

    /**
     * Closes background apps to reduce load, then the banner shows what was closed and the battery temperature.
     * It cannot cool the hardware by itself.
     */
    private fun coolDown() {
        coolBtn.setOn(true)
        onCool()
        handler.postDelayed({ if (root != null) coolBtn.setOn(false) }, 2500)
    }

    // ---------- WhatsApp ----------

    private fun openWhatsApp() {
        val pm = ctx.packageManager
        val i = pm.getLaunchIntentForPackage("com.whatsapp") ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
        if (i == null) {
            Toast.makeText(ctx, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
        } else {
            try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    // ---------- brightness ----------

    private fun currentBrightness(): Int =
        try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }.coerceIn(10, 255)

    private fun toggleBrightness() {
        if (!Settings.System.canWrite(ctx)) {
            openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
            return
        }
        val show = sliderRow.visibility != View.VISIBLE
        sliderRow.visibility = if (show) View.VISIBLE else View.GONE
        brightBtn.setOn(show)
        root?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
    }

    private fun setBrightness(v: Int) {
        try {
            if (origBrightness < 0) {
                origBrightness = currentBrightness()
                origMode = Settings.System.getInt(
                    ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
            }
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(10, 255))
        } catch (_: Exception) {}
    }

    private fun restoreBrightness() {
        if (origBrightness < 0) return
        try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, origBrightness)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, origMode)
        } catch (_: Exception) {}
        origBrightness = -1
    }

    // ---------- touch lock ----------

    private fun lock() {
        if (lockView != null) return
        val v = FrameLayout(ctx).apply {
            setBackgroundColor(0x01000000)
            setOnTouchListener { _, _ -> true }
        }
        v.addView(TextView(ctx).apply {
            text = "TOUCH LOCKED"
            textSize = 10f
            setTextColor(GS.CYAN)
            typeface = Typeface.MONOSPACE
            letterSpacing = 0.15f
            setPadding(dpi(14f), dpi(5f), dpi(14f), dpi(5f))
            glass(cornerDp = 14f, fill = 0xCC0A0E1E.toInt(), stroke = 0x8800F5FF.toInt())
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dpi(10f) })

        val unlockBtn = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            glass(cornerDp = 30f, fill = 0xCC0A0E1E.toInt(), stroke = 0xAA00F5FF.toInt())
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { handler.postDelayed(unlockRun, 1000); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(unlockRun); true }
                    else -> true
                }
            }
        }
        unlockBtn.addView(ctx.icon(R.drawable.ic_lock, 20f, GS.CYAN))
        unlockBtn.addView(TextView(ctx).apply {
            text = "HOLD"; textSize = 8f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
        })
        v.addView(unlockBtn, FrameLayout.LayoutParams(dpi(60f), dpi(60f), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dpi(20f), dpi(20f))
        })

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(v, p)
            lockView = v
            setUiVisible(View.GONE)
            stopHud()
        } catch (_: Exception) {}
    }

    private fun unlock() {
        lockView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        lockView = null
        setUiVisible(View.VISIBLE)
        if (!minimized) { updateHud(); startHud() }
    }

    private fun openSettings(action: String, uri: Uri?) {
        try {
            val i = Intent(action)
            if (uri != null) i.data = uri
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            Toast.makeText(ctx, "Allow Game Space, then go back to your game", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {}
    }
}
