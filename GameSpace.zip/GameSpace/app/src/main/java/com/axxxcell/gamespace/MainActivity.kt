package com.axxxcell.gamespace

import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.axxxcell.gamespace.data.Flag
import com.axxxcell.gamespace.data.SettingsStore
import com.axxxcell.gamespace.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import android.content.ComponentName
import android.provider.Settings
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.axxxcell.gamespace.data.GameRepository

/** Group 2: futuristic landscape home screen (top bar, stat pills, toggle cards, games area, bottom nav). */
class MainActivity : AppCompatActivity() {

    private lateinit var store: SettingsStore
    private lateinit var ramPill: StatPill
    private lateinit var pingPill: StatPill
    private lateinit var tempPill: StatPill
    private lateinit var netCard: ToggleCard
    private lateinit var autoSwitch: SwitchCompat
    private lateinit var futureDot: PulseDot
    private val toggles = ArrayList<Pair<ToggleCard, Flag>>()
    private lateinit var carousel: GameCarousel
    private lateinit var emptyView: TextView
    private var selectedPkgs: Set<String> = emptySet()
    private val repo by lazy { GameRepository(this) }
    private val handler = Handler(Looper.getMainLooper())
    private var shimmerAnim: ValueAnimator? = null
    private val gamesAdapter by lazy {
        GamesAdapter(onBoost = ::boostGame, onOpen = ::openGame, onRemove = ::askRemove)
    }

    /** Group 3 puts the game carousel in here. */
    lateinit var gamesContainer: FrameLayout
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore(this)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(14f), dpi(6f), dpi(14f), dpi(6f))
        }
        page.addView(buildTopBar(), LinearLayout.LayoutParams(MATCH, dpi(44f)))
        page.addView(buildPills(), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(6f) })
        page.addView(buildToggles(), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(6f) })
        page.addView(buildGames(), LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dpi(6f) })
        page.addView(buildNav(), LinearLayout.LayoutParams(MATCH, dpi(40f)).apply { topMargin = dpi(6f) })
        root.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        bindState()
    }

    override fun onStart() {
        super.onStart()
        futureDot.pulse(true)
        val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply {
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
        handler.postDelayed(shimmerTick, 2000)
        lifecycleScope.launch { showGames(selectedPkgs) }
    }

    override fun onStop() {
        futureDot.pulse(false)
        handler.removeCallbacks(shimmerTick)
        shimmerAnim?.cancel()
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
        super.onStop()
    }

    // ---------- UI builders ----------

    private fun buildTopBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(12f), 0, dpi(12f), 0)
            glass(cornerDp = 16f)
        }
        bar.addView(icon(R.drawable.ic_crosshair, 26f, GS.CYAN))
        bar.addView(TextView(this).apply {
            text = "GAME SPACE"
            textSize = 20f
            setTextColor(GS.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.1f
            setShadowLayer(dp(10f), 0f, 0f, GS.CYAN)
            setPadding(dpi(10f), 0, 0, 0)
        })

        futureDot = PulseDot(this, GS.GREEN_ON)
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(6f), dpi(2f), dpi(10f), dpi(2f))
            glass(cornerDp = 12f, fill = 0x3300FF88, stroke = 0x5500FF88)
        }
        chip.addView(futureDot)
        chip.addView(TextView(this).apply {
            text = "FUTURE MODE ON"
            textSize = 10f
            setTextColor(GS.GREEN_ON)
            typeface = Typeface.DEFAULT_BOLD
        })
        bar.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dpi(12f) })

        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val add = TextView(this).apply {
            text = "+ Add"
            textSize = 13f
            setTextColor(GS.CYAN)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpi(14f), dpi(6f), dpi(14f), dpi(6f))
            glass(cornerDp = 14f)
            setOnClickListener { haptic(); openAddGames() }
        }
        bar.addView(add)

        bar.addView(TextView(this).apply {
            text = "Auto Mode"
            textSize = 12f
            setTextColor(GS.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpi(14f), 0, dpi(6f), 0)
        })
        autoSwitch = SwitchCompat(this).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = android.content.res.ColorStateList(states, intArrayOf(GS.CYAN, GS.TEXT_SECONDARY))
            trackTintList = android.content.res.ColorStateList(states, intArrayOf(0x6600F5FF, 0x33FFFFFF))
            setOnCheckedChangeListener { v, checked ->
                if (v.isPressed) {
                    v.haptic()
                    lifecycleScope.launch { store.setFlag(Flag.AUTO_MODE, checked) }
                    if (checked && !AutoActivationService.isEnabled(this@MainActivity)) showEnableAccessibility()
                }
            }
        }
        bar.addView(autoSwitch)
        return bar
    }

    private fun scrollRow(row: LinearLayout) = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        addView(row)
    }

    private fun buildPills(): View {
        ramPill = StatPill(this, R.drawable.ic_ram, "-- RAM")
        pingPill = StatPill(this, R.drawable.ic_signal, "Ping --")
        tempPill = StatPill(this, R.drawable.ic_temp, "Temp --")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in listOf(ramPill, pingPill, tempPill)) {
            row.addView(p, LinearLayout.LayoutParams(WRAP, dpi(28f)).apply { marginEnd = dpi(8f) })
        }
        return scrollRow(row)
    }

    private fun buildToggles(): View {
        val specs = listOf(
            Triple(R.drawable.ic_games, "Game Mode", Flag.GAME_MODE),
            Triple(R.drawable.ic_shield, "Network Boost", Flag.NET_BOOST),
            Triple(R.drawable.ic_leaf, "Power Save", Flag.POWER_SAVE),
            Triple(R.drawable.ic_bell, "Alerts", Flag.ALERTS)
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((iconRes, name, flag) in specs) {
            val card = ToggleCard(this, iconRes, name)
            card.setOnClickListener {
                card.haptic()
                lifecycleScope.launch { store.setFlag(flag, !card.isOn) }
            }
            if (flag == Flag.NET_BOOST) netCard = card
            toggles.add(card to flag)
            row.addView(card, LinearLayout.LayoutParams(dpi(150f), dpi(56f)).apply { marginEnd = dpi(8f) })
        }
        return scrollRow(row)
    }

    private fun buildGames(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(this).apply {
            text = "GAMES"
            textSize = 12f
            setTextColor(GS.CYAN)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(dp(8f), 0f, 0f, GS.CYAN)
        })
        carousel = GameCarousel(this).apply { adapter = gamesAdapter }
        emptyView = TextView(this).apply {
            text = "No games yet\nTap + Add to choose your games"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(GS.TEXT_SECONDARY)
            glass(cornerDp = 18f)
        }
        gamesContainer = FrameLayout(this)
        gamesContainer.addView(carousel, FrameLayout.LayoutParams(MATCH, MATCH).apply { topMargin = dpi(4f) })
        gamesContainer.addView(emptyView, FrameLayout.LayoutParams(MATCH, MATCH).apply { topMargin = dpi(4f) })
        box.addView(gamesContainer, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    private fun buildNav(): View = BottomNav(
        this,
        listOf(
            R.drawable.ic_home to "Home",
            R.drawable.ic_stats to "Stats",
            R.drawable.ic_games to "Games",
            R.drawable.ic_rocket to "Boost",
            R.drawable.ic_settings to "Settings"
        )
    ) { index ->
        if (index != 0) Toast.makeText(this, "This page is coming in a later group", Toast.LENGTH_SHORT).show()
    }

    private fun icon(res: Int, sizeDp: Float, color: Int) = (this as android.content.Context).icon(res, sizeDp, color)

    // ---------- state + live stats (only while the screen is visible) ----------

    private fun bindState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { store.flag(Flag.AUTO_MODE).collect { if (autoSwitch.isChecked != it) autoSwitch.isChecked = it } }
                launch { store.games.collect { showGames(it) } }
                for ((card, flag) in toggles) {
                    launch { store.flag(flag).collect { card.setOn(it) } }
                }
                launch {
                    while (isActive) {
                        updateRamAndTemp()
                        val ms = measurePing()
                        updatePing(ms)
                        delay(3000)
                    }
                }
            }
        }
    }

    private fun updateRamAndTemp() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = 1073741824.0
        val used = (mi.totalMem - mi.availMem) / gb
        val total = Math.round(mi.totalMem / gb).toInt()
        ramPill.setText(String.format(Locale.US, "%.1fGB/%dGB RAM", used, total))

        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val state = when {
            t <= 0f -> ""
            t < 40f -> " Optimal"
            t < 45f -> " Warm"
            else -> " Hot"
        }
        tempPill.setText(if (t > 0f) String.format(Locale.US, "Temp %.0f°C%s", t, state) else "Temp --")
    }

    private suspend fun measurePing(): Int = withContext(Dispatchers.IO) {
        try {
            Socket().use { s ->
                val start = SystemClock.elapsedRealtime()
                s.connect(InetSocketAddress("1.1.1.1", 443), 1500)
                (SystemClock.elapsedRealtime() - start).toInt()
            }
        } catch (e: Exception) {
            -1
        }
    }

    private fun updatePing(ms: Int) {
        if (ms > 0) {
            val q = when {
                ms < 60 -> "Stable"
                ms < 120 -> "Fair"
                else -> "High"
            }
            pingPill.setText("Ping ${ms}ms $q")
            netCard.setValue("${ms}ms")
        } else {
            pingPill.setText("Ping --")
            netCard.setValue(null)
        }
    }

    // ---------- games ----------

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pkg = i.data?.schemeSpecificPart ?: return
            if (i.action == Intent.ACTION_PACKAGE_ADDED) {
                if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                lifecycleScope.launch {
                    val app = withContext(Dispatchers.IO) { repo.load(pkg) }
                    if (app != null && app.isGame) {
                        Toast.makeText(this@MainActivity, "New game detected: ${app.label}. Tap + Add", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                repo.forget(pkg)
                lifecycleScope.launch { showGames(selectedPkgs) }
            }
        }
    }

    private val shimmerTick = object : Runnable {
        override fun run() {
            shimmerAnim?.cancel()
            shimmerAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 900
                addUpdateListener { carousel.setShimmer(it.animatedValue as Float) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) { carousel.setShimmer(0f) }
                })
                start()
            }
            handler.postDelayed(this, 5000)
        }
    }

    private suspend fun showGames(pkgs: Set<String>) {
        selectedPkgs = pkgs
        val list = withContext(Dispatchers.IO) {
            pkgs.mapNotNull { repo.load(it) }.sortedBy { it.label.lowercase() }
        }
        gamesAdapter.submit(list)
        val empty = list.isEmpty()
        emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        carousel.visibility = if (empty) View.GONE else View.VISIBLE
    }

    private fun openAddGames() {
        lifecycleScope.launch {
            val apps = repo.launchableApps()
            AddGamesDialog.show(this@MainActivity, apps, selectedPkgs) { chosen ->
                lifecycleScope.launch { store.setGames(chosen) }
            }
        }
    }

    private fun boostGame(app: GameRepository.App, card: GameCardView) {
        card.burst()
        gamesAdapter.setActive(app.pkg)
        lifecycleScope.launch {
            delay(700)
            openGame(app)
        }
    }

    private fun openGame(app: GameRepository.App) {
        val i = packageManager.getLaunchIntentForPackage(app.pkg)
        if (i != null) startActivity(i)
        else Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
    }

    private fun askRemove(app: GameRepository.App) {
        AlertDialog.Builder(this)
            .setTitle("Remove ${app.label}?")
            .setMessage("It is only removed from Game Space, not uninstalled.")
            .setPositiveButton("Remove") { _, _ ->
                lifecycleScope.launch { store.setGames(selectedPkgs - app.pkg) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEnableAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("Turn on Auto Mode")
            .setMessage(
                "Auto Mode needs the Game Space accessibility service. It only notices which app " +
                "is in front; it never reads your screen, messages or passwords.\n\n" +
                "1. Tap Open Settings\n2. Find Game Space and switch it on\n\n" +
                "If it is greyed out: open App info for Game Space, tap the three dots, then " +
                "Allow restricted settings."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Later", null)
            .show()
    }
}
