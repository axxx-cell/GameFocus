package com.axxxcell.gamespace

import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.axxxcell.gamespace.data.Flag
import com.axxxcell.gamespace.data.SettingsStore
import com.axxxcell.gamespace.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import androidx.activity.OnBackPressedCallback
import android.graphics.drawable.ColorDrawable
import android.view.WindowManager
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import android.content.ComponentName
import android.provider.Settings
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.axxxcell.gamespace.data.GameRepository

/** Group 2: futuristic landscape home screen (top bar, stat pills, toggle cards, games area, bottom nav). */
class MainActivity : AppCompatActivity() {

    private lateinit var store: SettingsStore
    private lateinit var ramPill: StatPill
    private lateinit var pingPill: StatPill
    private lateinit var tempPill: StatPill
    private lateinit var netCard: ToggleCard
    private lateinit var autoSwitch: SwitchCompat
    private lateinit var futureDot: PulseDot
    private val toggles = ArrayList<Pair<ToggleCard, Flag>>()
    private lateinit var carousel: GameCarousel
    private lateinit var gridFloor: PerspectiveGridView
    private lateinit var aerialChip: TextView
    private var aerialOn = true
    private var aerialFlag = true
    private var isPro = false
    private var started = false
    private var themeName = "neon"
    private var modeName = "balanced"
    private var proExpiryMs = 0L
    private lateinit var aurora: AuroraView
    private lateinit var emptyView: View
    private lateinit var navBar: BottomNav
    private lateinit var playPanel: PlayPanel
    private var blockOn = true
    private var muteOn = false
    private var closeOn = true
    private lateinit var pageHost: FrameLayout
    private val pages = ArrayList<View>()
    private var currentPage = 0
    private lateinit var boostPage: BoostPage
    private lateinit var gamesPage: GamesPage
    private lateinit var statsPage: StatsPage
    private lateinit var settingsPage: SettingsPage
    private var selectedPkgs: Set<String> = emptySet()
    private val repo by lazy { GameRepository(this) }
    private val handler = Handler(Looper.getMainLooper())
    private var shimmerAnim: ValueAnimator? = null
    private val gamesAdapter by lazy {
        GamesAdapter(onBoost = ::boostGame, onOpen = ::openGamePanel, onRemove = ::askRemove, onAdd = ::openAddGames)
    }

    /** Group 3 puts the game carousel in here. */
    lateinit var gamesContainer: FrameLayout
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore(this)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val root = FrameLayout(this)
        aurora = AuroraView(this)
        root.addView(aurora, FrameLayout.LayoutParams(MATCH, MATCH))

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(14f), dpi(6f), dpi(14f), dpi(6f))
        }
        page.addView(buildTopBar(), LinearLayout.LayoutParams(MATCH, dpi(44f)))
        val home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        home.addView(buildPills(), LinearLayout.LayoutParams(MATCH, WRAP))
        playPanel = PlayPanel(
            this,
            { m -> lifecycleScope.launch { store.applyPreset(m) }; if (m == "ultra") ensureDndAccess() },
            { key, on -> setPlayFlag(key, on) }
        )
        val mainRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        mainRow.addView(playPanel, LinearLayout.LayoutParams(dpi(270f), MATCH))
        mainRow.addView(buildGames(), LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = dpi(10f) })
        home.addView(mainRow, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dpi(6f) })
        boostPage = BoostPage(this) { boostFromPage() }
        gamesPage = GamesPage(this, { openAddGames() }, { app -> openGamePanel(app) }, { app -> askRemove(app) })
        statsPage = StatsPage(this)
        settingsPage = SettingsPage(this, { key -> themePick(key) }, { showDonate(null) },
            { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        pages.clear()
        pages.addAll(listOf<View>(home, statsPage, gamesPage, boostPage, settingsPage))   // same order as the bottom bar
        pageHost = FrameLayout(this)
        pages.forEachIndexed { n, v ->
            v.visibility = if (n == 0) View.VISIBLE else View.GONE
            pageHost.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        page.addView(pageHost, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dpi(6f) })
        page.addView(buildNav(), LinearLayout.LayoutParams(MATCH, dpi(40f)).apply { topMargin = dpi(6f) })
        root.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        statsPage.setSessions(emptyList())
        gamesPage.setGames(emptyList(), emptyMap(), null)
        refreshSettingsPage()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentPage != 0) { navBar.select(0); selectPage(0) }
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        bindState()
    }

    override fun onStart() {
        super.onStart()
        futureDot.pulse(true)
        val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply {
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
        started = true
        aurora.setAnimated(isPro)
        refreshSettingsPage()
        if (isPro) handler.postDelayed(shimmerTick, 2000)
        lifecycleScope.launch { showGames(selectedPkgs) }
        lifecycleScope.launch {
            val last = store.lastProCheck.first()
            if (System.currentTimeMillis() - last > 3_600_000L) ProManager.refresh(this@MainActivity, store)
        }
    }

    override fun onStop() {
        futureDot.pulse(false)
        started = false
        aurora.setAnimated(false)
        handler.removeCallbacks(shimmerTick)
        shimmerAnim?.cancel()
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
        super.onStop()
    }

    // ---------- UI builders ----------

    private fun buildTopBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(12f), 0, dpi(12f), 0)
            hud(cutDp = 14f)
        }
        bar.addView(icon(R.drawable.ic_crosshair, 26f, GS.CYAN))
        bar.addView(TextView(this).apply {
            text = "GAME SPACE"
            textSize = 20f
            setTextColor(GS.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.1f
            setShadowLayer(dp(10f), 0f, 0f, GS.CYAN)
            setPadding(dpi(10f), 0, 0, 0)
            post {
                val w = paint.measureText(text.toString())
                paint.shader = android.graphics.LinearGradient(
                    0f, 0f, w, 0f,
                    intArrayOf(0xFFFFFFFF.toInt(), GS.CYAN, 0xFFB26BFF.toInt()), null,
                    android.graphics.Shader.TileMode.CLAMP
                )
                invalidate()
            }
        })

        futureDot = PulseDot(this, GS.GREEN_ON)
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(6f), dpi(2f), dpi(10f), dpi(2f))
            glass(cornerDp = 12f, fill = 0x3300FF88, stroke = 0x5500FF88)
        }
        chip.addView(futureDot)
        chip.addView(TextView(this).apply {
            text = "FUTURE MODE ON"
            textSize = 10f
            setTextColor(GS.GREEN_ON)
            typeface = Typeface.DEFAULT_BOLD
        })
        bar.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dpi(12f) })

        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val add = TextView(this).apply {
            text = "+ Add"
            textSize = 13f
            setTextColor(GS.CYAN)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpi(14f), dpi(6f), dpi(14f), dpi(6f))
            glass(cornerDp = 14f)
            setOnClickListener { haptic(); openAddGames() }
        }

        bar.addView(TextView(this).apply {
            text = "Auto Mode"
            tag = "autoLabel"
            textSize = 12f
            setTextColor(GS.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpi(14f), 0, dpi(6f), 0)
        })
        autoSwitch = SwitchCompat(this).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = android.content.res.ColorStateList(states, intArrayOf(GS.CYAN, GS.TEXT_SECONDARY))
            trackTintList = android.content.res.ColorStateList(states, intArrayOf(0x6600F5FF, 0x33FFFFFF))
            setOnCheckedChangeListener { v, checked ->
                if (v.isPressed) {
                    v.haptic()
                    if (checked && !isPro) {
                        v.isChecked = false
                        showDonate("Auto Mode is a Pro feature")
                        return@setOnCheckedChangeListener
                    }
                    lifecycleScope.launch { store.setFlag(Flag.AUTO_MODE, checked) }
                    if (checked && !AutoActivationService.isEnabled(this@MainActivity)) showEnableAccessibility()
                }
            }
        }
        bar.addView(autoSwitch)
        return bar
    }

    private fun scrollRow(row: LinearLayout) = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        addView(row)
    }

    private fun buildPills(): View {
        ramPill = StatPill(this, R.drawable.ic_ram, "-- RAM")
        pingPill = StatPill(this, R.drawable.ic_signal, "Ping --")
        tempPill = StatPill(this, R.drawable.ic_temp, "Temp --")
        pingPill.setOnClickListener { pingPill.haptic(); openNetwork() }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in listOf(ramPill, pingPill, tempPill)) {
            row.addView(p, LinearLayout.LayoutParams(WRAP, dpi(28f)).apply { marginEnd = dpi(8f) })
        }
        return scrollRow(row)
    }

    private fun buildToggles(): View {
        val specs = listOf(
            Triple(R.drawable.ic_games, "Game Mode", Flag.GAME_MODE),
            Triple(R.drawable.ic_shield, "Network Tools", Flag.NET_BOOST),
            Triple(R.drawable.ic_leaf, "Power Save", Flag.POWER_SAVE),
            Triple(R.drawable.ic_bell, "Alerts", Flag.ALERTS)
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((iconRes, name, flag) in specs) {
            val card = ToggleCard(this, iconRes, name)
            card.setOnClickListener {
                card.haptic()
                if (flag == Flag.NET_BOOST) openNetwork()
                else lifecycleScope.launch { store.setFlag(flag, !card.isOn) }
            }
            if (flag == Flag.NET_BOOST) netCard = card
            toggles.add(card to flag)
            row.addView(card, LinearLayout.LayoutParams(dpi(150f), dpi(56f)).apply { marginEnd = dpi(8f) })
        }
        return scrollRow(row)
    }

    private fun buildGames(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "GAMES"
            textSize = 12f
            setTextColor(GS.CYAN)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(dp(8f), 0f, 0f, GS.CYAN)
        })
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        aerialChip = TextView(this).apply {
            text = "AERIAL 3D"
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.1f
            setPadding(dpi(12f), dpi(3f), dpi(12f), dpi(3f))
            setOnClickListener {
                haptic()
                if (!isPro) showDonate("Aerial 3D is a Pro effect")
                else lifecycleScope.launch { store.setFlag(Flag.AERIAL_VIEW, !aerialFlag) }
            }
        }
        head.addView(aerialChip)
        box.addView(head)
        carousel = GameCarousel(this).apply { adapter = gamesAdapter }
        emptyView = FrameLayout(this).apply {
            addView(AddCardView(this@MainActivity).apply { setOnClickListener { haptic(); openAddGames() } },
                FrameLayout.LayoutParams(dpi(220f), WRAP, Gravity.CENTER))
        }
        gamesContainer = FrameLayout(this)
        gridFloor = PerspectiveGridView(this)
        gamesContainer.addView(gridFloor, FrameLayout.LayoutParams(MATCH, MATCH).apply { topMargin = dpi(4f) })
        gamesContainer.addView(carousel, FrameLayout.LayoutParams(MATCH, MATCH).apply { topMargin = dpi(4f) })
        gamesContainer.addView(emptyView, FrameLayout.LayoutParams(MATCH, MATCH).apply { topMargin = dpi(4f) })
        box.addView(gamesContainer, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    private fun buildNav(): View {
        navBar = BottomNav(
            this,
            listOf(
                R.drawable.ic_home to "Home",
                R.drawable.ic_stats to "Stats",
                R.drawable.ic_games to "Games",
                R.drawable.ic_rocket to "Boost",
                R.drawable.ic_settings to "Settings"
            )
        ) { index -> selectPage(index) }
        return navBar
    }

    private fun icon(res: Int, sizeDp: Float, color: Int) = (this as android.content.Context).icon(res, sizeDp, color)

    // ---------- state + live stats (only while the screen is visible) ----------

    private fun bindState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { store.flag(Flag.AUTO_MODE).collect { if (autoSwitch.isChecked != it) autoSwitch.isChecked = it } }
                launch { store.games.collect { showGames(it) } }
                launch { store.flag(Flag.AERIAL_VIEW).collect { aerialFlag = it; applyAerial() } }
                launch {
                    combine(store.flag(Flag.PRO), store.proExpiry) { f, e -> f to e }.collect { (f, e) ->
                        proExpiryMs = e
                        applyPro(f && System.currentTimeMillis() <= e)
                    }
                }
                launch { store.theme.collect { themeName = it; applyTheme(); refreshSettingsPage() } }
                launch {
                    combine(store.flag(Flag.GAME_MODE), store.flag(Flag.MUTE_CALLS), store.flag(Flag.CLOSE_APPS)) { a, b, c ->
                        Triple(a, b, c)
                    }.collect { (a, b, c) ->
                        blockOn = a; muteOn = b; closeOn = c
                        modeName = if (a && b && c) "ultra" else "balanced"
                        playPanel.setState(a, b, c)
                    }
                }
                launch { store.sessions.collect { statsPage.setSessions(it) } }
                launch { store.lastBoost.collect { boostPage.setLast(it) } }
                for ((card, flag) in toggles) {
                    launch { store.flag(flag).collect { card.setOn(it || flag == Flag.NET_BOOST) } }
                }
                launch {
                    while (isActive) {
                        updateRamAndTemp()
                        val ms = measurePing()
                        updatePing(ms)
                        delay(3000)
                    }
                }
            }
        }
    }

    private fun updateRamAndTemp() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = 1073741824.0
        val used = (mi.totalMem - mi.availMem) / gb
        val total = Math.round(mi.totalMem / gb).toInt()
        ramPill.setText(String.format(Locale.US, "%.1fGB/%dGB RAM", used, total))
        boostPage.setRam(((mi.totalMem - mi.availMem) / 1048576).toInt(), (mi.totalMem / 1048576).toInt())

        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val state = when {
            t <= 0f -> ""
            t < 40f -> " Optimal"
            t < 45f -> " Warm"
            else -> " Hot"
        }
        tempPill.setText(if (t > 0f) String.format(Locale.US, "Temp %.0f°C%s", t, state) else "Temp --")
    }

    private suspend fun measurePing(): Int = withContext(Dispatchers.IO) {
        try {
            Socket().use { s ->
                val start = SystemClock.elapsedRealtime()
                s.connect(InetSocketAddress("1.1.1.1", 443), 1500)
                (SystemClock.elapsedRealtime() - start).toInt()
            }
        } catch (e: Exception) {
            -1
        }
    }

    private fun updatePing(ms: Int) {
        if (ms > 0) {
            val q = when {
                ms < 60 -> "Stable"
                ms < 120 -> "Fair"
                else -> "High"
            }
            pingPill.setText("Ping ${ms}ms $q")
        } else {
            pingPill.setText("Ping --")
        }
    }

    // ---------- games ----------

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pkg = i.data?.schemeSpecificPart ?: return
            if (i.action == Intent.ACTION_PACKAGE_ADDED) {
                if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                lifecycleScope.launch {
                    val app = withContext(Dispatchers.IO) { repo.load(pkg) }
                    if (app != null && app.isGame) {
                        Toast.makeText(this@MainActivity, "New game detected: ${app.label}. Tap + Add", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                repo.forget(pkg)
                lifecycleScope.launch { showGames(selectedPkgs) }
            }
        }
    }

    private val shimmerTick = object : Runnable {
        override fun run() {
            if (!isPro) return
            shimmerAnim?.cancel()
            shimmerAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 900
                addUpdateListener { carousel.setShimmer(it.animatedValue as Float) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) { carousel.setShimmer(0f) }
                })
                start()
            }
            handler.postDelayed(this, 5000)
        }
    }

    private suspend fun showGames(pkgs: Set<String>) {
        selectedPkgs = pkgs
        val list = withContext(Dispatchers.IO) {
            pkgs.mapNotNull { repo.load(it) }.sortedBy { it.label.lowercase() }
        }
        val shown = if (isPro) list else list.take(3)   // Free: 3 games
        gamesAdapter.submit(shown)
        gamesPage.setGames(shown, playedTodayMap(), if (isPro) null else "Free version: 3 games. Donate for more.")
        val empty = shown.isEmpty()
        emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        carousel.visibility = if (empty) View.GONE else View.VISIBLE
    }

    private fun openAddGames() {
        lifecycleScope.launch {
            val apps = repo.launchableApps()
            AddGamesDialog.show(this@MainActivity, apps, selectedPkgs, if (isPro) 999 else 3, { showDonate("Free version: 3 games max") }) { chosen ->
                lifecycleScope.launch { store.setGames(chosen) }
            }
        }
    }

    private fun boostGame(app: GameRepository.App, card: GameCardView) {
        if (isPro) card.burst()
        gamesAdapter.setActive(app.pkg)
        lifecycleScope.launch {
            delay(450)
            if (closeOn) runBoost { launchWithToolbar(app) } else launchWithToolbar(app)
        }
    }

    private fun openGame(app: GameRepository.App) {
        val i = packageManager.getLaunchIntentForPackage(app.pkg)
        if (i != null) startActivity(i)
        else Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
    }

    private fun askRemove(app: GameRepository.App) {
        AlertDialog.Builder(this)
            .setTitle("Remove ${app.label}?")
            .setMessage("It is only removed from Game Space, not uninstalled.")
            .setPositiveButton("Remove") { _, _ ->
                lifecycleScope.launch { store.setGames(selectedPkgs - app.pkg) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEnableAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("Turn on Auto Mode")
            .setMessage(
                "Auto Mode needs the Game Space accessibility service. It only notices which app " +
                "is in front; it never reads your screen, messages or passwords.\n\n" +
                "1. Tap Open Settings\n2. Find Game Space and switch it on\n\n" +
                "If it is greyed out: open App info for Game Space, tap the three dots, then " +
                "Allow restricted settings."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private var aerialInit = false

    private fun applyAerial() {
        val on = aerialFlag && isPro
        aerialOn = on
        carousel.setAerial(on, animate = aerialInit)
        aerialInit = true
        gridFloor.visibility = if (on) View.VISIBLE else View.GONE
        aerialChip.text = if (isPro) "AERIAL 3D" else "AERIAL 3D  PRO"
        aerialChip.setTextColor(if (on) GS.CYAN else GS.TEXT_SECONDARY)
        aerialChip.glass(
            cornerDp = 12f,
            fill = if (on) 0xB3252D5A.toInt() else GS.GLASS_PILL_70,
            stroke = if (on) 0x9900F5FF.toInt() else GS.CYAN_BORDER_20
        )
    }

    // ---------- free / pro ----------

    private fun applyPro(pro: Boolean) {
        isPro = pro
        carousel.effects = pro
        aurora.setAnimated(pro && started)
        applyAerial()
        window.decorView.findViewWithTag<TextView>("autoLabel")?.text = if (pro) "Auto Mode" else "Auto Mode  PRO"
        handler.removeCallbacks(shimmerTick)
        shimmerAnim?.cancel()
        carousel.setShimmer(0f)
        if (pro && started) handler.postDelayed(shimmerTick, 2000)
        lifecycleScope.launch { showGames(selectedPkgs) }
        applyTheme()
        refreshSettingsPage()
    }

    private fun applyTheme() {
        val name = if (isPro) themeName else "neon"
        aurora.setTheme(name)
        when (name) {
            "amoled" -> {
                window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
                window.setBackgroundDrawable(ColorDrawable(0xFF000000.toInt()))
            }
            "transparent" -> {
                window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
                window.setBackgroundDrawable(ColorDrawable(0x66000000))
            }
            else -> {
                window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
                window.setBackgroundDrawable(androidx.core.content.res.ResourcesCompat.getDrawable(resources, R.drawable.bg_space, theme))
            }
        }
    }

    private fun showDonate(reason: String?) {
        DonateDialog.show(this, ProManager.deviceCode(this), reason) { checkPro() }
    }

    private fun checkPro() {
        lifecycleScope.launch {
            val ok = ProManager.refresh(this@MainActivity, store)
            Toast.makeText(
                this@MainActivity,
                if (ok) "Checked. Status updated." else "Can't reach the list. Check your internet.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun openSettings() {
        SettingsDialog.show(
            this, isPro, proExpiryMs, ProManager.deviceCode(this),
            if (isPro) themeName else "neon",
            { key ->
                if (key != "neon" && !isPro) showDonate("Themes are a Pro feature")
                else lifecycleScope.launch { store.setTheme(key) }
            },
            { showDonate(null) }
        )
    }

    private fun openStats() {
        lifecycleScope.launch { StatsDialog.show(this@MainActivity, store.sessions.first()) }
    }

    // ---------- real boost ----------

    private var boosting = false

    private fun runBoost(onDone: (() -> Unit)? = null) {
        if (boosting) return
        boosting = true
        val dlg = BoostDialog(this)
        dlg.show()
        lifecycleScope.launch {
            try {
                val r = BoostUtils.boost(this@MainActivity, selectedPkgs) { dlg.step(it) }
                SessionStats.freedMb = r.totalMb
                dlg.done(r)
                delay(2200)
            } finally {
                dlg.dismiss()
                boosting = false
            }
            onDone?.invoke()
        }
    }

    // ---------- start a game with the floating toolbar ----------

    private fun launchWithToolbar(app: GameRepository.App) {
        if (AutoActivationService.isEnabled(this) && AutoActivationService.startManual(app.pkg)) {
            openGame(app)
        } else {
            AlertDialog.Builder(this)
                .setTitle("Show the floating toolbar?")
                .setMessage(
                    "The toolbar (brightness, block notifications, record and more) appears over your game " +
                    "through the Game Space accessibility service. It only notices which app is in front.\n\n" +
                    "1. Tap Open Settings\n2. Find Game Space and switch it on\n3. Come back and tap BOOST again\n\n" +
                    "If it is greyed out: App info > three dots > Allow restricted settings."
                )
                .setPositiveButton("Open Settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNeutralButton("Play without it") { _, _ -> openGame(app) }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun openNetwork() { NetworkDialog.show(this) }

    // ---------- game panel (tap a card) ----------

    private fun openGamePanel(app: GameRepository.App) {
        lifecycleScope.launch {
            val mins = playedTodayMinutes(app.pkg)
            GamePanelDialog.show(
                this@MainActivity, app, mins, modeName,
                { m -> lifecycleScope.launch { store.applyPreset(m) }; if (m == "ultra") ensureDndAccess() },
                {
                    listOf(
                        "BATTERY" to batteryText(),
                        "NETWORK" to pingPill.text.removePrefix("Ping "),
                        "RAM" to ramPill.text.removeSuffix(" RAM"),
                        "TEMP" to tempPill.text.removePrefix("Temp ")
                    )
                },
                { if (closeOn) runBoost { launchWithToolbar(app) } else launchWithToolbar(app) }
            )
        }
    }

    private fun batteryText(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level < 0 || scale <= 0) "--" else "${level * 100 / scale}%"
    }

    /** Adds up today's logged sessions for this game. */
    private suspend fun playedTodayMinutes(pkg: String): Int {
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        var ms = 0L
        for (line in store.sessions.first()) {
            val p = line.split("|")
            if (p.size < 5 || p[0] != pkg) continue
            val st = p[2].toLongOrNull() ?: continue
            if (st >= start) ms += p[3].toLongOrNull() ?: 0L
        }
        return (ms / 60000).toInt()
    }

    // ---------- pages ----------

    private fun selectPage(i: Int) {
        if (i == currentPage || i !in pages.indices) return
        val from = pages[currentPage]
        val to = pages[i]
        val dir = if (i > currentPage) 1 else -1
        currentPage = i
        to.visibility = View.VISIBLE
        to.alpha = 0f
        to.translationX = dir * dp(36f)
        to.animate().alpha(1f).translationX(0f).setDuration(240).start()
        from.animate().alpha(0f).translationX(-dir * dp(36f)).setDuration(160).withEndAction {
            if (pages[currentPage] !== from) from.visibility = View.GONE
            from.alpha = 1f
            from.translationX = 0f
        }.start()
        if (i == 3) { val (u, t) = ramInfo(); boostPage.setRam(u, t) }
    }

    private fun ramInfo(): Pair<Int, Int> {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return ((mi.totalMem - mi.availMem) / 1048576).toInt() to (mi.totalMem / 1048576).toInt()
    }

    /** Boost page: the same real boost, with live steps and a real before/after. */
    private fun boostFromPage() {
        if (boosting) return
        boosting = true
        boostPage.begin()
        lifecycleScope.launch {
            try {
                val before = ramInfo().first
                val r = BoostUtils.boost(this@MainActivity, selectedPkgs) { boostPage.step(it) }
                boostPage.step("Checking network...")
                val ping = measurePing()
                delay(400)
                val (after, total) = ramInfo()
                SessionStats.freedMb = r.totalMb
                store.setLastBoost(r.ramMb, r.cacheMb, r.apps)
                boostPage.finish(r.totalMb, r.apps, before, after, ping)
                boostPage.setRam(after, total)
            } finally {
                boosting = false
            }
        }
    }

    private fun themePick(key: String) {
        if (key != "neon" && !isPro) showDonate("Themes are a Pro feature")
        else lifecycleScope.launch { store.setTheme(key) }
    }

    private fun refreshSettingsPage() {
        settingsPage.update(
            isPro, proExpiryMs, ProManager.deviceCode(this),
            if (isPro) themeName else "neon",
            AutoActivationService.isEnabled(this)
        )
    }

    private suspend fun playedTodayMap(): Map<String, Int> {
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        val m = HashMap<String, Long>()
        for (line in store.sessions.first()) {
            val p = line.split("|")
            if (p.size < 5) continue
            val st = p[2].toLongOrNull() ?: continue
            if (st >= start) m[p[0]] = (m[p[0]] ?: 0L) + (p[3].toLongOrNull() ?: 0L)
        }
        return m.mapValues { (it.value / 60000).toInt() }
    }

    // ---------- "when you play" switches ----------

    private fun setPlayFlag(key: String, on: Boolean) {
        val f = when (key) { "block" -> Flag.GAME_MODE; "mute" -> Flag.MUTE_CALLS; else -> Flag.CLOSE_APPS }
        lifecycleScope.launch { store.setFlag(f, on) }
        if (on && key != "close") ensureDndAccess()
    }

    /** Blocking notifications and muting calls both use Do Not Disturb, which needs a one-time permission. */
    private fun ensureDndAccess() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (nm.isNotificationPolicyAccessGranted) return
        AlertDialog.Builder(this)
            .setTitle("Allow Do Not Disturb access")
            .setMessage(
                "To silence notifications and calls while you play, Android needs you to allow Game Space " +
                "under Do Not Disturb access. Tap Open Settings, find Game Space and switch it on."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            .setNegativeButton("Later", null)
            .show()
    }
}
