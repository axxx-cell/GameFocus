package com.axxxcell.gamespace

import android.content.Context
import android.provider.Settings
import com.axxxcell.gamespace.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

/** Pro is switched on from a plain-text list on GitHub (device code + last day). Works offline until that day. */
object ProManager {

    fun deviceCode(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val hex = MessageDigest.getInstance("SHA-256")
            .digest("gamespace:$id".toByteArray())
            .joinToString("") { "%02X".format(it) }
        return hex.substring(0, 4) + "-" + hex.substring(4, 8)
    }

    /** true = the list was reached and the Pro state updated; false = no connection (state left unchanged). */
    suspend fun refresh(ctx: Context, store: SettingsStore): Boolean = withContext(Dispatchers.IO) {
        try {
            val conn = URL(Config.PRO_LIST_URL + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.useCaches = false
            conn.setRequestProperty("Cache-Control", "no-cache")
            if (conn.responseCode != 200) { conn.disconnect(); return@withContext false }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val code = deviceCode(ctx)
            var expiry = 0L
            for (line in text.lineSequence()) {
                val t = line.trim()
                if (t.isEmpty() || t.startsWith("#")) continue
                val parts = t.split(Regex("\\s+"))
                if (parts.size >= 2 && parts[0].equals(code, ignoreCase = true)) {
                    expiry = maxOf(expiry, endOfDay(parts[1]))
                }
            }
            val active = expiry > System.currentTimeMillis()
            store.setProState(active, if (active) expiry else 0L)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun endOfDay(d: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(d)!!.time + 24L * 3600 * 1000 - 1
    } catch (e: Exception) { 0L }
}
