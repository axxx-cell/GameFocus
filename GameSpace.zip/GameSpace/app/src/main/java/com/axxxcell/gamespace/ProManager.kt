package com.axxxcell.gamespace

import android.content.Context
import android.provider.Settings
import com.axxxcell.gamespace.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

/** Pro is switched on from a plain-text list on GitHub (device code + last day). Works offline until that day. */
object ProManager {

    data class PayInfo(val email: String, val gcash: String, val price: String)
    enum class Status { NO_CONNECTION, ACTIVE, EXPIRED, NOT_LISTED }
    data class Result(val status: Status, val expiry: Long = 0L)

    fun deviceCode(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val hex = MessageDigest.getInstance("SHA-256")
            .digest("gamespace:$id".toByteArray())
            .joinToString("") { "%02X".format(it) }
        return hex.substring(0, 4) + "-" + hex.substring(4, 8)
    }

    /** Stored as three lines: email, gcash, price. Empty parts fall back to Config. */
    fun parsePay(stored: String): PayInfo {
        val p = stored.split("\n")
        fun at(i: Int, def: String) = p.getOrNull(i)?.takeIf { it.isNotBlank() } ?: def
        return PayInfo(at(0, Config.CONTACT_EMAIL), at(1, Config.GCASH_NUMBER), at(2, Config.PRICE_TEXT))
    }

    private fun norm(s: String) = s.replace("-", "").replace(" ", "").uppercase()

    suspend fun refresh(ctx: Context, store: SettingsStore): Result = withContext(Dispatchers.IO) {
        try {
            val conn = URL(Config.PRO_LIST_URL + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.useCaches = false
            conn.setRequestProperty("Cache-Control", "no-cache")
            if (conn.responseCode != 200) { conn.disconnect(); return@withContext Result(Status.NO_CONNECTION) }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val mine = norm(deviceCode(ctx))
            var listed = false
            var expiry = 0L
            var email = ""; var gcash = ""; var price = ""
            for (line in text.lineSequence()) {
                val t = line.trim()
                if (t.isEmpty()) continue
                if (t.startsWith("#")) {
                    val body = t.removePrefix("#").trim()
                    val idx = body.indexOf(':')
                    if (idx > 0) {
                        val value = body.substring(idx + 1).trim()
                        when (body.substring(0, idx).trim().lowercase()) {
                            "email", "gmail", "contact" -> email = value
                            "gcash" -> gcash = value
                            "price" -> price = value
                        }
                    }
                    continue
                }
                val parts = t.split(Regex("\\s+"))
                if (parts.size >= 2 && norm(parts[0]) == mine) {
                    listed = true
                    expiry = maxOf(expiry, endOfDay(parts[1]))
                }
            }
            if (email.isNotEmpty() || gcash.isNotEmpty() || price.isNotEmpty()) store.setPayInfo(email, gcash, price)

            val active = expiry > System.currentTimeMillis()
            store.setProState(active, if (active) expiry else 0L)
            when {
                active -> Result(Status.ACTIVE, expiry)
                listed -> Result(Status.EXPIRED)
                else -> Result(Status.NOT_LISTED)
            }
        } catch (e: Exception) {
            Result(Status.NO_CONNECTION)
        }
    }

    private fun endOfDay(d: String): Long {
        for (pattern in listOf("yyyy-MM-dd", "yyyy/MM/dd")) {
            try {
                return SimpleDateFormat(pattern, Locale.US).parse(d)!!.time + 24L * 3600 * 1000 - 1
            } catch (_: Exception) {}
        }
        return 0L
    }
}
