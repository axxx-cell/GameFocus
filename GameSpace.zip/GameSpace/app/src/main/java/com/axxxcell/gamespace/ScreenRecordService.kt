package com.axxxcell.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Shared recording state (same process as the accessibility service). */
object RecordState {
    @Volatile var recording = false
    /** Free version shows a "GAME SPACE" watermark on screen while recording. Group 7 turns it off for Pro. */
    @Volatile var watermark = true
    var listener: ((Boolean) -> Unit)? = null
}

/** Foreground service that records the screen (video only) into Movies/GameSpace. Exists only while recording. */
class ScreenRecordService : Service() {

    companion object {
        const val ACTION_START = "gs.record.start"
        const val ACTION_STOP = "gs.record.stop"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        private const val CHANNEL = "gs_record"
        private const val NOTIF_ID = 4107

        @Volatile var instance: ScreenRecordService? = null

        fun start(ctx: Context, code: Int, data: Intent) {
            val i = Intent(ctx, ScreenRecordService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, code)
                .putExtra(EXTRA_DATA, data)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop() { instance?.stopRecording() }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var pendingUri: Uri? = null
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        instance = this
        when (intent?.action) {
            ACTION_START -> {
                startAsForeground()
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
                if (data == null) { stopSelf(); return START_NOT_STICKY }
                startRecording(code, data)
            }
            ACTION_STOP -> stopRecording()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_record)
            .setContentTitle("Game Space is recording")
            .setContentText("Tap Stop to finish and save")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun startRecording(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { handler.post { stopRecording() } }
            }, handler)

            val dm = resources.displayMetrics
            val scale = min(1f, 1920f / max(dm.widthPixels, dm.heightPixels))
            val w = (dm.widthPixels * scale).toInt() and 1.inv()
            val h = (dm.heightPixels * scale).toInt() and 1.inv()

            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoEncodingBitRate(8_000_000)
            rec.setVideoFrameRate(30)
            rec.setVideoSize(w, h)
            rec.setOutputFile(openOutput())
            rec.prepare()
            recorder = rec

            display = proj.createVirtualDisplay(
                "GameSpaceRec", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
            )
            rec.start()
            RecordState.recording = true
            RecordState.listener?.invoke(true)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start recording", Toast.LENGTH_SHORT).show()
            cleanup(save = false)
        }
    }

    private fun openOutput(): java.io.FileDescriptor {
        val name = "GameSpace_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val fd: ParcelFileDescriptor
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/GameSpace")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("no uri")
            pendingUri = uri
            fd = contentResolver.openFileDescriptor(uri, "w") ?: throw IllegalStateException("no fd")
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            fd = ParcelFileDescriptor.open(
                File(dir, name),
                ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
            )
        }
        pfd = fd
        return fd.fileDescriptor
    }

    fun stopRecording() {
        if (stopping) return
        stopping = true
        cleanup(save = true)
    }

    private fun cleanup(save: Boolean) {
        var ok = false
        try { recorder?.stop(); ok = true } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        pendingUri?.let { uri ->
            try {
                if (ok) {
                    contentResolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                } else {
                    contentResolver.delete(uri, null, null)
                }
            } catch (_: Exception) {}
        }
        recorder = null; display = null; projection = null; pfd = null; pendingUri = null
        val was = RecordState.recording
        RecordState.recording = false
        if (was) RecordState.listener?.invoke(false)
        if (save && ok) Toast.makeText(this, "Saved to Movies/GameSpace", Toast.LENGTH_LONG).show()
        stopForeground(STOP_FOREGROUND_REMOVE)
        instance = null
        stopSelf()
    }

    override fun onDestroy() {
        if (!stopping && (recorder != null || projection != null)) cleanup(save = true)
        instance = null
        super.onDestroy()
    }
}
