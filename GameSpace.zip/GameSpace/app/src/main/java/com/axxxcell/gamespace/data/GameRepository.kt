package com.axxxcell.gamespace.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Finds installed games. Results are cached in memory so the carousel loads fast. */
class GameRepository(private val ctx: Context) {

    data class App(
        val pkg: String,
        val label: String,
        val icon: Drawable,
        val isGame: Boolean,
        val category: String
    )

    private val pm: PackageManager = ctx.packageManager
    private val cache = HashMap<String, App>()

    private val knownCategories = mapOf(
        "com.mobile.legends" to "MOBA",
        "com.activision.callofduty.shooter" to "FPS",
        "com.garena.game.codm" to "FPS",
        "com.tencent.ig" to "BATTLE ROYALE",
        "com.pubg.imobile" to "BATTLE ROYALE",
        "com.dts.freefireth" to "BATTLE ROYALE",
        "com.dts.freefiremax" to "BATTLE ROYALE",
        "com.roblox.client" to "SANDBOX",
        "com.mojang.minecraftpe" to "SANDBOX",
        "com.miHoYo.GenshinImpact" to "RPG",
        "com.supercell.clashofclans" to "STRATEGY",
        "com.supercell.brawlstars" to "ACTION",
        "com.proximabeta.mf.uamo" to "RPG",
        "com.garena.game.df" to "MOBA"
    )

    @Suppress("DEPRECATION")
    fun load(pkg: String): App? {
        cache[pkg]?.let { return it }
        return try {
            val ai = pm.getApplicationInfo(pkg, 0)
            val isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            val app = App(
                pkg = pkg,
                label = pm.getApplicationLabel(ai).toString(),
                icon = pm.getApplicationIcon(ai),
                isGame = isGame,
                category = knownCategories[pkg] ?: "GAME"
            )
            cache[pkg] = app
            app
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    fun forget(pkg: String) { cache.remove(pkg) }

    /** Every app with a launcher icon (games first, then A-Z), excluding Game Space itself. */
    suspend fun launchableApps(): List<App> = withContext(Dispatchers.IO) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != ctx.packageName }
            .mapNotNull { load(it) }
            .sortedWith(compareByDescending<App> { it.isGame }.thenBy { it.label.lowercase() })
    }
}
