package com.axxxcell.gamespace.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.gsDataStore by preferencesDataStore(name = "gamespace_settings")

enum class Flag(val key: Preferences.Key<Boolean>, val default: Boolean) {
    AUTO_MODE(booleanPreferencesKey("auto_mode"), false),
    FUTURE_MODE(booleanPreferencesKey("future_mode"), true),
    GAME_MODE(booleanPreferencesKey("game_mode"), true),
    NET_BOOST(booleanPreferencesKey("net_boost"), true),
    POWER_SAVE(booleanPreferencesKey("power_save"), false),
    ALERTS(booleanPreferencesKey("alerts"), true),
    AERIAL_VIEW(booleanPreferencesKey("aerial_view"), true),
    PRO(booleanPreferencesKey("is_pro"), false)
}

/** All app settings live here (DataStore). */
class SettingsStore(context: Context) {
    private val store = context.applicationContext.gsDataStore
    private val themeKey = stringPreferencesKey("theme")
    private val gamesKey = stringSetPreferencesKey("games")

    fun flag(f: Flag): Flow<Boolean> = store.data.map { it[f.key] ?: f.default }
    suspend fun setFlag(f: Flag, value: Boolean) { store.edit { it[f.key] = value } }

    val theme: Flow<String> = store.data.map { it[themeKey] ?: "neon" }
    suspend fun setTheme(name: String) { store.edit { it[themeKey] = name } }

    /** Package names of games the user added to Game Space. */
    val games: Flow<Set<String>> = store.data.map { it[gamesKey] ?: emptySet() }
    suspend fun setGames(pkgs: Set<String>) { store.edit { it[gamesKey] = pkgs } }

    private val sessionsKey = stringPreferencesKey("sessions")

    /** Newest first. Each line: pkg|label|startMs|durationMs|freedMb */
    val sessions: Flow<List<String>> = store.data.map {
        (it[sessionsKey] ?: "").split("\n").filter { l -> l.isNotBlank() }
    }

    suspend fun addSession(line: String) {
        store.edit {
            val old = (it[sessionsKey] ?: "").split("\n").filter { l -> l.isNotBlank() }
            it[sessionsKey] = (listOf(line) + old).take(50).joinToString("\n")
        }
    }

    private val proExpiryKey = longPreferencesKey("pro_expiry")
    private val proCheckedKey = longPreferencesKey("pro_checked")

    val proExpiry: Flow<Long> = store.data.map { it[proExpiryKey] ?: 0L }
    val lastProCheck: Flow<Long> = store.data.map { it[proCheckedKey] ?: 0L }

    suspend fun setProState(active: Boolean, expiryMs: Long) {
        store.edit {
            it[Flag.PRO.key] = active
            it[proExpiryKey] = expiryMs
            it[proCheckedKey] = System.currentTimeMillis()
        }
    }
}
