package com.axxxcell.gamespace.ui

import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatCheckBox
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.axxxcell.gamespace.R
import com.axxxcell.gamespace.data.GameRepository

/** Pick which installed apps show up in Game Space. Detected games are listed first. */
object AddGamesDialog {

    private class Row(val root: LinearLayout, val icon: ImageView, val name: TextView, val tag: TextView, val check: AppCompatCheckBox) :
        RecyclerView.ViewHolder(root)

    fun show(
        a: AppCompatActivity,
        apps: List<GameRepository.App>,
        selected: Set<String>,
        maxSelect: Int,
        onLimit: () -> Unit,
        onDone: (Set<String>) -> Unit
    ) {
        val chosen = selected.take(maxSelect).toMutableSet()
        val dialog = Dialog(a)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dpi(16f), a.dpi(14f), a.dpi(16f), a.dpi(14f))
            background = Glass.drawable(a, 20f, fill = 0xFF141A33.toInt(), stroke = 0x6600F5FF)
        }
        box.addView(TextView(a).apply {
            text = "ADD GAMES"
            textSize = 16f
            setTextColor(GS.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.1f
            setShadowLayer(a.dp(8f), 0f, 0f, GS.CYAN)
        })
        box.addView(TextView(a).apply {
            text = "Detected games are listed first"
            textSize = 11f
            setTextColor(GS.TEXT_SECONDARY)
        })

        val list = RecyclerView(a).apply {
            layoutManager = LinearLayoutManager(a)
            adapter = object : RecyclerView.Adapter<Row>() {
                override fun getItemCount() = apps.size
                override fun onCreateViewHolder(p: ViewGroup, t: Int): Row {
                    val root = LinearLayout(a).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, a.dpi(6f), 0, a.dpi(6f))
                        layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
                    }
                    val icon = ImageView(a)
                    root.addView(icon, LinearLayout.LayoutParams(a.dpi(36f), a.dpi(36f)))
                    val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                    val name = TextView(a).apply {
                        textSize = 14f; setTextColor(GS.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1
                    }
                    val tag = TextView(a).apply {
                        text = "GAME DETECTED"; textSize = 9f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
                    }
                    col.addView(name); col.addView(tag)
                    root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dpi(10f) })
                    val check = AppCompatCheckBox(a).apply {
                        buttonTintList = ColorStateList(
                            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                            intArrayOf(GS.CYAN, GS.TEXT_SECONDARY)
                        )
                    }
                    root.addView(check)
                    return Row(root, icon, name, tag, check)
                }

                override fun onBindViewHolder(h: Row, i: Int) {
                    val app = apps[i]
                    h.icon.setImageDrawable(app.icon)
                    h.name.text = app.label
                    h.tag.visibility = if (app.isGame) android.view.View.VISIBLE else android.view.View.GONE
                    h.check.setOnCheckedChangeListener(null)
                    h.check.isChecked = app.pkg in chosen
                    h.check.setOnCheckedChangeListener { btn, on ->
                        if (on && app.pkg !in chosen && chosen.size >= maxSelect) {
                            btn.post { btn.isChecked = false }
                            onLimit()
                        } else if (on) chosen.add(app.pkg) else chosen.remove(app.pkg)
                    }
                    h.root.setOnClickListener { h.check.toggle() }
                }
            }
        }
        box.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = a.dpi(8f) })

        val done = TextView(a).apply {
            text = "DONE"
            textSize = 13f
            setTextColor(GS.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(GS.PURPLE, 0xFF00E5FF.toInt())
            ).apply { cornerRadius = a.dp(18f) }
            setOnClickListener { haptic(); onDone(chosen.toSet()); dialog.dismiss() }
        }
        box.addView(done, LinearLayout.LayoutParams(MATCH, a.dpi(36f)).apply { topMargin = a.dpi(8f) })

        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        val dm = a.resources.displayMetrics
        dialog.window?.setLayout(a.dpi(420f).coerceAtMost((dm.widthPixels * 0.9f).toInt()), (dm.heightPixels * 0.9f).toInt())
    }
}
