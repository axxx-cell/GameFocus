package com.axxxcell.gamespace.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.View

/** Deep-space gradient + soft aurora blobs + faint HUD grid dots (5% opacity). Static, so it costs no battery. */
class AuroraView(context: Context) : View(context) {

    private val blobPaints = ArrayList<Paint>()
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x0DFFFFFF } // ~5%
    private val spacing = context.dp(28f)
    private val dotR = context.dp(1f)

    private var theme = "neon"

    init { setTheme("neon") }

    /** neon = deep-space gradient + aurora + grid; amoled = black; transparent = shows your wallpaper. */
    fun setTheme(name: String) {
        theme = name
        background = if (name == "neon") GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(GS.NAVY, GS.MID, GS.PURPLE_DARK)
        ) else null
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        blobPaints.clear()
        val big = maxOf(w, h).toFloat()
        fun blob(cx: Float, cy: Float, r: Float, color: Int) {
            val clear = color and 0x00FFFFFF
            blobPaints.add(Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(cx * w, cy * h, r * big, color, clear, Shader.TileMode.CLAMP)
            })
        }
        blob(0.05f, 0.85f, 0.45f, 0x4D00D4FF)  // cyan, bottom-left
        blob(0.90f, 0.20f, 0.50f, 0x4D8A2BE2)  // purple, top-right
        blob(0.55f, 0.55f, 0.35f, 0x263B5BFF)  // blue, center
    }

    override fun onDraw(c: Canvas) {
        if (theme == "neon") for (p in blobPaints) c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        if (theme == "transparent") return
        var y = spacing / 2
        while (y < height) {
            var x = spacing / 2
            while (x < width) { c.drawCircle(x, y, dotR, dotPaint); x += spacing }
            y += spacing
        }
    }
}
