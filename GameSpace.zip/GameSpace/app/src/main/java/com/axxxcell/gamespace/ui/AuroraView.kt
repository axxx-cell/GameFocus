package com.axxxcell.gamespace.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Deep-space background: gradient, aurora blobs and a faint HUD dot grid.
 * Pro: the aurora drifts slowly (only while Game Space is on screen).
 */
class AuroraView(context: Context) : View(context) {

    private class Blob(val cx: Float, val cy: Float, val r: Float, val color: Int, val ax: Float, val ay: Float, val ph: Float)

    private val blobs = listOf(
        Blob(0.05f, 0.85f, 0.45f, 0x4D00D4FF, 0.07f, 0.05f, 0f),
        Blob(0.90f, 0.20f, 0.50f, 0x4D8A2BE2, 0.06f, 0.08f, 2.1f),
        Blob(0.55f, 0.55f, 0.35f, 0x263B5BFF, 0.09f, 0.06f, 4.2f)
    )
    private val blobPaints = ArrayList<Paint>()
    private val dotPaint = Paint()
    private var theme = "neon"
    private var phase = 0f
    private var frame = 0
    private var anim: ValueAnimator? = null

    init { setTheme("neon") }

    /** neon = deep-space gradient + aurora + grid; amoled = black; transparent = shows your wallpaper. */
    fun setTheme(name: String) {
        theme = name
        background = if (name == "neon") GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(GS.NAVY, GS.MID, GS.PURPLE_DARK)
        ) else null
        invalidate()
    }

    fun setAnimated(on: Boolean) {
        anim?.cancel(); anim = null
        if (on && theme == "neon") {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 24000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    phase = it.animatedValue as Float
                    if ((frame++ and 1) == 0) invalidate()      // ~30 fps is plenty for a slow drift
                }
                start()
            }
        } else { phase = 0f; invalidate() }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        blobPaints.clear()
        val big = max(w, h).toFloat()
        for (b in blobs) {
            val clear = b.color and 0x00FFFFFF
            blobPaints.add(Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(b.cx * w, b.cy * h, b.r * big, b.color, clear, Shader.TileMode.CLAMP)
            })
        }
        // one small tile with a single dot, repeated across the screen
        val s = max(8, context.dpi(28f))
        val tile = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        Canvas(tile).drawCircle(s / 2f, s / 2f, context.dp(1f),
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x0DFFFFFF })
        dotPaint.shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (theme == "transparent") return
        if (theme == "neon") {
            val tau = 6.2832f
            blobPaints.forEachIndexed { i, p ->
                val b = blobs[i]
                c.save()
                c.translate(sin(phase * tau + b.ph) * b.ax * w, cos(phase * tau + b.ph) * b.ay * h)
                c.drawRect(-w, -h, 2 * w, 2 * h, p)
                c.restore()
            }
        }
        c.drawRect(0f, 0f, w, h, dotPaint)
    }
}
