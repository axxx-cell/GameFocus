package com.axxxcell.gamespace.ui

import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.axxxcell.gamespace.BoostUtils

/** Small glass card that shows Boost progress, then the result. */
class BoostDialog(private val a: AppCompatActivity) {

    private val dialog = Dialog(a)
    private val title = TextView(a)
    private val line1 = TextView(a)
    private val line2 = TextView(a)
    private val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal)

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(a.dpi(28f), a.dpi(18f), a.dpi(28f), a.dpi(18f))
            background = Glass.drawable(a, 22f, fill = 0xF2141A33.toInt(), stroke = 0x8800F5FF.toInt())
        }
        title.apply {
            text = "BOOSTING"
            textSize = 16f
            setTextColor(GS.CYAN)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(a.dp(10f), 0f, 0f, GS.CYAN)
        }
        line1.apply {
            text = "Starting..."
            textSize = 14f
            setTextColor(GS.WHITE)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, a.dpi(8f), 0, 0)
        }
        line2.apply {
            textSize = 12f
            setTextColor(GS.TEXT_SECONDARY)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        bar.apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(GS.CYAN)
        }
        box.addView(title)
        box.addView(line1)
        box.addView(line2)
        box.addView(bar, LinearLayout.LayoutParams(a.dpi(220f), a.dpi(8f)).apply { topMargin = a.dpi(12f) })
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    fun show() { dialog.show() }

    fun step(text: String) { line1.text = text }

    fun done(r: BoostUtils.Result) {
        bar.visibility = View.GONE
        title.text = "BOOST COMPLETE"
        title.setTextColor(GS.GREEN_ON)
        title.setShadowLayer(a.dp(10f), 0f, 0f, GS.GREEN_ON)
        line1.text = "Freed ${r.totalMb} MB"
        line2.text = "${r.apps} background apps cleaned"
        line2.visibility = View.VISIBLE
    }

    fun dismiss() { try { dialog.dismiss() } catch (_: Exception) {} }
}
