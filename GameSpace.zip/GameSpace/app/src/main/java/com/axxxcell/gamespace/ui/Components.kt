package com.axxxcell.gamespace.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

fun Context.icon(res: Int, sizeDp: Float, color: Int) = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(color)
    layoutParams = LinearLayout.LayoutParams(dpi(sizeDp), dpi(sizeDp))
}

private fun circle(color: Int) = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

/** Small dot with a soft expanding ring. Animation runs only while pulse(true) and attached. */
class PulseDot(ctx: Context, color: Int) : View(ctx) {
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    private var ring = 0f
    private var want = false
    private var anim: ValueAnimator? = null

    override fun onMeasure(w: Int, h: Int) {
        val s = context.dpi(14f)
        setMeasuredDimension(s, s)
    }

    fun pulse(on: Boolean) {
        want = on
        anim?.cancel(); anim = null
        if (on && isAttachedToWindow) {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1300
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener { ring = it.animatedValue as Float; invalidate() }
                start()
            }
        } else { ring = 0f; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (want) pulse(true) }
    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width * 0.18f
        if (ring > 0f) {
            ringPaint.alpha = ((1f - ring) * 150).toInt()
            c.drawCircle(cx, cy, r + (width / 2f - r) * ring, ringPaint)
        }
        c.drawCircle(cx, cy, r, core)
    }
}

/** Glass stat pill: icon + text. */
class StatPill(ctx: Context, iconRes: Int, initial: String) : LinearLayout(ctx) {
    private val label = TextView(ctx)
    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpi(10f), dpi(3f), dpi(12f), dpi(3f))
        glass(cornerDp = 14f)
        addView(ctx.icon(iconRes, 14f, GS.CYAN))
        label.apply {
            text = initial
            textSize = 12f
            setTextColor(GS.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            setPadding(dpi(6f), 0, 0, 0)
        }
        addView(label)
    }
    fun setText(t: String) { label.text = t }
}

/** Capsule toggle card: icon (+ live value when ON), label, LED dots. */
class ToggleCard(ctx: Context, iconRes: Int, labelText: String) : LinearLayout(ctx) {
    var isOn = false
        private set
    private val iconView = ctx.icon(iconRes, 20f, GS.TEXT_SECONDARY)
    private val valueView = TextView(ctx)
    private val title = TextView(ctx)
    private val leds = Array(3) { View(ctx) }
    private var valueText: String? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(dpi(8f), dpi(4f), dpi(8f), dpi(4f))
        isClickable = true
        isFocusable = true

        val top = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        top.addView(iconView)
        valueView.apply {
            textSize = 11f
            setTextColor(GS.CYAN)
            typeface = Typeface.MONOSPACE
            visibility = GONE
            setPadding(dpi(6f), 0, 0, 0)
        }
        top.addView(valueView)
        addView(top)

        title.apply {
            text = labelText
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        addView(title, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(2f) })

        val ledRow = LinearLayout(ctx).apply { orientation = HORIZONTAL }
        for (led in leds) {
            ledRow.addView(led, LinearLayout.LayoutParams(dpi(5f), dpi(5f)).apply {
                marginStart = dpi(2f); marginEnd = dpi(2f)
            })
        }
        addView(ledRow, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(3f) })
        setOn(false)
    }

    fun setOn(on: Boolean) {
        isOn = on
        glass(
            cornerDp = 16f,
            fill = if (on) 0xB3252D5A.toInt() else GS.GLASS_PILL_70,
            stroke = if (on) 0x9900F5FF.toInt() else GS.CYAN_BORDER_20
        )
        iconView.setColorFilter(if (on) GS.CYAN else GS.TEXT_SECONDARY)
        title.setTextColor(if (on) GS.WHITE else GS.TEXT_SECONDARY)
        leds.forEachIndexed { i, led ->
            led.background = circle(if (on && i < 3) GS.GREEN_ON else 0x44FFFFFF)
        }
        refreshValue()
    }

    fun setValue(v: String?) { valueText = v; refreshValue() }

    private fun refreshValue() {
        val show = isOn && valueText != null
        valueView.visibility = if (show) VISIBLE else GONE
        if (show) valueView.text = valueText
    }
}

/** Glass bottom bar: Home / Stats / Games / Boost / Settings. */
class BottomNav(
    ctx: Context,
    items: List<Pair<Int, String>>,
    private val onSelect: (Int) -> Unit
) : LinearLayout(ctx) {
    private val icons = ArrayList<ImageView>()
    private val labels = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        glass(cornerDp = 18f)
        items.forEachIndexed { i, item ->
            val cell = LinearLayout(ctx).apply {
                orientation = VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
            }
            cell.setOnClickListener { cell.haptic(); select(i); onSelect(i) }
            val ic = ctx.icon(item.first, 18f, GS.TEXT_SECONDARY)
            val tv = TextView(ctx).apply {
                text = item.second
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(GS.TEXT_SECONDARY)
            }
            cell.addView(ic)
            cell.addView(tv)
            addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f))
            icons.add(ic); labels.add(tv)
        }
        select(0)
    }

    fun select(index: Int) {
        for (i in icons.indices) {
            val c = if (i == index) GS.CYAN else GS.TEXT_SECONDARY
            icons[i].setColorFilter(c)
            labels[i].setTextColor(c)
        }
    }
}
