package com.axxxcell.gamespace.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.WindowManager
import android.graphics.PixelFormat
import android.view.Gravity

/** 10 crosshair styles, drawn with a dark outline so they stay visible on any background. */
class CrosshairView(ctx: Context) : View(ctx) {

    companion object { const val STYLES = 10 }

    var style = 0
        set(v) { field = v.coerceIn(0, STYLES - 1); invalidate() }

    private val main = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = GS.GREEN_ON; strokeCap = Paint.Cap.ROUND
        strokeWidth = ctx.dp(2f)
    }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xAA000000.toInt(); strokeCap = Paint.Cap.ROUND
        strokeWidth = ctx.dp(4.5f)
    }
    private val fillMain = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = GS.GREEN_ON }
    private val fillOut = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xAA000000.toInt() }

    override fun onMeasure(w: Int, h: Int) {
        val s = context.dpi(64f)
        setMeasuredDimension(s, s)
    }

    private fun both(c: Canvas, draw: (Canvas, Paint) -> Unit) { draw(c, outline); draw(c, main) }

    private fun dot(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawCircle(cx, cy, r + context.dp(1.3f), fillOut)
        c.drawCircle(cx, cy, r, fillMain)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val d = context.dp(1f)

        fun cross(gap: Float, len: Float, top: Boolean = true) = both(c) { cv, p ->
            cv.drawLine(cx - gap * d - len * d, cy, cx - gap * d, cy, p)
            cv.drawLine(cx + gap * d, cy, cx + gap * d + len * d, cy, p)
            cv.drawLine(cx, cy + gap * d, cx, cy + gap * d + len * d, p)
            if (top) cv.drawLine(cx, cy - gap * d - len * d, cx, cy - gap * d, p)
        }
        fun ring(r: Float) = both(c) { cv, p -> cv.drawCircle(cx, cy, r * d, p) }

        when (style) {
            0 -> dot(c, cx, cy, 3f * d)
            1 -> cross(4f, 10f)
            2 -> cross(0f, 9f)
            3 -> ring(11f)
            4 -> { ring(11f); dot(c, cx, cy, 2f * d) }
            5 -> { ring(12f); cross(4f, 8f) }
            6 -> cross(3f, 11f, top = false)
            7 -> {
                val path = Path().apply {
                    moveTo(cx, cy - 11 * d); lineTo(cx + 11 * d, cy); lineTo(cx, cy + 11 * d); lineTo(cx - 11 * d, cy); close()
                }
                both(c) { cv, p -> cv.drawPath(path, p) }
                dot(c, cx, cy, 1.8f * d)
            }
            8 -> {
                val o = 12f * d; val l = 6f * d
                both(c) { cv, p ->
                    for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                        cv.drawLine(cx + sx * o, cy + sy * o, cx + sx * (o - l), cy + sy * o, p)
                        cv.drawLine(cx + sx * o, cy + sy * o, cx + sx * o, cy + sy * (o - l), p)
                    }
                }
            }
            else -> {
                val path = Path().apply {
                    moveTo(cx - 9 * d, cy + 4 * d); lineTo(cx, cy - 5 * d); lineTo(cx + 9 * d, cy + 4 * d)
                }
                both(c) { cv, p -> cv.drawPath(path, p) }
                dot(c, cx, cy + 9 * d, 1.8f * d)
            }
        }
    }
}

/** Puts the crosshair in the middle of the screen as a touch-through overlay. */
class CrosshairOverlay(private val ctx: Context, private val wm: WindowManager) {
    private var view: CrosshairView? = null

    fun show(style: Int) {
        if (view == null) {
            val v = CrosshairView(ctx)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.CENTER }
            try { wm.addView(v, lp); view = v } catch (_: Exception) { return }
        }
        view?.style = style
    }

    fun hide() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}
