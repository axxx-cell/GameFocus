package com.axxxcell.gamespace.ui

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.Window
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.axxxcell.gamespace.ProManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GlassDialogs {

    fun make(a: AppCompatActivity, widthDp: Float = 420f, build: (LinearLayout, Dialog) -> Unit): Dialog {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dpi(20f), a.dpi(16f), a.dpi(20f), a.dpi(16f))
            background = Glass.drawable(a, 20f, fill = 0xFF141A33.toInt(), stroke = 0x6600F5FF)
        }
        build(box, d)
        val scroll = ScrollView(a).apply { isVerticalScrollBarEnabled = false; addView(box) }
        d.setContentView(scroll)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.show()
        val dm = a.resources.displayMetrics
        d.window?.setLayout(a.dpi(widthDp).coerceAtMost((dm.widthPixels * 0.92f).toInt()), WRAP)
        return d
    }

    fun title(c: Context, text: String, color: Int = GS.CYAN) = TextView(c).apply {
        this.text = text
        textSize = 16f
        setTextColor(color)
        typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
        letterSpacing = 0.12f
        setShadowLayer(c.dp(8f), 0f, 0f, color)
    }

    fun body(c: Context, text: String, size: Float = 12f, color: Int = GS.TEXT_SECONDARY) = TextView(c).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        setPadding(0, c.dpi(8f), 0, 0)
    }

    fun button(c: Context, text: String, filled: Boolean, onClick: () -> Unit) = TextView(c).apply {
        this.text = text
        textSize = 12f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.1f
        setTextColor(if (filled) GS.WHITE else GS.CYAN)
        if (filled) {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(GS.PURPLE, 0xFF00E5FF.toInt())
            ).apply { cornerRadius = c.dp(18f) }
        } else glass(cornerDp = 18f)
        setOnClickListener { haptic(); onClick() }
    }

    fun row(c: Context, vararg buttons: TextView): LinearLayout {
        val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.forEachIndexed { i, b ->
            r.addView(b, LinearLayout.LayoutParams(0, c.dpi(36f), 1f).apply { if (i > 0) marginStart = c.dpi(8f) })
        }
        return r
    }
}

object DonateDialog {
    fun show(a: AppCompatActivity, code: String, reason: String?, pay: ProManager.PayInfo, onCheck: () -> Unit) {
        GlassDialogs.make(a) { box, d ->
            box.addView(GlassDialogs.title(a, "DONATE"))
            if (reason != null) box.addView(GlassDialogs.body(a, reason, 13f, GS.WHITE))
            box.addView(GlassDialogs.body(a,
                "Game Space is free to use. Donating supports its development and switches on the Pro features: " +
                "Auto Mode, HUD, crosshair, touch lock, WhatsApp button, no recording watermark, themes and full effects."))
            box.addView(GlassDialogs.body(a, pay.price, 13f, GS.WHITE))
            box.addView(GlassDialogs.body(a, "YOUR DEVICE CODE", 10f))
            box.addView(TextView(a).apply {
                text = code
                textSize = 24f
                setTextColor(GS.CYAN)
                typeface = Typeface.MONOSPACE
                letterSpacing = 0.15f
                setShadowLayer(a.dp(8f), 0f, 0f, GS.CYAN)
            })
            box.addView(GlassDialogs.body(a,
                "1. Donate by GCash to ${pay.gcash}\n" +
                "2. Email your receipt and device code to ${pay.email}\n" +
                "3. Pro switches on by itself when your phone is online."))
            val copy = GlassDialogs.button(a, "COPY CODE", false) {
                val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("device code", code))
                Toast.makeText(a, "Copied", Toast.LENGTH_SHORT).show()
            }
            val check = GlassDialogs.button(a, "CHECK AGAIN", true) { onCheck() }
            val close = GlassDialogs.button(a, "CLOSE", false) { d.dismiss() }
            box.addView(GlassDialogs.row(a, copy, check), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(14f) })
            box.addView(GlassDialogs.row(a, close), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(8f) })
        }
    }
}

object StatsDialog {
    fun show(a: AppCompatActivity, sessions: List<String>) {
        GlassDialogs.make(a) { box, d ->
            box.addView(GlassDialogs.title(a, "STATS"))
            if (sessions.isEmpty()) {
                box.addView(GlassDialogs.body(a, "No sessions yet. Turn on Auto Mode and play a game."))
            }
            val fmt = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
            for (line in sessions.take(20)) {
                val p = line.split("|")
                if (p.size < 5) continue
                val min = (p[3].toLongOrNull() ?: 0L) / 60000
                val freed = p[4].toIntOrNull() ?: 0
                val whenTxt = fmt.format(Date(p[2].toLongOrNull() ?: 0L))
                box.addView(GlassDialogs.body(a, p[1], 14f, GS.WHITE))
                box.addView(TextView(a).apply {
                    text = whenTxt + "  \u2022  " + (if (min < 1) "<1min" else "${min}min") + (if (freed > 0) "  \u2022  Freed ${freed}MB" else "")
                    textSize = 11f
                    setTextColor(GS.TEXT_SECONDARY)
                    typeface = Typeface.MONOSPACE
                })
            }
            box.addView(GlassDialogs.row(a, GlassDialogs.button(a, "CLOSE", false) { d.dismiss() }),
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(14f) })
        }
    }
}

object SettingsDialog {
    fun show(
        a: AppCompatActivity,
        isPro: Boolean,
        expiryMs: Long,
        code: String,
        currentTheme: String,
        onTheme: (String) -> Unit,
        onDonate: () -> Unit
    ) {
        GlassDialogs.make(a) { box, d ->
            box.addView(GlassDialogs.title(a, "SETTINGS"))

            box.addView(GlassDialogs.body(a, "THEME", 10f))
            val chips = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            listOf("neon" to "Neon Gaming", "amoled" to "AMOLED", "transparent" to "Transparent").forEachIndexed { i, (key, name) ->
                val on = key == currentTheme
                chips.addView(TextView(a).apply {
                    text = if (i > 0 && !isPro) "$name  PRO" else name
                    textSize = 11f
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (on) GS.CYAN else GS.TEXT_SECONDARY)
                    glass(
                        cornerDp = 14f,
                        fill = if (on) 0xB3252D5A.toInt() else GS.GLASS_PILL_70,
                        stroke = if (on) 0x9900F5FF.toInt() else GS.CYAN_BORDER_20
                    )
                    setPadding(a.dpi(8f), a.dpi(6f), a.dpi(8f), a.dpi(6f))
                    setOnClickListener { haptic(); onTheme(key); d.dismiss() }
                }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i > 0) marginStart = a.dpi(6f) })
            }
            box.addView(chips, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(4f) })

            box.addView(GlassDialogs.body(a, "PRO", 10f))
            val status = if (isPro) {
                "Pro is on until " + SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(expiryMs))
            } else "Free version"
            box.addView(GlassDialogs.body(a, status, 14f, if (isPro) GS.GREEN_ON else GS.WHITE))
            box.addView(GlassDialogs.body(a, "Device code: $code", 11f))

            box.addView(GlassDialogs.body(a, "ABOUT", 10f))
            val ver = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName } catch (e: Exception) { "" }
            box.addView(GlassDialogs.body(a,
                "Game Space $ver\nAuto Mode only watches which app is in front. It never reads your screen."))

            val donate = GlassDialogs.button(a, "DONATE", true) { d.dismiss(); onDonate() }
            val close = GlassDialogs.button(a, "CLOSE", false) { d.dismiss() }
            box.addView(GlassDialogs.row(a, donate, close), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(14f) })
        }
    }
}
