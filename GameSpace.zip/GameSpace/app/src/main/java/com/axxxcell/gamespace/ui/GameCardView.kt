package com.axxxcell.gamespace.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.axxxcell.gamespace.R
import com.axxxcell.gamespace.data.GameRepository
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Particles that fly out of the BOOST button. Only animates during the burst. */
class ParticleBurstView(ctx: Context) : View(ctx) {
    private class P(val a: Float, val speed: Float, val size: Float, val color: Int)

    private var parts: List<P> = emptyList()
    private var t = 0f
    private var ox = 0f
    private var oy = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var anim: ValueAnimator? = null

    fun burst(x: Float, y: Float) {
        ox = x; oy = y
        val rnd = java.util.Random()
        val colors = intArrayOf(GS.CYAN, GS.PURPLE, GS.WHITE, GS.GREEN_ON)
        parts = List(30) {
            P(
                rnd.nextFloat() * 6.2832f,
                context.dp(40f) + rnd.nextFloat() * context.dp(90f),
                context.dp(2f) + rnd.nextFloat() * context.dp(3f),
                colors[rnd.nextInt(colors.size)]
            )
        }
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { parts = emptyList(); invalidate() }
            })
            start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: android.graphics.Canvas) {
        if (parts.isEmpty()) return
        for (p in parts) {
            val d = p.speed * (1f - (1f - t) * (1f - t))
            paint.color = p.color
            paint.alpha = ((1f - t) * 255).toInt().coerceIn(0, 255)
            c.drawCircle(ox + cos(p.a) * d, oy + sin(p.a) * d, p.size * (1f - t * 0.5f), paint)
        }
    }
}

/** One game card: cover gradient, icon capsule, category badge, name, status, BOOST button. */
class GameCardView(ctx: Context) : FrameLayout(ctx) {

    private val bgView = View(ctx)
    private val bigIcon = ImageView(ctx).apply { scaleType = ImageView.ScaleType.FIT_CENTER; alpha = 0.28f }
    private val scrim = View(ctx).apply {
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x000A0E1E, 0xEE0A0E1E.toInt())
        )
    }
    private val capsuleIcon = ImageView(ctx)
    private val badge = TextView(ctx)
    private val nameView = TextView(ctx)
    private val statusView = TextView(ctx)
    private val burstView = ParticleBurstView(ctx)
    val boostButton = LinearLayout(ctx)

    private var active = false
    private var glow = 0f
    private var pulseAnim: ValueAnimator? = null
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = GS.CYAN }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = GS.CYAN }
    private val shimmerPaint = Paint()
    private val bracketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = GS.CYAN; strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()

    /** 0..1 progress of the holographic shimmer sweep (0 = off). */
    var shimmer = 0f
        set(v) { field = v; invalidate() }

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, context.dp(18f))
            }
        }
        clipToOutline = true
        cameraDistance = context.dp(900f) * 10f
        isClickable = true

        addView(bgView, LayoutParams(MATCH, MATCH))
        addView(bigIcon, LayoutParams(dpi(120f), dpi(120f), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            marginEnd = -dpi(14f)
        })
        addView(scrim, LayoutParams(MATCH, MATCH))

        val capsule = FrameLayout(ctx).apply { glass(cornerDp = 12f, fill = 0x990A0E1E.toInt(), stroke = 0xAA00F5FF.toInt()) }
        capsule.addView(capsuleIcon, LayoutParams(dpi(26f), dpi(26f), Gravity.CENTER))
        addView(capsule, LayoutParams(dpi(36f), dpi(36f), Gravity.TOP or Gravity.START).apply {
            setMargins(dpi(10f), dpi(10f), 0, 0)
        })

        badge.apply {
            textSize = 9f
            setTextColor(GS.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setPadding(dpi(8f), dpi(3f), dpi(8f), dpi(3f))
            glass(cornerDp = 10f, fill = 0x99252D5A.toInt(), stroke = 0x6600F5FF)
        }
        addView(badge, LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dpi(10f), dpi(10f), 0)
        })

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        nameView.apply {
            textSize = 15f
            setTextColor(GS.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusView.apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            maxLines = 1
        }
        col.addView(nameView)
        col.addView(statusView, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(1f) })

        boostButton.apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(GS.PURPLE, 0xFF00E5FF.toInt())
            ).apply { cornerRadius = context.dp(16f) }
            isClickable = true
        }
        boostButton.pressFeel()
        boostButton.addView(ctx.icon(R.drawable.ic_rocket, 15f, GS.WHITE))
        boostButton.addView(TextView(ctx).apply {
            text = "BOOST"
            textSize = 12f
            setTextColor(GS.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setPadding(dpi(6f), 0, 0, 0)
        })
        col.addView(boostButton, LinearLayout.LayoutParams(MATCH, dpi(30f)).apply { topMargin = dpi(6f) })

        addView(col, LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            setMargins(dpi(12f), 0, dpi(12f), dpi(10f))
        })
        addView(burstView, LayoutParams(MATCH, MATCH))
    }

    fun bind(app: GameRepository.App, isActive: Boolean) {
        val hue = (Math.abs(app.pkg.hashCode()) % 360).toFloat()
        val tint = Color.HSVToColor(floatArrayOf(hue, 0.65f, 0.50f))
        bgView.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint, GS.NAVY))
        bigIcon.setImageDrawable(app.icon)
        capsuleIcon.setImageDrawable(app.icon.constantState?.newDrawable()?.mutate() ?: app.icon)
        nameView.text = app.label.uppercase()
        badge.text = app.category
        setActive(isActive)
    }

    fun setActive(on: Boolean) {
        active = on
        statusView.text = if (on) "Optimized • Boost ON" else "STANDBY • READY"
        statusView.setTextColor(if (on) GS.CYAN else 0xFF7FD9E8.toInt())
        pulseAnim?.cancel(); pulseAnim = null
        if (on && isAttachedToWindow) startPulse() else { glow = 0f; invalidate() }
    }

    private fun startPulse() {
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { glow = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun burst() {
        burstView.burst(width / 2f, height - context.dp(25f))
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (active && pulseAnim == null) startPulse() }
    override fun onDetachedFromWindow() { pulseAnim?.cancel(); pulseAnim = null; super.onDetachedFromWindow() }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (shimmer > 0.001f && shimmer < 0.999f) {
            val band = w * 0.45f
            val x = -band + (w + band) * shimmer
            shimmerPaint.shader = LinearGradient(
                x, 0f, x + band, band * 0.6f,
                intArrayOf(0x00FFFFFF, 0x3300F5FF, 0x338A2BE2, 0x00FFFFFF),
                floatArrayOf(0f, 0.4f, 0.6f, 1f),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w, h, shimmerPaint)
        }
        // HUD corner brackets
        val bl = context.dp(14f)
        val bi = context.dp(8f)
        bracketPaint.strokeWidth = context.dp(2f)
        bracketPaint.alpha = if (active) 255 else 140
        for (sx in intArrayOf(0, 1)) for (sy in intArrayOf(0, 1)) {
            val x = if (sx == 0) bi else w - bi
            val y = if (sy == 0) bi else h - bi
            val dx = if (sx == 0) bl else -bl
            val dy = if (sy == 0) bl else -bl
            c.drawLine(x, y, x + dx, y, bracketPaint)
            c.drawLine(x, y, x, y + dy, bracketPaint)
        }
        if (active) {
            val r = context.dp(18f)
            glowPaint.strokeWidth = context.dp(8f)
            glowPaint.alpha = (40 + 50 * glow).toInt()
            rect.set(context.dp(3f), context.dp(3f), w - context.dp(3f), h - context.dp(3f))
            c.drawRoundRect(rect, r, r, glowPaint)
            borderPaint.strokeWidth = context.dp(2.5f)
            borderPaint.alpha = (120 + 135 * glow).toInt()
            rect.set(context.dp(1.5f), context.dp(1.5f), w - context.dp(1.5f), h - context.dp(1.5f))
            c.drawRoundRect(rect, r, r, borderPaint)
        }
    }
}
