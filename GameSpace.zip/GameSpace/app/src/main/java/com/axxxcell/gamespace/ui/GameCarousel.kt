package com.axxxcell.gamespace.ui

import android.content.Context
import android.graphics.Rect
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.axxxcell.gamespace.data.GameRepository
import kotlin.math.abs

/** Horizontal Netflix-style carousel: 3D tilt while scrolling + horizontal motion blur (Android 12+). */
class GameCarousel(ctx: Context) : RecyclerView(ctx) {

    init {
        layoutManager = LinearLayoutManager(ctx, HORIZONTAL, false)
        overScrollMode = OVER_SCROLL_NEVER
        clipToPadding = false
        clipChildren = false
        addItemDecoration(object : ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: State) {
                outRect.right = ctx.dpi(12f)
            }
        })
        addOnScrollListener(object : OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) { applyTilt(); updateBlur(dx) }
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == SCROLL_STATE_IDLE) clearBlur()
            }
        })
        addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyTilt() }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pivotX = w / 2f
        pivotY = h * 0.95f
    }

    /** Aerial / bird's-eye mode: the whole row leans back like cards lying on a tilted table. */
    fun setAerial(on: Boolean, animate: Boolean = true) {
        cameraDistance = resources.displayMetrics.density * 12000f
        val target = if (on) 26f else 0f
        if (animate) animate().rotationX(target).setDuration(350).start() else rotationX = target
    }

    fun applyTilt() {
        val mid = width / 2f
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val off = (((v.left + v.right) / 2f - mid) / width).coerceIn(-1f, 1f)
            v.rotationY = -off * 14f
            val s = 1f - abs(off) * 0.05f
            v.scaleX = s
            v.scaleY = s
        }
    }

    fun setShimmer(p: Float) {
        for (i in 0 until childCount) (getChildAt(i) as? GameCardView)?.shimmer = p
    }

    private fun updateBlur(dx: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        val r = (abs(dx) / 4f).coerceAtMost(14f)
        if (r < 1.5f) clearBlur()
        else setRenderEffect(RenderEffect.createBlurEffect(r, 0.1f, Shader.TileMode.CLAMP))
    }

    private fun clearBlur() {
        if (Build.VERSION.SDK_INT >= 31) setRenderEffect(null)
    }
}

class GamesAdapter(
    private val onBoost: (GameRepository.App, GameCardView) -> Unit,
    private val onOpen: (GameRepository.App) -> Unit,
    private val onRemove: (GameRepository.App) -> Unit
) : RecyclerView.Adapter<GamesAdapter.VH>() {

    class VH(val card: GameCardView) : RecyclerView.ViewHolder(card)

    private var items: List<GameRepository.App> = emptyList()
    private var activePkg: String? = null

    fun submit(list: List<GameRepository.App>) { items = list; notifyDataSetChanged() }

    fun setActive(pkg: String?) { activePkg = pkg; notifyDataSetChanged() }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
        val card = GameCardView(parent.context)
        card.layoutParams = RecyclerView.LayoutParams(parent.context.dpi(280f), MATCH)
        return VH(card)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val app = items[position]
        h.card.bind(app, app.pkg == activePkg)
        h.card.boostButton.setOnClickListener { it.haptic(); onBoost(app, h.card) }
        h.card.setOnClickListener { onOpen(app) }
        h.card.setOnLongClickListener { it.haptic(); onRemove(app); true }
    }
}
