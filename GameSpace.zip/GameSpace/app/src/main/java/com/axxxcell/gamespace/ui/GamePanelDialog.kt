package com.axxxcell.gamespace.ui

import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.axxxcell.gamespace.R
import com.axxxcell.gamespace.data.GameRepository

/**
 * Game panel opened by tapping a card: live stats on the left, the game in the middle,
 * Balanced / Ultra and LAUNCH GAME on the right.
 */
object GamePanelDialog {

    fun show(
        a: AppCompatActivity,
        app: GameRepository.App,
        playedMin: Int,
        mode: String,
        onMode: (String) -> Unit,
        stats: () -> List<Pair<String, String>>,
        onLaunch: () -> Unit
    ) {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dpi(16f), a.dpi(14f), a.dpi(16f), a.dpi(14f))
            hud(cutDp = 18f, on = true)
        }

        // ---- left: live stats ----
        val statsCol = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val values = ArrayList<TextView>()
        for (i in 0 until 4) {
            val tile = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(a.dpi(10f), a.dpi(4f), a.dpi(10f), a.dpi(4f))
                hud(cutDp = 8f)
            }
            val label = TextView(a).apply {
                textSize = 8f; setTextColor(GS.TEXT_SECONDARY); typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.12f
            }
            val value = TextView(a).apply {
                textSize = 14f; setTextColor(GS.CYAN); typeface = Typeface.MONOSPACE
                setTypeface(typeface, Typeface.BOLD); maxLines = 1
            }
            tile.addView(label); tile.addView(value)
            values.add(value)
            tile.tag = label
            statsCol.addView(tile, LinearLayout.LayoutParams(MATCH, WRAP).apply { if (i > 0) topMargin = a.dpi(6f) })
        }
        val handler = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                stats().forEachIndexed { i, (l, v) ->
                    if (i < values.size) {
                        ((statsCol.getChildAt(i).tag) as TextView).text = l
                        values[i].text = v
                    }
                }
                handler.postDelayed(this, 1500)
            }
        }
        d.setOnDismissListener { handler.removeCallbacks(tick) }
        tick.run()
        root.addView(statsCol, LinearLayout.LayoutParams(0, WRAP, 3f))

        // ---- middle: the game ----
        val mid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val iconBox = android.widget.FrameLayout(a).apply {
            setPadding(a.dpi(8f), a.dpi(8f), a.dpi(8f), a.dpi(8f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = a.dp(22f)
                setColor(0x2200F5FF)
                setStroke(a.dpi(2f), GS.CYAN)
            }
        }
        iconBox.addView(ImageView(a).apply { setImageDrawable(app.icon) }, android.widget.FrameLayout.LayoutParams(a.dpi(64f), a.dpi(64f)))
        mid.addView(iconBox)
        mid.addView(TextView(a).apply {
            text = app.label
            textSize = 17f
            setTextColor(GS.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setPadding(0, a.dpi(8f), 0, 0)
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        mid.addView(TextView(a).apply {
            text = if (playedMin >= 1) "Played today about $playedMin minutes" else "Not played today yet"
            textSize = 11f
            setTextColor(GS.TEXT_SECONDARY)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(mid, LinearLayout.LayoutParams(0, WRAP, 3.5f).apply { marginStart = a.dpi(10f); marginEnd = a.dpi(10f) })

        // ---- right: mode + launch ----
        val right = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val segment = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = a.dp(16f)
                setColor(0x33FFFFFF)
            }
            setPadding(a.dpi(3f), a.dpi(3f), a.dpi(3f), a.dpi(3f))
        }
        val desc = TextView(a).apply {
            textSize = 10f
            setTextColor(GS.TEXT_SECONDARY)
            setPadding(0, a.dpi(6f), 0, 0)
        }
        val chips = HashMap<String, TextView>()
        fun paint(sel: String) {
            for ((key, tv) in chips) {
                val on = key == sel
                tv.setTextColor(if (on) 0xFF04202B.toInt() else GS.WHITE)
                tv.background = if (on) GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = a.dp(13f)
                    setColor(0xFF00E5FF.toInt())
                } else null
            }
            desc.text = if (sel == "ultra") "Also blocks notifications and mutes calls while you play."
                        else "Closes background apps before you play."
        }
        for ((key, name) in listOf("balanced" to "Balanced", "ultra" to "Ultra")) {
            val tv = TextView(a).apply {
                text = name
                textSize = 12f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(a.dpi(6f), a.dpi(6f), a.dpi(6f), a.dpi(6f))
                setOnClickListener { haptic(); paint(key); onMode(key) }
            }
            chips[key] = tv
            segment.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(mode)
        right.addView(segment, LinearLayout.LayoutParams(MATCH, WRAP))
        right.addView(desc, LinearLayout.LayoutParams(MATCH, WRAP))

        val launch = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF00C2E0.toInt(), 0xFF00F5FF.toInt())
            ).apply { cornerRadius = a.dp(20f) }
            setOnClickListener { haptic(); d.dismiss(); onLaunch() }
        }
        launch.pressFeel()
        launch.addView(a.icon(R.drawable.ic_rocket, 16f, 0xFF04202B.toInt()))
        launch.addView(TextView(a).apply {
            text = "LAUNCH GAME"
            textSize = 13f
            setTextColor(0xFF04202B.toInt())
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.1f
            setPadding(a.dpi(6f), 0, 0, 0)
        })
        right.addView(launch, LinearLayout.LayoutParams(MATCH, a.dpi(40f)).apply { topMargin = a.dpi(10f) })
        root.addView(right, LinearLayout.LayoutParams(0, WRAP, 4f))

        d.setContentView(root)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.show()
        val dm = a.resources.displayMetrics
        d.window?.setLayout(a.dpi(580f).coerceAtMost((dm.widthPixels * 0.94f).toInt()), WRAP)
    }
}
