package com.axxxcell.gamespace.ui

import android.content.Context
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View

object GS {
    const val NAVY = 0xFF0A0E1E.toInt()
    const val MID = 0xFF141A33.toInt()
    const val PURPLE_DARK = 0xFF1A1040.toInt()
    const val GLASS = 0xFF252D5A.toInt()
    const val GLASS_PILL_70 = 0xB31E2450.toInt()   // #1E2450 @ 70%
    const val CYAN = 0xFF00F5FF.toInt()
    const val CYAN_BORDER_20 = 0x3300F5FF          // cyan @ 20%
    const val PURPLE = 0xFF8A2BE2.toInt()
    const val GREEN_ON = 0xFF00FF88.toInt()
    const val WHITE = 0xFFFFFFFF.toInt()
    const val TEXT_SECONDARY = 0xFF8B9CC5.toInt()
    const val ORANGE = 0xFFFFA726.toInt()
    const val RED = 0xFFFF5252.toInt()
}

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = dp(v).toInt()
fun View.dp(v: Float): Float = context.dp(v)
fun View.dpi(v: Float): Int = context.dpi(v)

object Glass {
    /** Translucent "glass" shape: tinted fill + thin cyan border. Works on every API level. */
    fun drawable(
        ctx: Context,
        cornerDp: Float = 16f,
        fill: Int = GS.GLASS_PILL_70,
        stroke: Int = GS.CYAN_BORDER_20,
        strokeDp: Float = 1f
    ) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = ctx.dp(cornerDp)
        setColor(fill)
        setStroke(ctx.dpi(strokeDp).coerceAtLeast(1), stroke)
    }
}

fun View.glass(
    cornerDp: Float = 16f,
    fill: Int = GS.GLASS_PILL_70,
    stroke: Int = GS.CYAN_BORDER_20
) { background = Glass.drawable(context, cornerDp, fill, stroke) }

/** Blurs this view's own content (Android 12+). Older phones: no-op, the translucent fill is the fallback. */
fun View.blurContent(radiusPx: Float) {
    if (Build.VERSION.SDK_INT >= 31) {
        setRenderEffect(RenderEffect.createBlurEffect(radiusPx, radiusPx, Shader.TileMode.CLAMP))
    }
}

fun View.haptic() {
    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
}
