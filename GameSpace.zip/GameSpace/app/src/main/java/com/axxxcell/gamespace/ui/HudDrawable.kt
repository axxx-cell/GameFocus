package com.axxxcell.gamespace.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View

/** Sci-fi panel: two cut corners, dark glass fill, cyan-to-purple neon edge, bright accents on the cuts. */
class HudDrawable(private val ctx: Context, cutDp: Float, on: Boolean) : Drawable() {

    var on: Boolean = on
        set(v) { field = v; rebuild(); invalidateSelf() }

    private val cut = ctx.dp(cutDp)
    private val path = Path()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(1.5f) }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(5f) }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(2.5f); color = GS.CYAN; strokeCap = Paint.Cap.ROUND
    }

    override fun onBoundsChange(b: Rect) { rebuild() }

    private fun rebuild() {
        val b = bounds
        if (b.isEmpty) return
        val inset = ctx.dp(1f)
        val l = b.left + inset; val t = b.top + inset; val r = b.right - inset; val bm = b.bottom - inset
        path.reset()
        path.moveTo(l + cut, t); path.lineTo(r, t); path.lineTo(r, bm - cut)
        path.lineTo(r - cut, bm); path.lineTo(l, bm); path.lineTo(l, t + cut); path.close()
        val top = if (on) 0xE61B3A5C.toInt() else 0xE6182046.toInt()
        val bottom = if (on) 0xE60E2038.toInt() else 0xE60C1028.toInt()
        fillPaint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        val edge = LinearGradient(b.left.toFloat(), 0f, b.right.toFloat(), 0f, GS.CYAN, 0xFF8A2BE2.toInt(), Shader.TileMode.CLAMP)
        borderPaint.shader = edge
        glowPaint.shader = edge
    }

    override fun draw(c: Canvas) {
        if (bounds.isEmpty) return
        c.drawPath(path, fillPaint)
        glowPaint.alpha = if (on) 80 else 32
        c.drawPath(path, glowPaint)
        borderPaint.alpha = if (on) 255 else 160
        c.drawPath(path, borderPaint)
        tickPaint.alpha = if (on) 255 else 190
        val b = bounds
        val inset = ctx.dp(1f)
        val l = b.left + inset; val t = b.top + inset; val r = b.right - inset; val bm = b.bottom - inset
        c.drawLine(l, t + cut, l + cut, t, tickPaint)          // top-left cut
        c.drawLine(r - cut, bm, r, bm - cut, tickPaint)        // bottom-right cut
        c.drawLine(l + cut + ctx.dp(5f), t, l + cut + ctx.dp(16f), t, tickPaint)
        c.drawLine(r - cut - ctx.dp(5f), bm, r - cut - ctx.dp(16f), bm, tickPaint)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun View.hud(cutDp: Float = 10f, on: Boolean = false) {
    background = HudDrawable(context, cutDp, on)
}
