package com.axxxcell.gamespace.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.axxxcell.gamespace.data.GameRepository

/** Full-screen launch moment: the game icon pops in, a ring fills, then the game opens. */
class LaunchOverlay(ctx: Context) : FrameLayout(ctx) {

    private class Ring(ctx: Context) : View(ctx) {
        var p = 0f
        private val rect = RectF()
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = ctx.dp(5f); color = 0x22FFFFFF
        }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = ctx.dp(5f); strokeCap = Paint.Cap.ROUND; color = GS.CYAN
        }
        override fun onDraw(c: Canvas) {
            val pad = context.dp(4f)
            rect.set(pad, pad, width - pad, height - pad)
            c.drawArc(rect, 0f, 360f, false, track)
            c.drawArc(rect, -90f, 360f * p, false, arc)
        }
    }

    private val ring = Ring(ctx)
    private val icon = ImageView(ctx)
    private val title = TextView(ctx)
    private val status = TextView(ctx)

    init {
        setBackgroundColor(0xF2080C1C.toInt())
        isClickable = true            // swallow touches while launching
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val box = FrameLayout(ctx)
        box.addView(ring, FrameLayout.LayoutParams(dpi(120f), dpi(120f)))
        box.addView(icon, FrameLayout.LayoutParams(dpi(70f), dpi(70f), Gravity.CENTER))
        col.addView(box, LinearLayout.LayoutParams(dpi(120f), dpi(120f)))
        title.apply {
            textSize = 18f; setTextColor(GS.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC); letterSpacing = 0.12f
            setPadding(0, dpi(14f), 0, 0)
        }
        status.apply { textSize = 11f; setTextColor(GS.CYAN); gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE }
        col.addView(title, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(status, LinearLayout.LayoutParams(WRAP, WRAP))
        addView(col, LayoutParams(WRAP, WRAP, Gravity.CENTER))
    }

    fun play(app: GameRepository.App, onDone: () -> Unit) {
        icon.setImageDrawable(app.icon)
        title.text = app.label.uppercase()
        status.text = "Preparing..."
        alpha = 0f
        animate().alpha(1f).setDuration(180).start()
        icon.scaleX = 0.6f; icon.scaleY = 0.6f
        icon.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(2f)).start()
        haptic()
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 950
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                ring.p = f
                ring.invalidate()
                status.text = when {
                    f < 0.40f -> "Preparing..."
                    f < 0.80f -> "Applying your switches..."
                    else -> "Starting game..."
                }
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { hapticConfirm(); onDone() }
            })
            start()
        }
    }
}
