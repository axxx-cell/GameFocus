package com.axxxcell.gamespace.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Small ring that fills to show a value, with an icon in the middle. */
class RingView(ctx: Context, iconRes: Int) : View(ctx) {
    private val rect = RectF()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(4f); color = 0x22FFFFFF
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(4f); strokeCap = Paint.Cap.ROUND
    }
    private val icon = ContextCompat.getDrawable(ctx, iconRes)?.mutate()
    private var frac = 0f
    private var anim: ValueAnimator? = null

    override fun onMeasure(w: Int, h: Int) {
        val s = context.dpi(38f)
        setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val p = context.dp(4f)
        rect.set(p, p, w - p, h - p)
    }

    fun set(fraction: Float, color: Int) {
        arc.color = color
        icon?.setTint(color)
        val target = fraction.coerceIn(0f, 1f)
        anim?.cancel()
        anim = ValueAnimator.ofFloat(frac, target).apply {
            duration = 450
            addUpdateListener { frac = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        c.drawArc(rect, 0f, 360f, false, track)
        if (frac > 0.01f) c.drawArc(rect, -90f, 360f * frac, false, arc)
        icon?.let {
            val half = (width * 0.20f).toInt()
            val cx = width / 2
            val cy = height / 2
            it.setBounds(cx - half, cy - half, cx + half, cy + half)
            it.draw(c)
        }
    }
}

/** One live meter: ring, label, big value and a short status. */
class MeterTile(ctx: Context, iconRes: Int, label: String) : LinearLayout(ctx) {
    private val ring = RingView(ctx, iconRes)
    private val labelTv = TextView(ctx)
    private val valueTv = TextView(ctx)
    private val subTv = TextView(ctx)

    val valueText: String get() = valueTv.text.toString()

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpi(8f), dpi(4f), dpi(8f), dpi(4f))
        isClickable = true
        hud(cutDp = 8f)
        addView(ring)
        val col = LinearLayout(ctx).apply { orientation = VERTICAL }
        labelTv.apply { text = label; textSize = 8f; setTextColor(GS.TEXT_SECONDARY); typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.1f; maxLines = 1 }
        valueTv.apply { text = "--"; textSize = 14f; setTextColor(GS.WHITE); typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); maxLines = 1 }
        subTv.apply { text = ""; textSize = 9f; setTextColor(GS.TEXT_SECONDARY); maxLines = 1 }
        col.addView(labelTv); col.addView(valueTv); col.addView(subTv)
        addView(col, LayoutParams(0, WRAP, 1f).apply { marginStart = dpi(8f) })
    }

    fun set(value: String, sub: String, fraction: Float, color: Int) {
        valueTv.text = value
        subTv.text = sub
        subTv.setTextColor(color)
        ring.set(fraction, color)
    }
}
