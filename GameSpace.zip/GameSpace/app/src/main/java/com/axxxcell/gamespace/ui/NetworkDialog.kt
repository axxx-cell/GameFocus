package com.axxxcell.gamespace.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.SystemClock
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

/** A quick, honest connection test. Nothing here changes your connection. */
object NetTools {

    data class Result(
        val avgMs: Int, val jitterMs: Int, val lossPct: Int,
        val wifi: Boolean, val mobile: Boolean, val rssi: Int?, val freqMhz: Int?
    )

    suspend fun measure(ctx: Context): Result = withContext(Dispatchers.IO) {
        val times = ArrayList<Int>()
        var lost = 0
        repeat(5) {
            try {
                Socket().use { s ->
                    val t = SystemClock.elapsedRealtime()
                    s.connect(InetSocketAddress("1.1.1.1", 443), 1500)
                    times.add((SystemClock.elapsedRealtime() - t).toInt())
                }
            } catch (e: Exception) { lost++ }
            delay(200)
        }
        val avg = if (times.isEmpty()) -1 else times.average().toInt()
        val jitter = if (times.size > 1) times.zipWithNext { a, b -> abs(a - b) }.average().toInt() else 0

        val app = ctx.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val mobile = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        var rssi: Int? = null
        var freq: Int? = null
        if (wifi) {
            try {
                val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION") val info = wm.connectionInfo
                rssi = info.rssi
                freq = info.frequency
            } catch (_: Exception) {}
        }
        Result(avg, jitter, lost * 20, wifi, mobile, rssi, freq)
    }

    fun describe(r: Result): String {
        if (r.avgMs < 0) return "No connection to the test server. Check your internet."
        val sb = StringBuilder()
        sb.append("Ping ${r.avgMs}ms  \u2022  Jitter ${r.jitterMs}ms  \u2022  Loss ${r.lossPct}%\n")
        sb.append(when {
            r.lossPct > 0 || r.jitterMs > 30 -> "Unstable. Expect lag spikes.\n"
            r.avgMs < 60 -> "Good for gaming.\n"
            r.avgMs < 120 -> "Playable, but you may feel delay.\n"
            else -> "High delay.\n"
        })
        if (r.wifi) {
            val band = if ((r.freqMhz ?: 0) >= 4900) "5 GHz" else if ((r.freqMhz ?: 0) > 0) "2.4 GHz" else ""
            sb.append("Wi-Fi $band")
            r.rssi?.let { sb.append("  signal $it dBm") }
            sb.append("\n")
            if ((r.rssi ?: 0) < -75 && r.rssi != null) sb.append("Weak signal: move closer to the router.\n")
            if (band == "2.4 GHz") sb.append("Try the 5 GHz network if your router has one.\n")
        } else if (r.mobile) {
            sb.append("Mobile data\n")
        }
        return sb.toString().trim()
    }
}

object NetworkDialog {

    private const val WARP_PKG = "com.cloudflare.onedotonedotonedotone"

    fun show(a: AppCompatActivity) {
        GlassDialogs.make(a, 460f) { box, d ->
            box.addView(GlassDialogs.title(a, "NETWORK TOOLS"))
            box.addView(GlassDialogs.body(a,
                "Game Space can't speed up your connection by itself. These tools help you find out what is wrong " +
                "and use free options that sometimes help."))

            // ---- test ----
            box.addView(GlassDialogs.body(a, "1  TEST YOUR CONNECTION", 11f, GS.CYAN))
            val result = TextView(a).apply {
                text = "Tap Test, then test again after changing something to compare."
                textSize = 12f
                setTextColor(GS.WHITE)
                typeface = android.graphics.Typeface.MONOSPACE
                setPadding(0, a.dpi(6f), 0, 0)
            }
            box.addView(result)
            val test = GlassDialogs.button(a, "TEST NOW", true) {
                result.text = "Testing..."
                a.lifecycleScope.launch { result.text = NetTools.describe(NetTools.measure(a)) }
            }
            box.addView(GlassDialogs.row(a, test), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(8f) })

            // ---- private DNS ----
            box.addView(GlassDialogs.body(a, "2  FASTER DNS (FREE)", 11f, GS.CYAN))
            box.addView(GlassDialogs.body(a,
                "Makes login and matchmaking lookups quicker. It does not lower in-match ping.\n" +
                "Settings > Network (or Connection & sharing) > Private DNS > \"Private DNS provider hostname\" > paste:"))
            box.addView(TextView(a).apply {
                text = "one.one.one.one"
                textSize = 15f
                setTextColor(GS.CYAN)
                typeface = android.graphics.Typeface.MONOSPACE
                setPadding(0, a.dpi(4f), 0, 0)
            })
            val copy = GlassDialogs.button(a, "COPY", false) {
                val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("dns", "one.one.one.one"))
                Toast.makeText(a, "Copied", Toast.LENGTH_SHORT).show()
            }
            val settings = GlassDialogs.button(a, "OPEN SETTINGS", false) {
                try { a.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
                catch (_: Exception) { a.startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            box.addView(GlassDialogs.row(a, copy, settings), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(8f) })

            // ---- WARP ----
            box.addView(GlassDialogs.body(a, "3  CLOUDFLARE WARP (FREE)", 11f, GS.CYAN))
            box.addView(GlassDialogs.body(a,
                "A free app that sends your traffic over Cloudflare's network. Where your provider's route to the game " +
                "is bad, ping can drop. Where the route is already good, it can get worse.\n" +
                "Install it, switch WARP on, then test again here. If the ping is worse, switch it off."))
            val installed = a.packageManager.getLaunchIntentForPackage(WARP_PKG) != null
            val warp = GlassDialogs.button(a, if (installed) "OPEN WARP" else "GET WARP", false) {
                val launch = a.packageManager.getLaunchIntentForPackage(WARP_PKG)
                try {
                    if (launch != null) a.startActivity(launch)
                    else a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$WARP_PKG")))
                } catch (_: Exception) {
                    try {
                        a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$WARP_PKG")))
                    } catch (_: Exception) {}
                }
            }
            box.addView(GlassDialogs.row(a, warp), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(8f) })

            // ---- quick wins ----
            box.addView(GlassDialogs.body(a, "4  QUICK WINS", 11f, GS.CYAN))
            box.addView(GlassDialogs.body(a,
                "\u2022 Use 5 GHz Wi-Fi and sit close to the router\n" +
                "\u2022 Pause downloads and streaming on other devices\n" +
                "\u2022 Compare Wi-Fi with mobile data and use the better one\n" +
                "\u2022 Tap BOOST first so background apps stop using data\n" +
                "\u2022 Restart the router if the test shows loss or high jitter"))

            box.addView(GlassDialogs.row(a, GlassDialogs.button(a, "CLOSE", false) { d.dismiss() }),
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(14f) })
        }
    }
}
