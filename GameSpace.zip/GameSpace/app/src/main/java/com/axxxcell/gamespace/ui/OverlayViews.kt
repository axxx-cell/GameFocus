package com.axxxcell.gamespace.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Views shown on top of games (added by AutoActivationService as accessibility overlays). */
object OverlayViews {

    fun banner(ctx: Context, game: String, extra: String? = null, title: String = "SYSTEM ENGAGED"): View {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ctx.dpi(22f), ctx.dpi(8f), ctx.dpi(22f), ctx.dpi(8f))
            glass(cornerDp = 18f, fill = 0xE60A0E1E.toInt(), stroke = 0xAA00FF88.toInt())
        }
        box.addView(TextView(ctx).apply {
            text = title
            textSize = 13f
            setTextColor(GS.GREEN_ON)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(ctx.dp(8f), 0f, 0f, GS.GREEN_ON)
        })
        box.addView(TextView(ctx).apply {
            text = if (extra != null) game.uppercase() + "\n" + extra else game.uppercase()
            textSize = 10f
            setTextColor(GS.TEXT_SECONDARY)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
        })
        return box
    }

    fun summary(ctx: Context, headline: String, onClose: () -> Unit): View {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ctx.dpi(20f), ctx.dpi(12f), ctx.dpi(20f), ctx.dpi(12f))
            glass(cornerDp = 20f, fill = 0xF20A0E1E.toInt(), stroke = 0xAA00F5FF.toInt())
        }
        box.addView(TextView(ctx).apply {
            text = "SESSION COMPLETE"
            textSize = 12f
            setTextColor(GS.CYAN)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(ctx.dp(8f), 0f, 0f, GS.CYAN)
        })
        box.addView(TextView(ctx).apply {
            text = headline
            textSize = 13f
            setTextColor(GS.WHITE)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, ctx.dpi(4f), 0, ctx.dpi(8f))
        })
        box.addView(TextView(ctx).apply {
            text = "DISMISS"
            textSize = 11f
            setTextColor(GS.CYAN)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setPadding(ctx.dpi(18f), ctx.dpi(5f), ctx.dpi(18f), ctx.dpi(5f))
            glass(cornerDp = 14f)
            setOnClickListener { haptic(); onClose() }
        })
        return box
    }
}
