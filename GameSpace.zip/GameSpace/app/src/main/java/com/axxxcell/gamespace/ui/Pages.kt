package com.axxxcell.gamespace.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.axxxcell.gamespace.R
import com.axxxcell.gamespace.data.GameRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun Context.tv(text: String, size: Float, color: Int, bold: Boolean = false, mono: Boolean = false) =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        if (mono) typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
    }

private fun Context.sectionTitle(text: String) = TextView(this).apply {
    this.text = text
    textSize = 12f
    setTextColor(GS.CYAN)
    typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
    letterSpacing = 0.15f
    setShadowLayer(dp(8f), 0f, 0f, GS.CYAN)
}

/** Small pill button. filled = solid cyan gradient. */
private fun Context.pill(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
    this.text = text
    textSize = 11f
    gravity = Gravity.CENTER
    typeface = Typeface.DEFAULT_BOLD
    letterSpacing = 0.08f
    setPadding(dpi(14f), dpi(7f), dpi(14f), dpi(7f))
    if (filled) {
        setTextColor(0xFF04202B.toInt())
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF00C2E0.toInt(), 0xFF00F5FF.toInt())
        ).apply { cornerRadius = dp(16f) }
    } else {
        setTextColor(GS.CYAN)
        glass(cornerDp = 16f)
    }
    setOnClickListener { haptic(); onClick() }
}

/** The "+ ADD GAME" card: last item in the carousel, and the big centred button when there are no games. */
class AddCardView(ctx: Context) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        hud(cutDp = 16f)
        val ring = FrameLayout(ctx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x2200F5FF)
                setStroke(ctx.dpi(2f), GS.CYAN)
            }
        }
        ring.addView(ctx.icon(R.drawable.ic_plus, 26f, GS.CYAN), FrameLayout.LayoutParams(dpi(26f), dpi(26f), Gravity.CENTER))
        addView(ring, LinearLayout.LayoutParams(dpi(52f), dpi(52f)))
        addView(ctx.tv("ADD GAME", 13f, GS.WHITE, bold = true).apply { letterSpacing = 0.1f; setPadding(0, dpi(8f), 0, 0) })
        addView(ctx.tv("Pick from your installed apps", 10f, GS.TEXT_SECONDARY))
    }
}

/** Ring gauge for RAM load. Spins while a boost is running. */
class BoostGaugeView(ctx: Context) : View(ctx) {
    private val rect = RectF()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(11f); strokeCap = Paint.Cap.ROUND; color = 0x1FFFFFFF
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(11f); strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(22f); strokeCap = Paint.Cap.ROUND; alpha = 45
    }
    private val spin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(4f); strokeCap = Paint.Cap.ROUND; color = 0xFFFFFFFF.toInt()
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GS.CYAN; textAlign = Paint.Align.CENTER; textSize = ctx.dp(30f)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GS.TEXT_SECONDARY; textAlign = Paint.Align.CENTER; textSize = ctx.dp(10f); typeface = Typeface.MONOSPACE
    }
    private var progress = 0f
    private var centerText = "--"
    private var subText = ""
    private var spinning = false
    private var spinAngle = 0f
    private var progAnim: ValueAnimator? = null
    private var spinAnim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val pad = context.dp(18f)
        rect.set(pad, pad, w - pad, h - pad)
        val g = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), GS.CYAN, GS.PURPLE, Shader.TileMode.CLAMP)
        arc.shader = g
        glow.shader = g
    }

    fun setValue(pct: Int, sub: String, animate: Boolean = true) {
        centerText = "$pct%"
        subText = sub
        val target = pct / 100f
        progAnim?.cancel()
        if (!animate) { progress = target; invalidate(); return }
        progAnim = ValueAnimator.ofFloat(progress, target).apply {
            duration = 700
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun setSpinning(on: Boolean) {
        spinning = on
        spinAnim?.cancel(); spinAnim = null
        if (on) {
            spinAnim = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 1100
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { spinAngle = it.animatedValue as Float; invalidate() }
                start()
            }
        } else invalidate()
    }

    override fun onDetachedFromWindow() { progAnim?.cancel(); spinAnim?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        c.drawArc(rect, 135f, 270f, false, track)
        val sweep = 270f * progress
        if (sweep > 1f) {
            c.drawArc(rect, 135f, sweep, false, glow)
            c.drawArc(rect, 135f, sweep, false, arc)
        }
        if (spinning) {
            val inner = RectF(rect).apply { inset(context.dp(16f), context.dp(16f)) }
            c.drawArc(inner, spinAngle, 70f, false, spin)
            c.drawArc(inner, spinAngle + 180f, 40f, false, spin)
        }
        val cx = width / 2f
        val cy = height / 2f
        c.drawText(centerText, cx, cy + context.dp(6f), big)
        c.drawText("RAM LOAD", cx, cy - context.dp(24f), small)
        c.drawText(subText, cx, cy + context.dp(26f), small)
    }
}

/** Boost page: RAM ring, live status while boosting, and the real result afterwards. */
class BoostPage(ctx: Context, private val onBoost: () -> Unit) : FrameLayout(ctx) {

    private val gauge = BoostGaugeView(ctx)
    private val burst = ParticleBurstView(ctx)
    private val status = ctx.tv("READY TO BOOST", 13f, GS.CYAN, bold = true).apply { letterSpacing = 0.12f }
    private val line1 = ctx.tv("Tap BOOST NOW to free memory", 18f, GS.WHITE, bold = true, mono = true)
    private val line2 = ctx.tv("", 12f, GS.TEXT_SECONDARY, mono = true)
    private val line3 = ctx.tv("", 12f, GS.TEXT_SECONDARY, mono = true)
    private val last = ctx.tv("No boost yet", 10f, GS.TEXT_SECONDARY, mono = true)
    private val btn = LinearLayout(ctx)
    private val btnLabel = ctx.tv("BOOST NOW", 14f, 0xFF04202B.toInt(), bold = true).apply { letterSpacing = 0.12f }
    private var busy = false

    init {
        val content = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        content.addView(gauge, LinearLayout.LayoutParams(dpi(200f), dpi(200f)))

        val right = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        right.addView(ctx.sectionTitle("BOOST"))
        right.addView(ctx.tv("Closes background apps and clears Game Space's cache.", 11f, GS.TEXT_SECONDARY))
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(14f), dpi(10f), dpi(14f), dpi(10f))
            hud(cutDp = 12f, on = true)
        }
        card.addView(status)
        card.addView(line1, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(4f) })
        card.addView(line2)
        card.addView(line3)
        right.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(8f) })
        right.addView(last, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dpi(6f) })

        btn.apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF00C2E0.toInt(), 0xFF00F5FF.toInt())
            ).apply { cornerRadius = ctx.dp(22f) }
            setOnClickListener { if (!busy) { haptic(); onBoost() } }
        }
        btn.addView(ctx.icon(R.drawable.ic_rocket, 18f, 0xFF04202B.toInt()))
        btn.addView(btnLabel.apply { setPadding(dpi(8f), 0, 0, 0) })
        right.addView(btn, LinearLayout.LayoutParams(MATCH, dpi(44f)).apply { topMargin = dpi(10f) })

        content.addView(right, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dpi(14f) })
        addView(content, LayoutParams(MATCH, MATCH))
        addView(burst, LayoutParams(MATCH, MATCH))
    }

    fun setRam(usedMb: Int, totalMb: Int) {
        if (busy || totalMb <= 0) return
        val pct = usedMb * 100 / totalMb
        gauge.setValue(pct, String.format(Locale.US, "%.1f / %.1f GB", usedMb / 1024.0, totalMb / 1024.0))
    }

    /** Line saved by the last boost: "timeMs|ramMb|cacheMb|apps" */
    fun setLast(line: String) {
        val p = line.split("|")
        if (p.size < 4) { last.text = "No boost yet"; return }
        val ago = (System.currentTimeMillis() - (p[0].toLongOrNull() ?: 0L)) / 60000
        val whenTxt = when { ago < 1 -> "just now"; ago < 60 -> "$ago min ago"; ago < 1440 -> "${ago / 60} h ago"; else -> "${ago / 1440} d ago" }
        val mb = (p[1].toIntOrNull() ?: 0) + (p[2].toIntOrNull() ?: 0)
        last.text = "Last boost: $whenTxt  |  freed $mb MB  |  ${p[3]} apps cleaned"
    }

    fun begin() {
        busy = true
        gauge.setSpinning(true)
        status.text = "BOOSTING"
        status.setTextColor(GS.CYAN)
        line1.text = "Scanning apps..."
        line2.text = ""
        line3.text = ""
        btnLabel.text = "BOOSTING..."
        btn.alpha = 0.6f
    }

    fun step(text: String) { line1.text = text }

    fun finish(freedMb: Int, apps: Int, beforeMb: Int, afterMb: Int, pingMs: Int) {
        busy = false
        gauge.setSpinning(false)
        status.text = if (freedMb > 0) "BOOST COMPLETE" else "ALREADY CLEAN"
        status.setTextColor(GS.GREEN_ON)
        line1.text = if (freedMb > 0) "Freed $freedMb MB" else "Nothing left to free"
        line2.text = "$apps background apps cleaned"
        line3.text = "RAM $beforeMb -> $afterMb MB" + if (pingMs > 0) "   Ping $pingMs ms" else ""
        btnLabel.text = "BOOST AGAIN"
        btn.alpha = 1f
        burst.burst(gauge.left + gauge.width / 2f, gauge.top + gauge.height / 2f)
        haptic()
    }
}

/** All your games as a list. */
class GamesPage(
    ctx: Context,
    private val onAdd: () -> Unit,
    private val onPlay: (GameRepository.App) -> Unit,
    private val onRemove: (GameRepository.App) -> Unit
) : LinearLayout(ctx) {

    init { orientation = VERTICAL }

    fun setGames(list: List<GameRepository.App>, played: Map<String, Int>, note: String?) {
        removeAllViews()
        val head = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(context.sectionTitle("MY GAMES"))
        head.addView(context.tv("  ${list.size}", 12f, GS.TEXT_SECONDARY, mono = true))
        head.addView(View(context), LayoutParams(0, 1, 1f))
        head.addView(context.pill("+ ADD GAME", true) { onAdd() })
        addView(head)
        if (note != null) addView(context.tv(note, 10f, GS.TEXT_SECONDARY))

        val col = LinearLayout(context).apply { orientation = VERTICAL }
        if (list.isEmpty()) {
            col.addView(context.tv("No games yet. Tap + ADD GAME.", 13f, GS.TEXT_SECONDARY).apply { setPadding(0, dpi(20f), 0, 0) })
        }
        for (app in list) {
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpi(12f), dpi(8f), dpi(12f), dpi(8f))
                hud(cutDp = 10f)
            }
            row.addView(ImageView(context).apply { setImageDrawable(app.icon) }, LayoutParams(dpi(40f), dpi(40f)))
            val info = LinearLayout(context).apply { orientation = VERTICAL }
            info.addView(context.tv(app.label, 14f, GS.WHITE, bold = true).apply { maxLines = 1 })
            val mins = played[app.pkg] ?: 0
            info.addView(context.tv(app.category + "  |  " + (if (mins > 0) "$mins min today" else "not played today"), 10f, GS.TEXT_SECONDARY, mono = true))
            row.addView(info, LayoutParams(0, WRAP, 1f).apply { marginStart = dpi(12f) })
            row.addView(context.pill("PLAY", true) { onPlay(app) })
            row.addView(context.pill("REMOVE", false) { onRemove(app) }, LayoutParams(WRAP, WRAP).apply { marginStart = dpi(8f) })
            col.addView(row, LayoutParams(MATCH, WRAP).apply { topMargin = dpi(8f) })
        }
        addView(ScrollView(context).apply { isVerticalScrollBarEnabled = false; addView(col) }, LayoutParams(MATCH, 0, 1f))
    }
}

/** Totals and recent sessions. */
class StatsPage(ctx: Context) : LinearLayout(ctx) {

    init { orientation = VERTICAL }

    fun setSessions(lines: List<String>) {
        removeAllViews()
        addView(context.sectionTitle("STATS"))
        var count = 0
        var totalMs = 0L
        var freed = 0
        val rows = ArrayList<List<String>>()
        for (l in lines) {
            val p = l.split("|")
            if (p.size < 5) continue
            count++
            totalMs += p[3].toLongOrNull() ?: 0L
            freed += p[4].toIntOrNull() ?: 0
            rows.add(p)
        }
        val tiles = LinearLayout(context).apply { orientation = HORIZONTAL }
        fun tile(label: String, value: String) {
            val t = LinearLayout(context).apply {
                orientation = VERTICAL
                setPadding(dpi(12f), dpi(6f), dpi(12f), dpi(6f))
                hud(cutDp = 10f)
            }
            t.addView(context.tv(label, 9f, GS.TEXT_SECONDARY, bold = true).apply { letterSpacing = 0.12f })
            t.addView(context.tv(value, 20f, GS.CYAN, bold = true, mono = true))
            tiles.addView(t, LayoutParams(0, WRAP, 1f).apply { if (tiles.childCount > 0) marginStart = dpi(8f) })
        }
        val mins = totalMs / 60000
        tile("SESSIONS", "$count")
        tile("TIME PLAYED", if (mins >= 60) "${mins / 60}h ${mins % 60}m" else "${mins}m")
        tile("MEMORY FREED", "$freed MB")
        addView(tiles, LayoutParams(MATCH, WRAP).apply { topMargin = dpi(8f) })

        val col = LinearLayout(context).apply { orientation = VERTICAL }
        if (rows.isEmpty()) {
            col.addView(context.tv("No sessions yet. Start a game from Game Space and it shows up here.", 12f, GS.TEXT_SECONDARY)
                .apply { setPadding(0, dpi(14f), 0, 0) })
        }
        val fmt = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
        for (p in rows.take(20)) {
            val m = (p[3].toLongOrNull() ?: 0L) / 60000
            val f = p[4].toIntOrNull() ?: 0
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpi(12f), dpi(7f), dpi(12f), dpi(7f))
                hud(cutDp = 8f)
            }
            row.addView(context.tv(p[1], 13f, GS.WHITE, bold = true).apply { maxLines = 1 }, LayoutParams(0, WRAP, 1f))
            row.addView(context.tv(
                fmt.format(Date(p[2].toLongOrNull() ?: 0L)) + "  |  " + (if (m < 1) "<1 min" else "$m min") + (if (f > 0) "  |  freed $f MB" else ""),
                10f, GS.TEXT_SECONDARY, mono = true))
            col.addView(row, LayoutParams(MATCH, WRAP).apply { topMargin = dpi(6f) })
        }
        addView(ScrollView(context).apply { isVerticalScrollBarEnabled = false; addView(col) }, LayoutParams(MATCH, 0, 1f))
    }
}

/** Theme, Pro status, floating toolbar setup, about. */
class SettingsPage(
    ctx: Context,
    private val onTheme: (String) -> Unit,
    private val onDonate: () -> Unit,
    private val onOpenAccessibility: () -> Unit
) : LinearLayout(ctx) {

    init { orientation = VERTICAL }

    fun update(isPro: Boolean, expiryMs: Long, code: String, theme: String, toolbarOn: Boolean) {
        removeAllViews()
        addView(context.sectionTitle("SETTINGS"))
        val col = LinearLayout(context).apply { orientation = VERTICAL }
        fun card(build: LinearLayout.() -> Unit) {
            val c = LinearLayout(context).apply {
                orientation = VERTICAL
                setPadding(dpi(14f), dpi(10f), dpi(14f), dpi(10f))
                hud(cutDp = 10f)
            }
            c.build()
            col.addView(c, LayoutParams(MATCH, WRAP).apply { topMargin = dpi(8f) })
        }

        card {
            addView(context.tv("THEME", 9f, GS.TEXT_SECONDARY, bold = true).apply { letterSpacing = 0.12f })
            val chips = LinearLayout(context).apply { orientation = HORIZONTAL }
            listOf("neon" to "Neon Gaming", "amoled" to "AMOLED", "transparent" to "Transparent").forEachIndexed { i, (key, name) ->
                val on = key == theme
                chips.addView(TextView(context).apply {
                    text = if (i > 0 && !isPro) "$name  PRO" else name
                    textSize = 11f
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (on) GS.CYAN else GS.TEXT_SECONDARY)
                    glass(
                        cornerDp = 14f,
                        fill = if (on) 0xB3252D5A.toInt() else GS.GLASS_PILL_70,
                        stroke = if (on) 0x9900F5FF.toInt() else GS.CYAN_BORDER_20
                    )
                    setPadding(dpi(8f), dpi(7f), dpi(8f), dpi(7f))
                    setOnClickListener { haptic(); onTheme(key) }
                }, LayoutParams(0, WRAP, 1f).apply { if (i > 0) marginStart = dpi(6f) })
            }
            addView(chips, LayoutParams(MATCH, WRAP).apply { topMargin = dpi(6f) })
        }

        card {
            addView(context.tv("PRO", 9f, GS.TEXT_SECONDARY, bold = true).apply { letterSpacing = 0.12f })
            val status = if (isPro) "Pro is on until " + SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(expiryMs))
                         else "Free version"
            addView(context.tv(status, 14f, if (isPro) GS.GREEN_ON else GS.WHITE, bold = true))
            addView(context.tv("Device code: $code", 11f, GS.TEXT_SECONDARY, mono = true))
            addView(context.pill("DONATE", true) { onDonate() }, LayoutParams(WRAP, WRAP).apply { topMargin = dpi(8f) })
        }

        card {
            addView(context.tv("FLOATING TOOLBAR", 9f, GS.TEXT_SECONDARY, bold = true).apply { letterSpacing = 0.12f })
            addView(context.tv(if (toolbarOn) "On. It appears over your game." else "Off. Turn on the Game Space accessibility service to see it over your game.",
                12f, if (toolbarOn) GS.GREEN_ON else GS.WHITE))
            if (!toolbarOn) addView(context.pill("OPEN SETTINGS", true) { onOpenAccessibility() }, LayoutParams(WRAP, WRAP).apply { topMargin = dpi(8f) })
        }

        card {
            addView(context.tv("ABOUT", 9f, GS.TEXT_SECONDARY, bold = true).apply { letterSpacing = 0.12f })
            val ver = try { context.packageManager.getPackageInfo(context.packageName, 0).versionName } catch (e: Exception) { "" }
            addView(context.tv("Game Space $ver", 12f, GS.WHITE))
            addView(context.tv("Auto Mode only watches which app is in front. It never reads your screen.", 11f, GS.TEXT_SECONDARY))
        }
        addView(ScrollView(context).apply { isVerticalScrollBarEnabled = false; addView(col) }, LayoutParams(MATCH, 0, 1f))
    }
}
