package com.axxxcell.gamespace.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Static perspective "floor" grid that makes the game cards look like they sit on a tilted surface. */
class PerspectiveGridView(ctx: Context) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(1f)
        color = GS.CYAN
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val vx = w / 2f           // vanishing point at the top centre
        val horizon = h * 0.10f

        // horizontal lines: closer together near the horizon, wider apart near the viewer
        val rows = 7
        for (i in 1..rows) {
            val t = i / rows.toFloat()
            val y = horizon + (h - horizon) * t * t
            paint.alpha = (14 + 40 * t).toInt()
            c.drawLine(0f, y, w, y, paint)
        }
        // lines that run toward the vanishing point
        val cols = 14
        for (i in -cols..cols) {
            val xb = vx + i * (w / cols) * 0.9f
            paint.alpha = 30 - (kotlin.math.abs(i) * 30f / (cols + 1)).toInt().coerceAtMost(26)
            c.drawLine(vx + (xb - vx) * 0.12f, horizon, xb, h, paint)
        }
    }
}
