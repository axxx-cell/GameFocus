package com.axxxcell.gamespace.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

/**
 * "WHEN YOU PLAY": what Game Space really does when a game starts.
 * Ultra = all three on. Balanced = only close background apps.
 */
class PlayPanel(
    ctx: Context,
    private val onMode: (String) -> Unit,
    private val onToggle: (String, Boolean) -> Unit
) : LinearLayout(ctx) {

    private val chips = HashMap<String, TextView>()
    private val switches = HashMap<String, SwitchCompat>()
    private var silent = false

    init {
        orientation = VERTICAL
        setPadding(dpi(12f), dpi(10f), dpi(12f), dpi(10f))
        hud(cutDp = 14f)

        addView(TextView(ctx).apply {
            text = "WHEN YOU PLAY"
            textSize = 11f
            setTextColor(GS.CYAN)
            typeface = Typeface.create("sans-serif-black", Typeface.ITALIC)
            letterSpacing = 0.15f
            setShadowLayer(ctx.dp(8f), 0f, 0f, GS.CYAN)
        })

        val seg = LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE; cornerRadius = ctx.dp(15f); setColor(0x33FFFFFF)
            }
            setPadding(dpi(3f), dpi(3f), dpi(3f), dpi(3f))
        }
        for ((key, name) in listOf("balanced" to "Balanced", "ultra" to "Ultra")) {
            val tv = TextView(ctx).apply {
                text = name
                textSize = 11f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dpi(4f), dpi(5f), dpi(4f), dpi(5f))
                setOnClickListener { haptic(); onMode(key) }
            }
            chips[key] = tv
            seg.addView(tv, LayoutParams(0, WRAP, 1f))
        }
        addView(seg, LayoutParams(MATCH, WRAP).apply { topMargin = dpi(8f) })

        row("block", "Block notifications", "Silences pop-ups while you play")
        row("mute", "Mute calls", "Needs Do Not Disturb access")
        row("close", "Close background apps", "Frees memory at launch")
    }

    private fun row(key: String, label: String, sub: String) {
        val r = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(context).apply { orientation = VERTICAL }
        col.addView(TextView(context).apply {
            text = label; textSize = 12f; setTextColor(GS.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 1
        })
        col.addView(TextView(context).apply {
            text = sub; textSize = 9f; setTextColor(GS.TEXT_SECONDARY); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        })
        r.addView(col, LayoutParams(0, WRAP, 1f))
        val sw = SwitchCompat(context).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(GS.CYAN, GS.TEXT_SECONDARY))
            trackTintList = ColorStateList(states, intArrayOf(0x6600F5FF, 0x33FFFFFF))
            setOnCheckedChangeListener { v, on -> if (!silent) { v.haptic(); onToggle(key, on) } }
        }
        switches[key] = sw
        r.addView(sw)
        addView(r, LayoutParams(MATCH, WRAP).apply { topMargin = dpi(8f) })
    }

    fun setState(block: Boolean, mute: Boolean, close: Boolean) {
        silent = true
        switches["block"]?.isChecked = block
        switches["mute"]?.isChecked = mute
        switches["close"]?.isChecked = close
        silent = false
        val sel = when {
            block && mute && close -> "ultra"
            !block && !mute && close -> "balanced"
            else -> ""
        }
        for ((key, tv) in chips) {
            val on = key == sel
            tv.setTextColor(if (on) 0xFF04202B.toInt() else GS.WHITE)
            tv.background = if (on) GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE; cornerRadius = context.dp(12f); setColor(0xFF00E5FF.toInt())
            } else null
        }
    }
}
